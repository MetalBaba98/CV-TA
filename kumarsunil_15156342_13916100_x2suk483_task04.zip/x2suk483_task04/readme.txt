Task04 submission draft package
===============================
Files included:
- answers.tex : main LaTeX file with the report draft
- answers.pdf : compiled PDF (if compilation succeeded)
- images/     : representative and annotated images
- HW.sty, 04-task-header.inc, task-body.tex : copied from the course template for convenience

Important note:
This is a structured draft built from the supplied images. Before final submission,
please re-check every numeric measurement against the original phone images and tape readings.
