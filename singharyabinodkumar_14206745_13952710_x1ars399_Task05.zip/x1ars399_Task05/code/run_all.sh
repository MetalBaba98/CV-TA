#!/bin/bash
set -e
cd "$(dirname "$0")/.."

PY=code/venv/bin/python
REQ=code/requirements.txt

mkdir -p images features

banner () {
    echo
    echo "====================================================================="
    echo ">>> $1"
    echo "====================================================================="
}

banner "CSO610 - CV Task 5 - Arya Singh - x1ars399"

START=$(date +%s)
echo "Task 05 pipeline starting: $(date)"
echo "working directory: $(pwd)"

banner "STEP 0/5  environment  -  create code/venv and install $REQ"

# build the venv the first time this script is run
if [ ! -x "$PY" ]; then
    echo "no venv at code/venv, creating one ..."
    python3 -m venv code/venv
    $PY -m pip install --quiet --upgrade pip
fi

# install the pinned deps if anything is missing
if $PY -c "import torch, torchvision, transformers, sklearn, matplotlib" 2>/dev/null; then
    echo "dependencies already present, skipping install"
else
    echo "installing dependencies from $REQ (this takes a few minutes the first time) ..."
    $PY -m pip install --quiet -r "$REQ"
fi

echo "python: $($PY --version)"

banner "STEP 1/5  code/explore_data.py  -  Section 2: dataset statistics"
echo "downloads the dataset if needed, prints train/test/class counts"
$PY code/explore_data.py


banner "STEP 2/5  code/find_examples.py  -  Section 2: the two visual factors"
echo "searches for the inter-class and intra-class example pairs, writes to images/inter_class_similarity.png and images/intra_class_dissimilarity.png"
$PY code/find_examples.py

banner "STEP 3/5  code/extract_features.py  -  Section 3: DINOv2 [CLS] embeddings"
echo "runs the frozen dinov2-small over both splits, prints the required tensor shapes, writes features/trainval.npz and features/test.npz"
$PY code/extract_features.py

banner "STEP 4/5  code/tsne_plots.py  -  Section 4: t-SNE visualisation"
echo "projects the test embeddings to 2D, writes to images/tsne_cat_dog.png and images/tsne_six_breeds.png"
$PY code/tsne_plots.py

banner "STEP 5/5  code/linear_probe.py  -  Section 5: logistic regression probe"
echo "trains on the trainval embeddings, evaluates once on the test split, prints test accuracy and macro-averaged f1"
$PY code/linear_probe.py

END=$(date +%s)
banner "DONE in $(( (END-START)/60 ))m $(( (END-START)%60 ))s"
echo "figures written to images/:"
ls -1 images/
echo "features/ holds the cached embeddings (not part of submission)"
