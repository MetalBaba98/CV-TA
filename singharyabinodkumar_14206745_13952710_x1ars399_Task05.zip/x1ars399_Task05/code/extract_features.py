## extract the frozen DINOv2 [CLS] embedding for every image in both splits
import os
import numpy as np
import torch
from torch.utils.data import DataLoader
from torchvision.datasets import OxfordIIITPet
from transformers import AutoImageProcessor, AutoModel

torch.manual_seed(42)
np.random.seed(42)

BATCH = 32
OUT = "features"
os.makedirs(OUT, exist_ok=True)

# dinov2
processor = AutoImageProcessor.from_pretrained("facebook/dinov2-small")
model = AutoModel.from_pretrained("facebook/dinov2-small")

# frozen
model.eval()                    

n_params = sum(p.numel() for p in model.parameters())
print(f"loaded facebook/dinov2-small  ({n_params/1e6:.1f}M params)")
print()


# dataset returns PIL images, so turn a list of them into one tensor
def collate(batch):
    images = [im for im, _ in batch]
    labels = torch.tensor([lab for _, lab in batch])
    return processor(images=images, return_tensors="pt"), labels


def extract(split):
    ds = OxfordIIITPet(root=".", split=split, target_types="category", download=True)
    loader = DataLoader(ds, batch_size=BATCH, shuffle=False, collate_fn=collate)

    feats, labels = [], []
    for i, (inputs, y) in enumerate(loader):
        with torch.no_grad():
            out = model(**inputs)
        cls = out.last_hidden_state[:, 0, :]        # token 0 of every image = [CLS]

        ## report the required shapes, using first batch
        if i == 0:
            px = inputs["pixel_values"]
            print(f">> tensor shapes for the first batch of the '{split}' split")
            print(f"   processed input     {tuple(px.shape)} = (batch, RGB channels, height, width)")
            print(f"   final hidden state  {tuple(out.last_hidden_state.shape)}  = (batch, 1 [CLS] + {out.last_hidden_state.shape[1]-1} patch tokens, embedding dim)")
            print(f"   [CLS] embeddings    {tuple(cls.shape)} = (batch, embedding dim)")
            print()

        feats.append(cls.numpy())
        labels.append(y.numpy())
        if (i + 1) % 20 == 0:
            print(f"   {split}: {(i+1)*BATCH}/{len(ds)} images done")

    feats = np.concatenate(feats)
    labels = np.concatenate(labels)

    ## verify that exactly one embedding per image, and it is 1-D per image
    assert feats.shape == (len(ds), model.config.hidden_size)
    print(f">> {split}: {feats.shape[0]} embeddings for {len(ds)} images, each of dimension {feats.shape[1]}")

    path = f"{OUT}/{split}.npz"
    np.savez(path, feats=feats, labels=labels, classes=np.array(ds.classes))
    print("   saved", path)

extract("trainval")
extract("test")
