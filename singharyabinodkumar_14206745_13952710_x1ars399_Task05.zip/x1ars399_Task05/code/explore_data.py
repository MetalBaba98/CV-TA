from torchvision.datasets import OxfordIIITPet
trainval = OxfordIIITPet(root=".", split="trainval", target_types="category", download=True)
test = OxfordIIITPet(root=".", split="test", target_types="category", download=True)

print("training (trainval) images :", len(trainval))
print("test images                :", len(test))
print("classes                    :", len(trainval.classes))

# how many images per breed?
counts = {}
for label in trainval._labels:
    counts[label] = counts.get(label, 0) + 1
print("images per breed in trainval:", sorted(set(counts.values())))

print()
print("the 37 breeds:")
for i, name in enumerate(trainval.classes):
    print(f"  {i:2d}  {name}")
