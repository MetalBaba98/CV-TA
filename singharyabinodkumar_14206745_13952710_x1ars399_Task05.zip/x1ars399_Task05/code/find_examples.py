## find inter-class and intra-class examples of the dataset
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image
from torchvision.datasets import OxfordIIITPet

# The breeds I settled on after reading the two rankings printed below
SIMILAR_PAIR = ("British Shorthair", "Russian Blue")
VARIED_BREED = "Staffordshire Bull Terrier"

trainval = OxfordIIITPet(root=".", split="trainval", target_types="category", download=True)
breeds = trainval.classes


def descriptor(path):
    ## Compute a simple descriptor of an image: a 3D colour histogram of image center
    im = Image.open(path).convert("RGB").resize((96, 96))
    im = im.crop((24, 24, 72, 72))
    hsv = np.asarray(im.convert("HSV"), dtype=float) / 255.0
    hist, _ = np.histogramdd(hsv.reshape(-1, 3), bins=(8, 8, 8), range=((0, 1), (0, 1), (0, 1)))
    hist = hist.ravel() / hist.sum()
    return hist / np.linalg.norm(hist)      # unit length, so distance = cosine


print("computing descriptors for", len(trainval), "trainval images ...")
X = np.stack([descriptor(p) for p in trainval._images])
y = np.array(trainval._labels)

# average descriptor of each breed
means = np.stack([X[y == c].mean(axis=0) for c in range(len(breeds))])
means /= np.linalg.norm(means, axis=1, keepdims=True)

##################  VISUAL FACTOR 1 ###########################
##################  which breeds look alike?
pairs = sorted((1 - means[a] @ means[b], a, b) for a in range(len(breeds)) for b in range(a + 1, len(breeds)))

print()
print(f">> most similar breed pairs (of {len(pairs)}), by distance between breed averages ")
for rank, (d, a, b) in enumerate(pairs[:12], start=1):
    print(f"  {rank:2d}.  {d:.5f}   {breeds[a]:26s} vs {breeds[b]}")

chosen = [i for i, (_, a, b) in enumerate(pairs, start=1) if {breeds[a], breeds[b]} == set(SIMILAR_PAIR)][0]
print(f"we'll use {SIMILAR_PAIR[0]} vs {SIMILAR_PAIR[1]}, which is rank {chosen} of {len(pairs)}.")

## the other end of the same ranking, needed to pick the 6 breeds for section 4.
## in this dataset the cat images are the ones with a capitalised filename, so the
## cat/dog split falls straight out of the file names
is_cat = np.array([trainval._images[np.where(y == c)[0][0]].name[0].isupper() for c in range(len(breeds))])
print(f"   ({is_cat.sum()} cat breeds, {(~is_cat).sum()} dog breeds)")

print()
print(">> most DISsimilar breed pairs that are both cats or both dogs ")
far = [(d, a, b) for d, a, b in pairs if is_cat[a] == is_cat[b]]
for rank, (d, a, b) in enumerate(far[::-1][:8], start=1):
    print(f"  {rank:2d}.  {d:.5f}   {breeds[a]:26s} vs {breeds[b]}")

##################  VISUAL FACTOR 2 ###########################
############      which breed varies the most?
spread = sorted(((np.mean(1 - X[y == c] @ means[c]), c) for c in range(len(breeds))), reverse=True)

print()
print(">> most internally varied breeds (mean distance of an image to its breed average) ")
for rank, (s, c) in enumerate(spread[:12], start=1):
    print(f"  {rank:2d}.  {s:.5f}   {breeds[c]}")

print()
print(">> least internally varied breeds, for contrast ")
for s, c in sorted(spread)[:5]: print(f"{s:.5f}   {breeds[c]}")

chosen = [i for i, (_, c) in enumerate(spread, start=1) if breeds[c] == VARIED_BREED][0]
print(f"we'll use {VARIED_BREED}, which is rank {chosen} of {len(breeds)}.")


############ picking the actual images
def closest_cross_pair(breed_a, breed_b):
    ia = np.where(y == breeds.index(breed_a))[0]
    ib = np.where(y == breeds.index(breed_b))[0]
    d = 1 - X[ia] @ X[ib].T
    r, c = np.unravel_index(np.argmin(d), d.shape)
    return trainval._images[ia[r]], trainval._images[ib[c]], d[r, c]


def farthest_within_pair(breed):
    i = np.where(y == breeds.index(breed))[0]
    d = 1 - X[i] @ X[i].T
    extremeness = 1 - X[i] @ means[breeds.index(breed)]
    tiebreak = np.where(d >= d.max() - 1e-9, extremeness[:, None] + extremeness[None, :], -1)
    r, c = np.unravel_index(np.argmax(tiebreak), tiebreak.shape)
    return trainval._images[i[r]], trainval._images[i[c]], d[r, c]


def save_pair(left, right, left_title, right_title, suptitle, outfile):
    fig, axes = plt.subplots(1, 2, figsize=(9, 4.6))
    for ax, path, title in zip(axes, [left, right], [left_title, right_title]):
        ax.imshow(Image.open(path).convert("RGB"))
        ax.set_anchor("N")
        ax.set_title(title, fontsize=11)
        ax.axis("off")
    fig.suptitle(suptitle, fontsize=13)
    fig.tight_layout()
    fig.savefig(outfile, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print("saved", outfile, "  from", left.name, "and", right.name)

############## save them #################
print()
a, b, d = closest_cross_pair(*SIMILAR_PAIR)
save_pair(a, b,
          f"{SIMILAR_PAIR[0]} (class {breeds.index(SIMILAR_PAIR[0])})",
          f"{SIMILAR_PAIR[1]} (class {breeds.index(SIMILAR_PAIR[1])})",
          f"Inter-class similarity: two different breeds, distance {d:.3f}",
          "images/inter_class_similarity.png")

a, b, d = farthest_within_pair(VARIED_BREED)
save_pair(a, b,
          f"{VARIED_BREED} (class {breeds.index(VARIED_BREED)})",
          f"{VARIED_BREED} (class {breeds.index(VARIED_BREED)})",
          f"Intra-class dissimilarity: one breed, distance {d:.3f}",
          "images/intra_class_dissimilarity.png")
