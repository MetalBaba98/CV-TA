## linear probe: multiclass logistic regression on the frozen DINOv2 embeddings
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score, confusion_matrix, f1_score as _f1
from sklearn.preprocessing import StandardScaler

np.random.seed(42)

SIX = ["British Shorthair", "Russian Blue", "Samoyed", "Newfoundland", "Bombay", "Staffordshire Bull Terrier"]

tr = np.load("features/trainval.npz", allow_pickle=True)
te = np.load("features/test.npz", allow_pickle=True)
Xtr, ytr = tr["feats"], tr["labels"]
Xte, yte = te["feats"], te["labels"]
breeds = list(tr["classes"])
print(f"train {Xtr.shape}  test {Xte.shape}  classes {len(breeds)}")

## standardise, the scaler is FITTED ON TRAIN ONLY and then applied to test
scaler = StandardScaler().fit(Xtr)
Xtr = scaler.transform(Xtr)
Xte = scaler.transform(Xte)
print("standardised (scaler fitted on trainval embeddings only)")

clf = LogisticRegression(max_iter=2000, random_state=42)
clf.fit(Xtr, ytr)
print(f"converged in {clf.n_iter_[0]} iterations (limit 2000)")

pred = clf.predict(Xte)
acc = accuracy_score(yte, pred)
macro = f1_score(yte, pred, average="macro")

print()
print(">> RESULTS on the official test split")
print(f"   test accuracy   {acc:.4f}")
print(f"   macro-averaged F1  {macro:.4f}")

## how did the 6 breeds from the t-SNE plot do?
per_class = _f1(yte, pred, average=None, labels=range(len(breeds)))
print()
print(">> per-breed F1 for the 6 breeds plotted in section 4")
for name in SIX:
    print(f"   {per_class[breeds.index(name)]:.4f}   {name}")

## and which breeds actually get mixed up the most
cm = confusion_matrix(yte, pred, labels=range(len(breeds)))
off = [(cm[i, j] + cm[j, i], i, j) for i in range(len(breeds)) for j in range(i + 1, len(breeds))]
print()
print(">> most confused breed pairs (mistakes in both directions summed)")
for n, i, j in sorted(off, reverse=True)[:8]:
    print(f"   {n:3d}   {breeds[i]:26s} <-> {breeds[j]}")
