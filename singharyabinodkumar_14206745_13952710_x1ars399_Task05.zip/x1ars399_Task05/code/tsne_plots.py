import numpy as np
from torchvision.datasets import OxfordIIITPet
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE
from sklearn.preprocessing import StandardScaler

np.random.seed(42)

# the 6 breeds for 2nd plot, every one of them picked from a ranking printed by find_examples.py file
SIX = [
    "British Shorthair",            # rank 5/666 most similar pair
    "Russian Blue",                 #
    "Samoyed",                      # rank 8 most dissimilar pair that is still same species
    "Newfoundland",                 #
    "Bombay",                       # rank 1/37 most internally varied breed
    "Staffordshire Bull Terrier",   # rank 10/37, the intra-class example from section 2
]

# okabe-ito colors
COLOURS = ["#0072B2", "#D55E00", "#009E73", "#56B4E9", "#CC79A7", "#E69F00"]

d = np.load("features/test.npz", allow_pickle=True)
feats, labels, breeds = d["feats"], d["labels"], list(d["classes"])
print(f"loaded {feats.shape[0]} test embeddings of dimension {feats.shape[1]}")

# cat breeds are the ones whose image files are capitalised in this dataset
test = OxfordIIITPet(root=".", split="test", target_types="category", download=True)
is_cat = np.array([test._images[np.where(labels == c)[0][0]].name[0].isupper() for c in range(len(breeds))])
print(f"derived cat/dog from the file names: {is_cat.sum()} cat breeds, {(~is_cat).sum()} dog breeds")

## standardise before t-SNE, then one projection reused by both plots
Z = TSNE(n_components=2, random_state=42).fit_transform(StandardScaler().fit_transform(feats))
print("t-SNE done, projected shape", Z.shape)

########### plot 1: cat vs dog 
fig, ax = plt.subplots(figsize=(9.5, 6.5))
for cat, colour, name in [(True, COLOURS[0], "cat"), (False, COLOURS[1], "dog")]:
    m = is_cat[labels] == cat
    ax.scatter(Z[m, 0], Z[m, 1], s=7, c=colour, alpha=0.6, linewidths=0, label=f"{name} ({m.sum()} images)")
ax.set_title("t-SNE of frozen DINOv2 [CLS] embeddings, test split\ncoloured by cat vs dog")
ax.set_xlabel("t-SNE dim 1"); ax.set_ylabel("t-SNE dim 2")
ax.legend(markerscale=3, frameon=False, loc="upper left", bbox_to_anchor=(1.02, 1))
fig.tight_layout()
fig.savefig("images/tsne_cat_dog.png", dpi=150)
plt.close(fig)
print("saved images/tsne_cat_dog.png")

############# plot 2: the 6 chosen breeds
fig, ax = plt.subplots(figsize=(9.5, 6.5))
chosen = np.isin(labels, [breeds.index(b) for b in SIX])
ax.scatter(Z[~chosen, 0], Z[~chosen, 1], s=5, c="#d9d9d9", alpha=0.5, linewidths=0, label="other 31 breeds")
for name, colour in zip(SIX, COLOURS):
    m = labels == breeds.index(name)
    ax.scatter(Z[m, 0], Z[m, 1], s=22, c=colour, alpha=0.9, linewidths=0.4, edgecolors="white", label=f"{name} ({m.sum()})")
ax.set_title("t-SNE of frozen DINOv2 [CLS] embeddings, test split\nsame projection, 6 selected breeds")
ax.set_xlabel("t-SNE dim 1"); ax.set_ylabel("t-SNE dim 2")
ax.legend(markerscale=1.6, frameon=False, fontsize=9, loc="upper left", bbox_to_anchor=(1.02, 1))
fig.tight_layout()
fig.savefig("images/tsne_six_breeds.png", dpi=150)
plt.close(fig)
print("saved images/tsne_six_breeds.png")
