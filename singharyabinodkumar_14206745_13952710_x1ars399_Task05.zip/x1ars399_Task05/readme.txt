CSO610 CV Task 05
Arya Singh | x1ars399

############  Run instructions
bash code/run_all.sh

It makes the venv, installs code/requirements.txt, then runs all 5 scripts in order. Takes ~3.5 min on CPU.

############ Code files
code/explore_data.py       # sec 2: counts
code/find_examples.py      # sec 2: the 2 image pairs
code/extract_features.py   # sec 3: dinov2 embeddings
code/tsne_plots.py         # sec 4: both t-SNE plots
code/linear_probe.py       # sec 5: accuracy + macro F1

extract_features.py has to run before the last two, they read its .npz files.

############   Results 
images/inter_class_similarity.png
images/intra_class_dissimilarity.png
images/tsne_cat_dog.png
images/tsne_six_breeds.png
features/trainval.npz, features/test.npz   (cached embeddings, not a part of submission)

Linear probe on the frozen [CLS] embeddings: test accuracy 0.9469, macro F1 0.9461.


############  Honor code
The work here is my own.
I used an AI assistant (Claude) to help debug the code. I used it to understand the task PDF, and write a script that searches for the two example pairs instead of me hand-picking them. Every result in the report came from running the experiment myself.
