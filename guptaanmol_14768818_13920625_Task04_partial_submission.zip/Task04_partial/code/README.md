# Task 04 measurement pipeline

This code calibrates a pinhole camera from chessboard views, records 3D-to-2D
furniture landmark correspondences, and estimates camera pose and distance using
EPnP inside RANSAC followed by Levenberg-Marquardt refinement.

## Coordinate convention

Place the furniture against a wall. `O = (0, 0, 0)` must be the bottom-left leg
contact point that is farthest from the observer, exactly as the assignment
specifies. Use:

- +x: left to right along the furniture width
- +y: rear to front, toward the observer
- +z: vertically upward

Measure every landmark from `O` in centimetres. Use exactly `O, A, B, C, D, E`
for a convenient six-point experiment, and ensure the six points are visibly
distinct and not all coplanar.

## Environment

From the submission root:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r code/requirements.txt
```

## 1. Capture and calibrate

Print or display a chessboard rigidly and measure one square side. Capture about
10-20 sharp images with the same rear camera, lens, focus/zoom mode, resolution,
and orientation that will be used for the furniture. Vary board tilt, distance,
and image position. The `cols` and `rows` values below mean **inner corners**.

Example for a 9-by-6 inner-corner board with 2.4 cm squares:

```bash
.venv/bin/python code/calibrate_camera.py \
  --images 'images/calibration/*.jpg' \
  --cols 9 --rows 6 --square-size-cm 2.4 \
  --output outputs/calibration.json
```

Inspect every image in `outputs/calibration_detections/`. The JSON contains the
matrix `K`, distortion coefficients, accepted/rejected files, RMS error, and
per-view reprojection errors. Retake blurry or repetitive views. Three distinct
planar views are the theoretical minimum used by this implementation, but that
minimum is not a good experimental target.

## 2. Measure and annotate furniture landmarks

Copy `code/landmarks_template.csv` to a new CSV and replace every `REPLACE` with
your tape/ruler measurement. Do not change the required label order. Capture 2-6
furniture photos; also capture a third-person photo of the photographer for the
report.

For each furniture image:

```bash
.venv/bin/python code/annotate_landmarks.py \
  --image images/furniture/view01.jpg \
  --landmarks measurements/landmarks.csv \
  --output outputs/view01_correspondences.json
```

Click `O`, then `A` through `E`. Press `u` to undo, `r` to reset, `s` to save,
or `q` to quit. The program saves original-resolution pixels and an annotated
image suitable for the report.

## 3. Estimate distance

Measure the ground-truth straight-line distance from the camera optical centre
(approximately the physical lens centre) to landmark `O`. Do not measure to the
front face of the chair if the estimated quantity is distance to `O`.

```bash
.venv/bin/python code/estimate_pose.py \
  --calibration outputs/calibration.json \
  --correspondences outputs/view01_correspondences.json \
  --true-distance-cm 175.4 \
  --output outputs/view01_pose.json
```

Repeat for at least two furniture views. Report each distance and error, then a
summary such as mean absolute error. In the overlay, yellow circles are manual
clicks, magenta crosses are PnP reprojections, and red segments show residuals.

## Experimental checks

- Disable digital zoom, filters, portrait correction, and resolution changes.
- Keep the full original images; cropped/rescaled furniture images invalidate K.
- Make the chessboard flat and enter its measured, not nominal, square size.
- Spread calibration poses across the frame and include strong tilts.
- Prefer corners with precise physical definitions and unobstructed pixels.
- Treat a large reprojection error as a warning, not a distance to report.

## Data-free smoke test

After installing dependencies, verify both calibration and pose recovery with
synthetic data:

```bash
.venv/bin/python code/smoke_test.py
```
