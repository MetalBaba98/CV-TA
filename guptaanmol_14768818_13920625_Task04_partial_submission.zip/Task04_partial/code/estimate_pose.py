#!/usr/bin/env python3
"""Estimate camera pose and camera-to-origin distance with EPnP/RANSAC."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import cv2
import numpy as np


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--calibration", required=True)
    parser.add_argument("--correspondences", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--overlay", help="Defaults beside the result JSON")
    parser.add_argument("--true-distance-cm", type=float, help="Tape-measured camera optical-centre to O distance")
    parser.add_argument("--ransac-threshold-px", type=float, default=5.0)
    return parser.parse_args()


def read_json(path: Path) -> dict[str, object]:
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> int:
    args = parse_args()
    calibration = read_json(Path(args.calibration))
    correspondences = read_json(Path(args.correspondences))

    camera_matrix = np.asarray(calibration["camera_matrix"], dtype=np.float64)
    distortion = np.asarray(calibration["distortion_coefficients"], dtype=np.float64)
    points = correspondences["points"]
    object_points = np.asarray([point["object_point_cm"] for point in points], dtype=np.float64)
    image_points = np.asarray([point["image_point_px"] for point in points], dtype=np.float64)

    if camera_matrix.shape != (3, 3):
        raise ValueError("camera_matrix must be 3x3")
    if len(object_points) < 4 or len(object_points) != len(image_points):
        raise ValueError("At least four matching 3D-2D points are required")
    if np.linalg.matrix_rank(object_points - object_points[0]) < 3:
        raise ValueError("Furniture landmarks must not all lie on one plane")
    image_path = Path(str(correspondences["image"]))
    image = cv2.imread(str(image_path), cv2.IMREAD_COLOR)
    if image is None:
        raise FileNotFoundError(f"Could not read correspondence image: {image_path}")
    expected_size = tuple(int(value) for value in calibration["image_size_px"])
    actual_size = (image.shape[1], image.shape[0])
    if actual_size != expected_size:
        raise ValueError(
            f"Furniture image is {actual_size}, but calibration used {expected_size}. "
            "Use the same camera mode/resolution without cropping or digital zoom."
        )

    success, rvec, tvec, inliers = cv2.solvePnPRansac(
        object_points,
        image_points,
        camera_matrix,
        distortion,
        flags=cv2.SOLVEPNP_EPNP,
        iterationsCount=1000,
        reprojectionError=args.ransac_threshold_px,
        confidence=0.999,
    )
    if not success or inliers is None or len(inliers) < 4:
        raise RuntimeError("PnP/RANSAC could not find a pose supported by at least four landmarks")

    inlier_indices = inliers.reshape(-1)
    rvec, tvec = cv2.solvePnPRefineLM(
        object_points[inlier_indices],
        image_points[inlier_indices],
        camera_matrix,
        distortion,
        rvec,
        tvec,
    )
    projected, _ = cv2.projectPoints(object_points, rvec, tvec, camera_matrix, distortion)
    projected = projected.reshape(-1, 2)
    residuals = np.linalg.norm(projected - image_points, axis=1)

    rotation, _ = cv2.Rodrigues(rvec)
    camera_center_object_cm = (-rotation.T @ tvec).reshape(3)
    distance_to_origin_cm = float(np.linalg.norm(tvec))
    result: dict[str, object] = {
        "pnp_variant": "EPnP with RANSAC; Levenberg-Marquardt refinement on inliers",
        "rotation_vector": rvec.reshape(-1).tolist(),
        "translation_object_to_camera_cm": tvec.reshape(-1).tolist(),
        "camera_center_in_object_frame_cm": camera_center_object_cm.tolist(),
        "distance_camera_to_origin_O_cm": distance_to_origin_cm,
        "inlier_labels": [points[index]["label"] for index in inlier_indices],
        "reprojection_error_px_by_label": {
            point["label"]: float(error) for point, error in zip(points, residuals)
        },
        "inlier_rmse_px": float(np.sqrt(np.mean(residuals[inlier_indices] ** 2))),
    }
    if args.true_distance_cm is not None:
        if args.true_distance_cm <= 0:
            raise ValueError("true distance must be positive")
        signed_error = distance_to_origin_cm - args.true_distance_cm
        result["true_distance_camera_to_origin_O_cm"] = args.true_distance_cm
        result["signed_distance_error_cm"] = signed_error
        result["absolute_distance_error_cm"] = abs(signed_error)
        result["absolute_percentage_error"] = abs(signed_error) / args.true_distance_cm * 100.0

    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")

    overlay = image.copy()
    for point, observed, estimated, error in zip(points, image_points, projected, residuals):
        obs = tuple(np.rint(observed).astype(int))
        est = tuple(np.rint(estimated).astype(int))
        cv2.circle(overlay, obs, 8, (0, 255, 255), 2, cv2.LINE_AA)
        cv2.drawMarker(overlay, est, (255, 0, 255), cv2.MARKER_CROSS, 18, 2, cv2.LINE_AA)
        cv2.line(overlay, obs, est, (0, 0, 255), 2, cv2.LINE_AA)
        cv2.putText(
            overlay,
            f"{point['label']} {error:.1f}px",
            (obs[0] + 10, obs[1] - 10),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.65,
            (0, 0, 0),
            4,
            cv2.LINE_AA,
        )
        cv2.putText(
            overlay,
            f"{point['label']} {error:.1f}px",
            (obs[0] + 10, obs[1] - 10),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.65,
            (0, 255, 255),
            2,
            cv2.LINE_AA,
        )
    overlay_path = Path(args.overlay) if args.overlay else output_path.with_suffix(".jpg")
    overlay_path.parent.mkdir(parents=True, exist_ok=True)
    cv2.imwrite(str(overlay_path), overlay)

    print(f"Distance camera -> O: {distance_to_origin_cm:.3f} cm")
    print(f"Inlier reprojection RMSE: {result['inlier_rmse_px']:.3f} px")
    if args.true_distance_cm is not None:
        print(f"Absolute error: {result['absolute_distance_error_cm']:.3f} cm")
        print(f"Absolute percentage error: {result['absolute_percentage_error']:.2f}%")
    print(f"Saved {output_path}")
    print(f"Saved {overlay_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

