#!/usr/bin/env python3
"""Calibrate a pinhole camera from chessboard photographs.

The board dimensions passed on the command line are the number of *inner*
corners, not the number of black/white squares.
"""

from __future__ import annotations

import argparse
import glob
import json
from pathlib import Path
import sys

import cv2
import numpy as np


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--images", required=True, help="Glob for calibration images, quoted in the shell")
    parser.add_argument("--cols", required=True, type=int, help="Inner corners per row")
    parser.add_argument("--rows", required=True, type=int, help="Inner corners per column")
    parser.add_argument("--square-size-cm", required=True, type=float, help="Measured chessboard square side in cm")
    parser.add_argument("--output", default="outputs/calibration.json")
    parser.add_argument("--detections-dir", default="outputs/calibration_detections")
    parser.add_argument("--minimum-views", type=int, default=3)
    return parser.parse_args()


def detect_corners(gray: np.ndarray, pattern_size: tuple[int, int]) -> tuple[bool, np.ndarray | None]:
    """Prefer the robust sector-based detector, with a classic fallback."""
    if hasattr(cv2, "findChessboardCornersSB"):
        flags = cv2.CALIB_CB_NORMALIZE_IMAGE | cv2.CALIB_CB_EXHAUSTIVE | cv2.CALIB_CB_ACCURACY
        found, corners = cv2.findChessboardCornersSB(gray, pattern_size, flags=flags)
        if found:
            return True, corners.astype(np.float32)

    flags = cv2.CALIB_CB_ADAPTIVE_THRESH | cv2.CALIB_CB_NORMALIZE_IMAGE
    found, corners = cv2.findChessboardCorners(gray, pattern_size, flags=flags)
    if not found:
        return False, None
    criteria = (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_MAX_ITER, 50, 1e-4)
    refined = cv2.cornerSubPix(gray, corners, (11, 11), (-1, -1), criteria)
    return True, refined


def per_view_errors(
    object_points: list[np.ndarray],
    image_points: list[np.ndarray],
    rvecs: tuple[np.ndarray, ...],
    tvecs: tuple[np.ndarray, ...],
    camera_matrix: np.ndarray,
    distortion: np.ndarray,
) -> list[float]:
    errors: list[float] = []
    for object_view, image_view, rvec, tvec in zip(object_points, image_points, rvecs, tvecs):
        projected, _ = cv2.projectPoints(object_view, rvec, tvec, camera_matrix, distortion)
        residuals = image_view.reshape(-1, 2) - projected.reshape(-1, 2)
        errors.append(float(np.sqrt(np.mean(np.sum(residuals * residuals, axis=1)))))
    return errors


def main() -> int:
    args = parse_args()
    if args.cols < 2 or args.rows < 2 or args.square_size_cm <= 0:
        raise ValueError("cols and rows must be >= 2; square size must be positive")

    image_paths = [Path(path) for path in sorted(glob.glob(args.images))]
    if not image_paths:
        raise FileNotFoundError(f"No images matched: {args.images}")

    pattern_size = (args.cols, args.rows)
    object_template = np.zeros((args.rows * args.cols, 3), dtype=np.float32)
    object_template[:, :2] = (
        np.mgrid[0 : args.cols, 0 : args.rows].T.reshape(-1, 2) * args.square_size_cm
    )

    detections_dir = Path(args.detections_dir)
    detections_dir.mkdir(parents=True, exist_ok=True)
    object_points: list[np.ndarray] = []
    image_points: list[np.ndarray] = []
    used_files: list[str] = []
    rejected_files: list[str] = []
    image_size: tuple[int, int] | None = None

    for image_path in image_paths:
        image = cv2.imread(str(image_path), cv2.IMREAD_COLOR)
        if image is None:
            rejected_files.append(str(image_path))
            print(f"REJECT unreadable: {image_path}")
            continue
        current_size = (image.shape[1], image.shape[0])
        if image_size is None:
            image_size = current_size
        elif current_size != image_size:
            rejected_files.append(str(image_path))
            print(f"REJECT image size {current_size}, expected {image_size}: {image_path}")
            continue

        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        found, corners = detect_corners(gray, pattern_size)
        if not found or corners is None:
            rejected_files.append(str(image_path))
            print(f"REJECT board not found: {image_path}")
            continue

        object_points.append(object_template.copy())
        image_points.append(corners)
        used_files.append(str(image_path))
        preview = image.copy()
        cv2.drawChessboardCorners(preview, pattern_size, corners, True)
        cv2.imwrite(str(detections_dir / f"{image_path.stem}_corners.jpg"), preview)
        print(f"USE: {image_path}")

    required = max(3, args.minimum_views)
    if len(used_files) < required:
        raise RuntimeError(
            f"Only {len(used_files)} usable views; at least {required} geometrically varied views are required. "
            "For a stable submission, capture roughly 10-20 views at different tilts and image positions."
        )
    assert image_size is not None

    rms, camera_matrix, distortion, rvecs, tvecs = cv2.calibrateCamera(
        object_points, image_points, image_size, None, None
    )
    errors = per_view_errors(object_points, image_points, rvecs, tvecs, camera_matrix, distortion)

    result = {
        "model": "opencv_pinhole",
        "camera_matrix": camera_matrix.tolist(),
        "distortion_coefficients": distortion.reshape(-1).tolist(),
        "image_size_px": [image_size[0], image_size[1]],
        "board_inner_corners": [args.cols, args.rows],
        "square_size_cm": args.square_size_cm,
        "rms_reprojection_error_px": float(rms),
        "per_view_reprojection_error_px": dict(zip(used_files, errors)),
        "mean_view_reprojection_error_px": float(np.mean(errors)),
        "used_images": used_files,
        "rejected_images": rejected_files,
    }
    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")

    np.set_printoptions(precision=8, suppress=True)
    print("\nK =")
    print(camera_matrix)
    print(f"RMS reprojection error: {rms:.4f} px")
    print(f"Mean per-view reprojection error: {np.mean(errors):.4f} px")
    print(f"Saved {output_path}")
    if len(used_files) < 10:
        print("WARNING: The theoretical minimum was met, but 10-20 diverse views are recommended.", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

