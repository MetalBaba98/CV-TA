#!/usr/bin/env python3
"""Synthetic, data-free verification of calibration and pose estimation."""

from __future__ import annotations

import argparse
from contextlib import nullcontext
import json
from pathlib import Path
import subprocess
import sys
import tempfile

import cv2
import numpy as np


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output-dir",
        help="Keep generated calibration, pose, and preview artifacts in this directory",
    )
    return parser.parse_args()


def make_chessboard_views(root: Path, camera_matrix: np.ndarray) -> list[Path]:
    """Render geometrically consistent 9x6-inner-corner chessboard views."""
    square_px = 100
    board_cols, board_rows = 10, 7
    border = square_px
    base = np.full(
        ((board_rows + 2) * square_px, (board_cols + 2) * square_px), 255, dtype=np.uint8
    )
    for row in range(board_rows):
        for col in range(board_cols):
            color = 0 if (row + col) % 2 == 0 else 255
            y0, y1 = border + row * square_px, border + (row + 1) * square_px
            x0, x1 = border + col * square_px, border + (col + 1) * square_px
            base[y0:y1, x0:x1] = color

    source = np.array(
        [
            [border, border],
            [border + board_cols * square_px, border],
            [border + board_cols * square_px, border + board_rows * square_px],
            [border, border + board_rows * square_px],
        ],
        dtype=np.float32,
    )
    square_cm = 2.5
    outer_object = np.array(
        [
            [-square_cm, -square_cm, 0.0],
            [9 * square_cm, -square_cm, 0.0],
            [9 * square_cm, 6 * square_cm, 0.0],
            [-square_cm, 6 * square_cm, 0.0],
        ],
        dtype=np.float64,
    )
    poses = [
        ((-0.20, -0.18, -0.05), (-10.0, -6.0, 58.0)),
        ((-0.10, 0.22, 0.08), (-6.0, -4.0, 62.0)),
        ((0.18, -0.12, -0.10), (-8.0, -8.0, 66.0)),
        ((0.25, 0.18, 0.03), (-4.0, -5.0, 70.0)),
        ((-0.25, 0.10, 0.13), (-12.0, -2.0, 68.0)),
        ((0.12, -0.25, -0.08), (-3.0, -9.0, 72.0)),
        ((-0.15, -0.28, 0.12), (-8.0, -3.0, 74.0)),
        ((0.28, 0.08, -0.12), (-5.0, -7.0, 76.0)),
    ]
    outputs: list[Path] = []
    for index, (rotation, translation) in enumerate(poses):
        destination, _ = cv2.projectPoints(
            outer_object,
            np.asarray(rotation, dtype=np.float64),
            np.asarray(translation, dtype=np.float64),
            camera_matrix,
            np.zeros(5),
        )
        homography = cv2.getPerspectiveTransform(source, destination.reshape(4, 2).astype(np.float32))
        rendered = cv2.warpPerspective(
            base,
            homography,
            (1280, 960),
            flags=cv2.INTER_LINEAR,
            borderMode=cv2.BORDER_CONSTANT,
            borderValue=200,
        )
        output = root / f"calibration_{index:02d}.png"
        cv2.imwrite(str(output), rendered)
        outputs.append(output)
    return outputs


def main() -> int:
    args = parse_args()
    if args.output_dir:
        output_root = Path(args.output_dir)
        output_root.mkdir(parents=True, exist_ok=True)
        workspace = nullcontext(str(output_root))
    else:
        workspace = tempfile.TemporaryDirectory(prefix="task04-smoke-")

    with workspace as temp_dir:
        root = Path(temp_dir)
        width, height = 1280, 960
        camera_matrix = np.array(
            [[1050.0, 0.0, width / 2], [0.0, 1040.0, height / 2], [0.0, 0.0, 1.0]],
            dtype=np.float64,
        )
        distortion = np.zeros(5, dtype=np.float64)
        calibration_views = root / "calibration_views"
        calibration_views.mkdir()
        make_chessboard_views(calibration_views, camera_matrix)
        calibrated_path = root / "calibrated.json"
        calibration_command = [
            sys.executable,
            str(Path(__file__).with_name("calibrate_camera.py")),
            "--images",
            str(calibration_views / "*.png"),
            "--cols",
            "9",
            "--rows",
            "6",
            "--square-size-cm",
            "2.5",
            "--output",
            str(calibrated_path),
            "--detections-dir",
            str(root / "detections"),
        ]
        subprocess.run(calibration_command, check=True)
        calibrated = json.loads(calibrated_path.read_text(encoding="utf-8"))
        recovered_k = np.asarray(calibrated["camera_matrix"])
        assert len(calibrated["used_images"]) == 8
        assert abs(recovered_k[0, 0] - camera_matrix[0, 0]) / camera_matrix[0, 0] < 0.03
        assert abs(recovered_k[1, 1] - camera_matrix[1, 1]) / camera_matrix[1, 1] < 0.03
        assert calibrated["mean_view_reprojection_error_px"] < 0.25

        object_points = np.array(
            [
                [0.0, 0.0, 0.0],
                [50.0, 0.0, 0.0],
                [0.0, 45.0, 0.0],
                [50.0, 45.0, 0.0],
                [0.0, 0.0, 85.0],
                [50.0, 0.0, 85.0],
            ],
            dtype=np.float64,
        )
        rvec_true = np.array([[0.08], [-0.18], [0.04]], dtype=np.float64)
        tvec_true = np.array([[15.0], [8.0], [230.0]], dtype=np.float64)
        image_points, _ = cv2.projectPoints(
            object_points, rvec_true, tvec_true, camera_matrix, distortion
        )
        image_points = image_points.reshape(-1, 2)

        image_path = root / "synthetic.jpg"
        synthetic_image = np.full((height, width, 3), 245, dtype=np.uint8)
        for start, end in [(0, 1), (0, 2), (1, 3), (2, 3), (0, 4), (1, 5), (4, 5)]:
            p1 = tuple(np.rint(image_points[start]).astype(int))
            p2 = tuple(np.rint(image_points[end]).astype(int))
            cv2.line(synthetic_image, p1, p2, (150, 150, 150), 3, cv2.LINE_AA)
        cv2.putText(
            synthetic_image,
            "SYNTHETIC GEOMETRY - NOT A CAPTURED PHOTOGRAPH",
            (45, 70),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.9,
            (20, 20, 180),
            2,
            cv2.LINE_AA,
        )
        cv2.imwrite(str(image_path), synthetic_image)
        calibration_path = root / "calibration.json"
        calibration_path.write_text(
            json.dumps(
                {
                    "camera_matrix": camera_matrix.tolist(),
                    "distortion_coefficients": distortion.tolist(),
                    "image_size_px": [width, height],
                }
            ),
            encoding="utf-8",
        )
        labels = ["O", "A", "B", "C", "D", "E"]
        correspondences_path = root / "correspondences.json"
        correspondences_path.write_text(
            json.dumps(
                {
                    "image": str(image_path),
                    "points": [
                        {
                            "label": label,
                            "object_point_cm": object_point.tolist(),
                            "image_point_px": image_point.tolist(),
                        }
                        for label, object_point, image_point in zip(
                            labels, object_points, image_points
                        )
                    ],
                }
            ),
            encoding="utf-8",
        )
        result_path = root / "result.json"
        true_distance = float(np.linalg.norm(tvec_true))
        command = [
            sys.executable,
            str(Path(__file__).with_name("estimate_pose.py")),
            "--calibration",
            str(calibration_path),
            "--correspondences",
            str(correspondences_path),
            "--true-distance-cm",
            str(true_distance),
            "--output",
            str(result_path),
        ]
        subprocess.run(command, check=True)
        result = json.loads(result_path.read_text(encoding="utf-8"))
        assert abs(result["distance_camera_to_origin_O_cm"] - true_distance) < 1e-4
        assert result["inlier_rmse_px"] < 1e-3
        assert Path(result_path.with_suffix(".jpg")).is_file()
        summary = {
            "purpose": "Synthetic software validation only; not experimental evidence",
            "known_camera_matrix": camera_matrix.tolist(),
            "recovered_camera_matrix": calibrated["camera_matrix"],
            "calibration_rms_reprojection_error_px": calibrated[
                "rms_reprojection_error_px"
            ],
            "calibration_mean_view_reprojection_error_px": calibrated[
                "mean_view_reprojection_error_px"
            ],
            "known_distance_camera_to_origin_O_cm": true_distance,
            "recovered_distance_camera_to_origin_O_cm": result[
                "distance_camera_to_origin_O_cm"
            ],
            "pose_inlier_rmse_px": result["inlier_rmse_px"],
        }
        (root / "synthetic_summary.json").write_text(
            json.dumps(summary, indent=2) + "\n", encoding="utf-8"
        )
        print("Synthetic calibration and pose smoke tests passed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
