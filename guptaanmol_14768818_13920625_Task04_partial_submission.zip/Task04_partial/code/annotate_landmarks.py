#!/usr/bin/env python3
"""Click furniture landmarks in a photograph and save 3D-2D pairs."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import cv2
import numpy as np


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--image", required=True)
    parser.add_argument("--landmarks", required=True, help="CSV columns: label,x_cm,y_cm,z_cm")
    parser.add_argument("--output", required=True, help="Output correspondence JSON")
    parser.add_argument("--annotated-image", help="Defaults beside the JSON output")
    parser.add_argument("--max-display-width", type=int, default=1400)
    return parser.parse_args()


def load_landmarks(path: Path) -> list[dict[str, object]]:
    with path.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    required = {"label", "x_cm", "y_cm", "z_cm"}
    if not rows or not required.issubset(rows[0]):
        raise ValueError(f"{path} must contain columns: {', '.join(sorted(required))}")

    points: list[dict[str, object]] = []
    for row in rows:
        label = row["label"].strip()
        if len(label) != 1 or not label.isupper():
            raise ValueError(f"Landmark labels must be single uppercase letters; got {label!r}")
        points.append(
            {
                "label": label,
                "object_point_cm": [float(row["x_cm"]), float(row["y_cm"]), float(row["z_cm"])],
            }
        )

    labels = [str(point["label"]) for point in points]
    expected = ["O"] + [chr(ord("A") + index) for index in range(len(points) - 1)]
    if labels != expected:
        raise ValueError(f"Labels must be ordered as {expected}; got {labels}")
    if not np.allclose(points[0]["object_point_cm"], [0.0, 0.0, 0.0]):
        raise ValueError("Landmark O must be the object origin (0, 0, 0)")
    geometry = np.asarray([point["object_point_cm"] for point in points], dtype=np.float64)
    if len(points) < 4 or np.linalg.matrix_rank(geometry - geometry[0]) < 3:
        raise ValueError("Use at least four landmarks that are not all coplanar")
    return points


def draw_points(image: np.ndarray, points: list[dict[str, object]], scale: float) -> np.ndarray:
    canvas = image.copy()
    for point in points:
        if "image_point_px" not in point:
            continue
        x, y = point["image_point_px"]
        display_xy = (int(round(float(x) * scale)), int(round(float(y) * scale)))
        cv2.circle(canvas, display_xy, 7, (0, 255, 255), -1, cv2.LINE_AA)
        cv2.circle(canvas, display_xy, 9, (0, 0, 0), 2, cv2.LINE_AA)
        cv2.putText(
            canvas,
            str(point["label"]),
            (display_xy[0] + 10, display_xy[1] - 10),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.8,
            (0, 0, 0),
            4,
            cv2.LINE_AA,
        )
        cv2.putText(
            canvas,
            str(point["label"]),
            (display_xy[0] + 10, display_xy[1] - 10),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.8,
            (0, 255, 255),
            2,
            cv2.LINE_AA,
        )
    return canvas


def main() -> int:
    args = parse_args()
    image_path = Path(args.image)
    original = cv2.imread(str(image_path), cv2.IMREAD_COLOR)
    if original is None:
        raise FileNotFoundError(f"Could not read image: {image_path}")
    points = load_landmarks(Path(args.landmarks))

    scale = min(1.0, args.max_display_width / original.shape[1])
    display = cv2.resize(original, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA)
    clicked = 0
    window = "Landmarks: click O,A,... | u=undo r=reset s=save q=quit"

    def on_mouse(event: int, x: int, y: int, _flags: int, _userdata: object) -> None:
        nonlocal clicked
        if event == cv2.EVENT_LBUTTONDOWN and clicked < len(points):
            points[clicked]["image_point_px"] = [x / scale, y / scale]
            print(f"{points[clicked]['label']}: ({x / scale:.2f}, {y / scale:.2f}) px")
            clicked += 1

    cv2.namedWindow(window, cv2.WINDOW_AUTOSIZE)
    cv2.setMouseCallback(window, on_mouse)
    saved = False
    while True:
        canvas = draw_points(display, points, scale)
        next_label = "done" if clicked == len(points) else str(points[clicked]["label"])
        cv2.putText(canvas, f"Next: {next_label}", (18, 36), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 0, 0), 4)
        cv2.putText(canvas, f"Next: {next_label}", (18, 36), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (255, 255, 255), 2)
        cv2.imshow(window, canvas)
        key = cv2.waitKey(20) & 0xFF
        if key == ord("u") and clicked:
            clicked -= 1
            points[clicked].pop("image_point_px", None)
        elif key == ord("r"):
            for point in points:
                point.pop("image_point_px", None)
            clicked = 0
        elif key == ord("s"):
            if clicked != len(points):
                print(f"Click all {len(points)} landmarks before saving ({clicked} complete).")
                continue
            saved = True
            break
        elif key in (ord("q"), 27):
            break
    cv2.destroyAllWindows()

    if not saved:
        print("No files saved.")
        return 1

    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    payload = {"image": str(image_path), "points": points}
    output_path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")

    annotated_path = Path(args.annotated_image) if args.annotated_image else output_path.with_suffix(".jpg")
    annotated_path.parent.mkdir(parents=True, exist_ok=True)
    full_size_overlay = draw_points(original, points, 1.0)
    cv2.imwrite(str(annotated_path), full_size_overlay)
    print(f"Saved {output_path}")
    print(f"Saved {annotated_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

