Task 04 honest partial submission

Status
------
The empirical experiment was not completed because the team did not have access
to a physical, dimensionally known chessboard or another suitable calibration
target during the available completion period. No personal photographs, real
camera matrix, physical furniture measurements, 3D-2D image correspondences, or
real distance results are claimed.

The answers document explains this limitation. The files under
outputs/synthetic are generated software-test artifacts only and are explicitly
labelled as synthetic. They must not be represented as captured photographs.

Camera intended for the experiment
----------------------------------
Apple iPhone 12 Pro, rear 1x Wide camera.

Implementation
--------------
code/calibrate_camera.py
    Calibrates a pinhole camera from chessboard images and reports errors.

code/annotate_landmarks.py
    Records ordered 3D-to-2D furniture landmark correspondences.

code/estimate_pose.py
    Runs EPnP inside RANSAC, refines the pose, and reports distance to O.

code/smoke_test.py
    Generates and verifies a synthetic calibration and pose problem.

Install and verify
------------------
python3 -m venv .venv
.venv/bin/python -m pip install -r code/requirements.txt
.venv/bin/python code/smoke_test.py

Items not supplied to the document preparer
-------------------------------------------
1. Team names and IDs.
2. An authorized, truthful honor-code declaration.
3. The class K matrix from the restricted Piazza post.
4. A share link for the disclosed OpenAI Codex conversation.

The submitting team should review every document and add only truthful
information before upload.
