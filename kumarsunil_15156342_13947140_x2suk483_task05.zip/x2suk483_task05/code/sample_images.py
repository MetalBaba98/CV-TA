"""
sample_images.py
Pulls example images per breed from the already-downloaded Oxford-IIIT Pet
dataset, so you can pick the image PAIRS for Section 2:
  Factor A (inter-class similarity): two DIFFERENT breeds that look alike
  Factor B (intra-class dissimilarity): two images of the SAME breed that differ
Run (venv active, after extract_embeddings.py):  python sample_images.py
Then browse images/samples/, pick your pairs, copy chosen files up into images/.
"""

import os
from collections import defaultdict
from torchvision.datasets import OxfordIIITPet

HERE = os.path.dirname(__file__)
OUT = os.path.join(HERE, "..", "images", "samples")
os.makedirs(OUT, exist_ok=True)

BREEDS = ["Ragdoll", "Birman", "Siamese", "Sphynx", "Samoyed", "Pug"]  # edit freely
N_PER = 8   # examples saved per breed

ds = OxfordIIITPet(
    root=os.path.join(HERE, "data"),
    split="trainval",
    target_types="category",
    download=False,          # already downloaded by extract_embeddings.py
)
name_to_idx = {c: i for i, c in enumerate(ds.classes)}
want = {name_to_idx[b]: b for b in BREEDS}

saved = defaultdict(int)
for img, label in ds:
    if label in want and saved[label] < N_PER:
        stem = want[label].replace(" ", "_")
        img.convert("RGB").save(os.path.join(OUT, f"{stem}_{saved[label]+1}.jpg"))
        saved[label] += 1
    if all(saved[l] >= N_PER for l in want):
        break

print(f"[saved] {sum(saved.values())} images to {OUT}")
for l, b in want.items():
    print(f"  {b}: {saved[l]} images")