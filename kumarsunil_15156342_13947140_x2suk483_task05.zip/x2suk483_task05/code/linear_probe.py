"""
linear_probe.py
---------------------------------
Task 05, Classification section.

Trains a single multiclass logistic-regression "linear probe" on the frozen
DINOv2 [CLS] embeddings and evaluates it once on the official test split.

- Standardisation is fitted on the TRAINVAL embeddings only, then applied to
  test (no leakage).
- LogisticRegression(max_iter=2000, random_state=42), other params default.
- Reports test accuracy and macro-averaged F1 to four decimal places.

DINOv2 is NOT called here; we only use the saved embeddings.

Run (after extract_embeddings.py):
    python linear_probe.py
"""

import os
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, f1_score

HERE = os.path.dirname(__file__)


def load(split):
    d = np.load(os.path.join(HERE, "embeddings", f"{split}.npz"), allow_pickle=True)
    return d["X"], d["y"]


def main():
    Xtr, ytr = load("trainval")
    Xte, yte = load("test")

    # Standardise using ONLY the training statistics.
    scaler = StandardScaler().fit(Xtr)
    Xtr_s = scaler.transform(Xtr)
    Xte_s = scaler.transform(Xte)

    clf = LogisticRegression(max_iter=2000, random_state=42)
    clf.fit(Xtr_s, ytr)

    pred = clf.predict(Xte_s)
    acc = accuracy_score(yte, pred)
    f1 = f1_score(yte, pred, average="macro")

    print("=== Linear probe (logistic regression) on frozen DINOv2 [CLS] ===")
    print(f"Test Accuracy : {acc:.4f}")
    print(f"Macro F1      : {f1:.4f}")


if __name__ == "__main__":
    main()
