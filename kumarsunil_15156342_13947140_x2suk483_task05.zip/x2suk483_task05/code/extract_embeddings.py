"""
extract_embeddings.py
---------------------------------
Task 05: DINOv2 as a frozen feature extractor on the Oxford-IIIT Pet dataset.

What this script does
  1. Downloads the OxfordIIITPet dataset (trainval + test splits, target_types="category").
  2. Loads the frozen facebook/dinov2-small backbone through Hugging Face AutoModel.
  3. Extracts the final-layer [CLS] embedding for every image.
  4. Prints the tensor SHAPES required in Section 4 of the task (one batch).
  5. Saves embeddings + labels + class names to code/embeddings/ as .npz.

The backbone is used in eval() mode inside torch.no_grad(): no gradients, no
weight updates -> "frozen". DINOv2 is never trained or fine-tuned here.

Run:
    python extract_embeddings.py
Outputs (git-ignored, do NOT submit):
    embeddings/trainval.npz , embeddings/test.npz
"""

import os
import random
import numpy as np
import torch
from torch.utils.data import DataLoader
from torchvision.datasets import OxfordIIITPet
from transformers import AutoImageProcessor, AutoModel

# ---------------------------------------------------------------------------
# Reproducibility: fix every relevant seed to 42.
# ---------------------------------------------------------------------------
SEED = 42
random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)
torch.cuda.manual_seed_all(SEED)

DATA_ROOT = os.path.join(os.path.dirname(__file__), "data")
OUT_DIR = os.path.join(os.path.dirname(__file__), "embeddings")
os.makedirs(OUT_DIR, exist_ok=True)

MODEL_NAME = "facebook/dinov2-small"
BATCH_SIZE = 64

device = "cuda" if torch.cuda.is_available() else "cpu"
print(f"[info] device = {device}")

# ---------------------------------------------------------------------------
# Model + image processor (frozen feature extractor).
# ---------------------------------------------------------------------------
processor = AutoImageProcessor.from_pretrained(MODEL_NAME)
model = AutoModel.from_pretrained(MODEL_NAME).to(device).eval()
for p in model.parameters():          # make "frozen" explicit
    p.requires_grad_(False)


def collate_pil(batch):
    """Dataset returns (PIL image, int label). Keep PIL images for the processor."""
    images = [b[0].convert("RGB") for b in batch]
    labels = torch.tensor([b[1] for b in batch])
    return images, labels


def extract_split(split_name):
    """Extract [CLS] embeddings for one official split."""
    ds = OxfordIIITPet(
        root=DATA_ROOT,
        split=split_name,           # "trainval" or "test"
        target_types="category",    # 37 breed categories
        download=True,
    )
    loader = DataLoader(
        ds, batch_size=BATCH_SIZE, shuffle=False,
        num_workers=4, collate_fn=collate_pil,
    )

    feats, labels = [], []
    printed_shapes = False
    for images, y in loader:
        inputs = processor(images=images, return_tensors="pt").to(device)
        with torch.no_grad():
            out = model(**inputs)
        last_hidden = out.last_hidden_state      # [B, 1+num_patches, hidden]
        cls = last_hidden[:, 0, :]               # [B, hidden]  <- z_i (Eq. in task)

        if not printed_shapes:
            # ---- Section 4, Task Q1: report these SHAPES for one batch ----
            print("\n=== Section 4 tensor shapes (one batch) ===")
            print(f"processed input tensor   : {tuple(inputs['pixel_values'].shape)}")
            print(f"final hidden-state tensor: {tuple(last_hidden.shape)}")
            print(f"[CLS] embedding tensor   : {tuple(cls.shape)}")
            print("===========================================\n")
            printed_shapes = True

        feats.append(cls.cpu().numpy())
        labels.append(y.numpy())

    X = np.concatenate(feats, axis=0)
    y = np.concatenate(labels, axis=0)
    return X, y, ds.classes


def main():
    Xtr, ytr, classes = extract_split("trainval")
    Xte, yte, _ = extract_split("test")

    # ---- Section 2 Q1 & Section 4 Q2: counts and dimensionality ----
    print(f"training (trainval) images : {Xtr.shape[0]}")
    print(f"test images                : {Xte.shape[0]}")
    print(f"number of classes          : {len(classes)}")
    print(f"embedding dimensionality   : {Xtr.shape[1]}")
    print(f"one embedding per image?   : "
          f"{Xtr.shape[0] == len(ytr)} / {Xte.shape[0] == len(yte)}")

    np.savez(os.path.join(OUT_DIR, "trainval.npz"),
             X=Xtr, y=ytr, classes=np.array(classes, dtype=object))
    np.savez(os.path.join(OUT_DIR, "test.npz"),
             X=Xte, y=yte, classes=np.array(classes, dtype=object))
    print(f"\n[info] saved embeddings to {OUT_DIR}/")


if __name__ == "__main__":
    main()
