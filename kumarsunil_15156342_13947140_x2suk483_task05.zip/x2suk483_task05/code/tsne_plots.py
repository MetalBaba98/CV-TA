"""
tsne_plots.py
---------------------------------
Task 05, Section on visualising the embedding space.

Produces two t-SNE plots from the TEST-split [CLS] embeddings:
  Plot 1: coloured by cat-vs-dog super-category  -> images/tsne_catdog.png
  Plot 2: a focused subset of exactly 6 breeds    -> images/tsne_6breeds.png

t-SNE uses random_state=42. Embeddings are standardised (StandardScaler)
before projection; this is stated explicitly in the write-up.

Run (after extract_embeddings.py):
    python tsne_plots.py
"""

import os
import numpy as np
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE
from sklearn.preprocessing import StandardScaler

HERE = os.path.dirname(__file__)
EMB = os.path.join(HERE, "embeddings", "test.npz")
IMG_DIR = os.path.join(HERE, "..", "images")
os.makedirs(IMG_DIR, exist_ok=True)

# The 12 cat breeds of the Oxford-IIIT Pet dataset. Everything else is a dog.
# (Mapping computed from breed names, as permitted by the task.)
CAT_BREEDS = {
    "Abyssinian", "Bengal", "Birman", "Bombay", "British Shorthair",
    "Egyptian Mau", "Maine Coon", "Persian", "Ragdoll", "Russian Blue",
    "Siamese", "Sphynx",
}

# -------------------------------------------------------------------------
# EDIT ME: pick exactly 6 breeds for Plot 2.
# Must include >=2 you called visually SIMILAR and >=2 you expect to be
# visually DISTINCT (Section 2). Use names exactly as they appear in
# `classes` printed below.
# -------------------------------------------------------------------------
#SIX_BREEDS = [
#    # e.g. "Ragdoll", "Birman",            # similar pair (both long-haired, colour-point cats)
#    # e.g. "Bombay", "Sphynx",             # distinct within cats
#    # e.g. "Samoyed", "Pug",               # distinct dogs
#]

SIX_BREEDS = ["Ragdoll", "Birman", "Siamese", "Sphynx", "Samoyed", "Pug"]

def load():
    d = np.load(EMB, allow_pickle=True)
    return d["X"], d["y"], list(d["classes"])


def main():
    X, y, classes = load()
    print("breed classes (index: name):")
    for i, c in enumerate(classes):
        print(f"  {i:2d}: {c}")

    # Standardise, then run a single 2-D t-SNE projection reused by both plots.
    Xs = StandardScaler().fit_transform(X)
    emb2d = TSNE(n_components=2, random_state=42, init="pca").fit_transform(Xs)

    # ---- Plot 1: cat vs dog ------------------------------------------------
    is_cat = np.array([classes[label] in CAT_BREEDS for label in y])
    plt.figure(figsize=(7, 6))
    plt.scatter(emb2d[is_cat, 0], emb2d[is_cat, 1], s=6, alpha=0.6, label="cat")
    plt.scatter(emb2d[~is_cat, 0], emb2d[~is_cat, 1], s=6, alpha=0.6, label="dog")
    plt.legend(markerscale=2)
    plt.title("DINOv2 [CLS] t-SNE (test split): cat vs dog")
    plt.xlabel("t-SNE 1"); plt.ylabel("t-SNE 2"); plt.tight_layout()
    p1 = os.path.join(IMG_DIR, "tsne_catdog.png")
    plt.savefig(p1, dpi=150); plt.close()
    print(f"[saved] {p1}")

    # ---- Plot 2: 6-breed subset -------------------------------------------
    if len(SIX_BREEDS) != 6:
        print("[warn] SIX_BREEDS is not set to exactly 6 breeds -> skipping Plot 2.")
        return
    name_to_idx = {c: i for i, c in enumerate(classes)}
    plt.figure(figsize=(7, 6))
    for breed in SIX_BREEDS:
        idx = name_to_idx[breed]
        m = y == idx
        plt.scatter(emb2d[m, 0], emb2d[m, 1], s=10, alpha=0.75, label=breed)
    plt.legend(markerscale=1.5, fontsize=8)
    plt.title("DINOv2 [CLS] t-SNE (test split): 6-breed subset")
    plt.xlabel("t-SNE 1"); plt.ylabel("t-SNE 2"); plt.tight_layout()
    p2 = os.path.join(IMG_DIR, "tsne_6breeds.png")
    plt.savefig(p2, dpi=150); plt.close()
    print(f"[saved] {p2}")


if __name__ == "__main__":
    main()
