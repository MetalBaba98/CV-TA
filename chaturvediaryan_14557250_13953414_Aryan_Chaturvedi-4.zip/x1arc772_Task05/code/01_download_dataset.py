#!/usr/bin/env python3
# Downloads the Oxford-IIIT Pet Dataset via torchvision and reports basic dataset statistics
import os
from pathlib import Path

import torch
from torchvision.datasets import OxfordIIITPet

# Paths & seed
DATA_ROOT = Path(__file__).resolve().parent.parent / "data" / "oxford-iiit-pet"
DATA_ROOT.mkdir(parents=True, exist_ok=True)

RANDOM_SEED = 42
torch.manual_seed(RANDOM_SEED)

def main():

    # Download and load both official splits using target_types="category" (37 breed labels)
    print(f"\nData will be stored under: {DATA_ROOT}")

    trainval = OxfordIIITPet(
        root=str(DATA_ROOT),
        split="trainval",
        target_types="category",
        download=True,
    )

    test = OxfordIIITPet(
        root=str(DATA_ROOT),
        split="test",
        target_types="category",
        download=True,
    )

    # Reporting the numbers for training images, test images, and the classes
    n_train = len(trainval)
    n_test = len(test)
    n_classes = len(trainval.classes)

    print(f"Number of training (trainval) images: {n_train}")
    print(f"Number of test images: {n_test}")
    print(f"Number of classes: {n_classes}")
    print()
    print("Class names (in label order):")
    for idx, name in enumerate(trainval.classes):
        print(f"  {idx:2d}: {name}")

    # We perform a quick sanity check that the two splits share the same class list
    assert trainval.classes == test.classes, "Train and test class lists differ!"
    print("\nSanity check passed: trainval and test share identical class ordering")

    # We save a text file so later scripts can reuse the ordered class list without having to re-instantiate the dataset
    class_list_path = DATA_ROOT / "class_names.txt"
    with open(class_list_path, "w") as f:
        for name in trainval.classes:
            f.write(name + "\n")
    print(f"\nSaved ordered class list to: {class_list_path}")

if __name__ == "__main__":
    main()
