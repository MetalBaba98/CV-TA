#!/usr/bin/env python3

import os
from pathlib import Path

import matplotlib.pyplot as plt
import torch
from torchvision.datasets import OxfordIIITPet
from torchvision.utils import save_image
from PIL import Image
import numpy as np

# Shared paths and seeds matching
DATA_ROOT = Path(__file__).resolve().parent.parent / "data" / "oxford-iiit-pet"
IMAGES_DIR = Path(__file__).resolve().parent.parent / "images"
IMAGES_DIR.mkdir(parents=True, exist_ok=True)

RANDOM_SEED = 42
torch.manual_seed(RANDOM_SEED)
np.random.seed(RANDOM_SEED)

def load_splits():
    # Load the already-downloaded trainval and test sets
    trainval = OxfordIIITPet(
        root=str(DATA_ROOT),
        split="trainval",
        target_types="category",
        download=False,  # must already exist after download dataset step
    )
    test = OxfordIIITPet(
        root=str(DATA_ROOT),
        split="test",
        target_types="category",
        download=False,
    )
    return trainval, test

def find_indices_for_breed(dataset, breed_name, max_examples=5):
    # Return up to max_examples indices whose label matches the given breed name
    target_idx = dataset.class_to_idx[breed_name]
    indices = [i for i, (_, label) in enumerate(dataset) if label == target_idx]
    return indices[:max_examples]

def save_sample_pair(dataset, idx_a, idx_b, filename_prefix, title_a, title_b):
    # Save two images side-by-side as a single PNG for the report
    img_a, _ = dataset[idx_a]
    img_b, _ = dataset[idx_b]

    fig, axes = plt.subplots(1, 2, figsize=(8, 4))
    axes[0].imshow(img_a)
    axes[0].set_title(title_a, fontsize=10)
    axes[0].axis("off")
    axes[1].imshow(img_b)
    axes[1].set_title(title_b, fontsize=10)
    axes[1].axis("off")
    plt.tight_layout()
    out_path = IMAGES_DIR / f"{filename_prefix}.png"
    plt.savefig(out_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"Saved illustration with path: {out_path}")

def main():

    trainval, test = load_splits()
    classes = trainval.classes
    print(f"\nLoaded {len(trainval)} trainval + {len(test)} test images.")
    print(f"37 breed names available\n")

    # Factor 1 – Inter-class similarity with two different breeds that can be hard to tell apart. We pick Siamese vs Birman both pointed cats, similar colouring and also note British Shorthair vs Russian Blue (both grey short-hair).
    print("Visual factor 1: Inter-class similarity")

    siamese_idxs = find_indices_for_breed(trainval, "Siamese")
    birman_idxs = find_indices_for_breed(trainval, "Birman")
    if siamese_idxs and birman_idxs:
        save_sample_pair(
            trainval,
            siamese_idxs[0],
            birman_idxs[0],
            "interclass_siamese_birman",
            "Siamese (class)",
            "Birman (different class)",
        )

    print("\nVisual factor 2: Intra-class dissimilarity")

    sphynx_idxs = find_indices_for_breed(trainval, "Sphynx", max_examples=10)
    if len(sphynx_idxs) >= 2:
        save_sample_pair(
            trainval,
            sphynx_idxs[0],
            sphynx_idxs[3],  
            "intraclass_sphynx",
            "Sphynx #1",
            "Sphynx #2 (same class)",
        )

    # Recordingthe six breeds we will later visualise with t-SNE
    # Similar pair 1: Siamese & Birman (inter-class similarity)
    # Similar pair 2: British Shorthair & Russian Blue
    # Distinct pair: Sphynx (hairless) vs Persian (long-haired)
    chosen_six = [
        "Siamese",
        "Birman",
        "British Shorthair",
        "Russian Blue",
        "Sphynx",
        "Persian",
    ]
    print("\nSix breeds chosen for the focused t-SNE plot:")
    for b in chosen_six:
        print(f"  - {b}")

    # Persist the list for future use
    six_path = DATA_ROOT / "chosen_six_breeds.txt"
    with open(six_path, "w") as f:
        for b in chosen_six:
            f.write(b + "\n")
    print(f"\nSaved chosen six breeds to: {six_path}")

if __name__ == "__main__":
    main()
