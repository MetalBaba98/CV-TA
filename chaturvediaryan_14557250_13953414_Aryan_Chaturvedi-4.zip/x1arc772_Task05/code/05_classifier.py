#!/usr/bin/env python3

from pathlib import Path

import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score
from sklearn.preprocessing import StandardScaler

# Paths & seed
EMB_DIR = Path(__file__).resolve().parent.parent / "embeddings"

RANDOM_SEED = 42
np.random.seed(RANDOM_SEED)


def main():

    # Load the pre-computed embeddings (no DINOv2 itself called for classifier training)
    X_train = np.load(EMB_DIR / "trainval_embeddings.npy")
    y_train = np.load(EMB_DIR / "trainval_labels.npy")
    X_test = np.load(EMB_DIR / "test_embeddings.npy")
    y_test = np.load(EMB_DIR / "test_labels.npy")

    print(f"Train embeddings : {X_train.shape}")
    print(f"Test  embeddings : {X_test.shape}")

    # Standardise and fit only on the training embeddings 
    print("\nStandardising embeddings (fit on trainval only)")
    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_test = scaler.transform(X_test)          # same transform, no re-fit

    # Train the linear probe
    print("Training LogisticRegression with (max_iter=2000, random_state=42)")
    clf = LogisticRegression(
        max_iter=2000,
        random_state=RANDOM_SEED,
    )
    clf.fit(X_train, y_train)
    print("Training finished")

    # Evaluate once on the official test split
    y_pred = clf.predict(X_test)

    acc = accuracy_score(y_test, y_pred)
    macro_f1 = f1_score(y_test, y_pred, average="macro")

    print("Results:")
    print(f"{'Classifier':<40} {'Test Accuracy':>14} {'Macro F1':>12}")
    print(f"{'Logistic Regression (linear probe)':<40} {acc:14.4f} {macro_f1:12.4f}")

if __name__ == "__main__":
    main()
