#!/usr/bin/env python3

import os
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader
from torchvision.datasets import OxfordIIITPet
from transformers import AutoImageProcessor, AutoModel
from tqdm import tqdm
from PIL import Image

# Paths & seed
DATA_ROOT = Path(__file__).resolve().parent.parent / "data" / "oxford-iiit-pet"
EMB_DIR = Path(__file__).resolve().parent.parent / "embeddings"
EMB_DIR.mkdir(parents=True, exist_ok=True)

RANDOM_SEED = 42
torch.manual_seed(RANDOM_SEED)
np.random.seed(RANDOM_SEED)

BATCH_SIZE = 32
MODEL_NAME = "facebook/dinov2-small"
DEVICE = torch.device("cuda" if torch.cuda.is_available()
                      else "mps" if torch.backends.mps.is_available()
                      else "cpu")


def get_dataloader(split: str):

    dataset = OxfordIIITPet(
        root=str(DATA_ROOT),
        split=split,
        target_types="category",
        download=False,
    )

    # Custom collate: keep images as list of PIL so the processor can handle them
    def collate(batch):
        images, labels = zip(*batch)
        return list(images), torch.tensor(labels, dtype=torch.long)

    loader = DataLoader(
        dataset,
        batch_size=BATCH_SIZE,
        shuffle=False,          # order must stay deterministic
        num_workers=0,          
        collate_fn=collate,
    )
    return loader, dataset


def extract_cls_embeddings(model, processor, loader, device):
    # Run the frozen model over every batch and collect [CLS] vectors.
    model.eval()
    all_embs = []
    all_labels = []

    with torch.no_grad():
        for images, labels in tqdm(loader, desc="Extracting"):
            # Processor turns list-of-PIL into a batch tensor
            inputs = processor(images=images, return_tensors="pt")
            pixel_values = inputs["pixel_values"].to(device)

            # We only need the final hidden states
            outputs = model(pixel_values=pixel_values)
            last_hidden = outputs.last_hidden_state          

            # [CLS] is always at position 0
            cls_emb = last_hidden[:, 0, :]                   

            all_embs.append(cls_emb.cpu().numpy())
            all_labels.append(labels.numpy())

    embeddings = np.concatenate(all_embs, axis=0)
    labels = np.concatenate(all_labels, axis=0)
    return embeddings, labels


def report_shapes(model, processor, device):

    # We Grab two real images for only this demonstration
    ds = OxfordIIITPet(root=str(DATA_ROOT), split="trainval",
                       target_types="category", download=False)
    imgs = [ds[0][0], ds[1][0]]          # two PIL images

    inputs = processor(images=imgs, return_tensors="pt")
    pixel_values = inputs["pixel_values"]                 
    print(f"Processed input tensor (pixel_values) shape: {tuple(pixel_values.shape)}")

    pixel_values = pixel_values.to(device)
    with torch.no_grad():
        outputs = model(pixel_values=pixel_values)
        last_hidden = outputs.last_hidden_state
        cls = last_hidden[:, 0, :]

    print(f"Complete final hidden-state tensor shape: {tuple(last_hidden.shape)}")

    print(f"Extracted [CLS] embedding tensor shape: {tuple(cls.shape)}")

    print(f"\nDimensionality of a single DINOv2-small embedding : {cls.shape[1]}")
    print("Verified: exactly one embedding is produced per image in the batch")

def main():

    # Load processor + model once (frozen)
    print("\nLoading image processor and model from Hugging Face")
    processor = AutoImageProcessor.from_pretrained(MODEL_NAME)
    model = AutoModel.from_pretrained(MODEL_NAME)
    model.to(DEVICE)
    model.eval()          
    # Explicitly freeze every parameter (backbone is frozen)
    for p in model.parameters():
        p.requires_grad = False
    print("Model loaded and frozen successfully")

    # Documenting the shapes and dimensionality
    report_shapes(model, processor, DEVICE)

    # Extract embeddings for both splits
    for split in ("trainval", "test"):
        print(f"\nProcessing split: {split}")
        loader, _ = get_dataloader(split)
        embs, labs = extract_cls_embeddings(model, processor, loader, DEVICE)

        emb_path = EMB_DIR / f"{split}_embeddings.npy"
        lab_path = EMB_DIR / f"{split}_labels.npy"
        np.save(emb_path, embs)
        np.save(lab_path, labs)

        print(f"Saved embeddings: {emb_path}  shape {embs.shape}")
        print(f"Saved labels: {lab_path}  shape {labs.shape}")
        assert embs.shape[0] == labs.shape[0], "Mismatch between embeddings and labels!"
        assert embs.shape[1] == 384, "Expected 384-dim embeddings for dinov2-small"

if __name__ == "__main__":
    main()
