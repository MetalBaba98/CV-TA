#!/usr/bin/env python3

import os
from pathlib import Path

import numpy as np
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE
from sklearn.preprocessing import StandardScaler

# Paths & seed
DATA_ROOT = Path(__file__).resolve().parent.parent / "data" / "oxford-iiit-pet"
EMB_DIR = Path(__file__).resolve().parent.parent / "embeddings"
IMAGES_DIR = Path(__file__).resolve().parent.parent / "images"
IMAGES_DIR.mkdir(parents=True, exist_ok=True)

RANDOM_SEED = 42
np.random.seed(RANDOM_SEED)

# The 12 cat breeds in the Oxford-IIIT Pet dataset (derived from names)
CAT_BREEDS = {
    "Abyssinian", "Bengal", "Birman", "Bombay", "British Shorthair",
    "Egyptian Mau", "Maine Coon", "Persian", "Ragdoll", "Russian Blue",
    "Siamese", "Sphynx",
}


def load_test_data():
    embs = np.load(EMB_DIR / "test_embeddings.npy")
    labels = np.load(EMB_DIR / "test_labels.npy")
    with open(DATA_ROOT / "class_names.txt") as f:
        class_names = [line.strip() for line in f]
    return embs, labels, class_names


def load_chosen_six():
    with open(DATA_ROOT / "chosen_six_breeds.txt") as f:
        return [line.strip() for line in f]


def breed_to_species(breed_name: str) -> str:
    """Map a breed name to the cat / dog super-category (no binary label used)."""
    return "Cat" if breed_name in CAT_BREEDS else "Dog"


def main():

    embs, labels, class_names = load_test_data()
    print(f"Loaded test embeddings: {embs.shape}")

    #Standardising embeddings (zero-mean, unit-variance) before t-SNE
    scaler = StandardScaler()
    embs_scaled = scaler.fit_transform(embs)

    # Compute the 2-D projection once using random_state=42 as required
    print("Running t-SNE")
    tsne = TSNE(
        n_components=2,
        random_state=RANDOM_SEED,
        perplexity=30,
        max_iter=1000,          
        init="pca",
        learning_rate="auto",
    )
    coords = tsne.fit_transform(embs_scaled)
    print(f"t-SNE finished. Coordinate matrix shape: {coords.shape}")

    # Plot 1 – Cat vs Dog
    print("\nCreating Plot 1: Cat vs Dog structure …")
    species = np.array([breed_to_species(class_names[y]) for y in labels])

    fig, ax = plt.subplots(figsize=(8, 7))
    for sp, colour in [("Cat", "#e74c3c"), ("Dog", "#3498db")]:
        mask = species == sp
        ax.scatter(
            coords[mask, 0],
            coords[mask, 1],
            c=colour,
            label=sp,
            alpha=0.55,
            s=12,
            edgecolors="none",
        )
    ax.set_title("t-SNE of DINOv2-small embeddings – Cat vs Dog", fontsize=13)
    ax.set_xlabel("t-SNE dimension 1")
    ax.set_ylabel("t-SNE dimension 2")
    ax.legend(markerscale=2, frameon=True)
    ax.grid(True, alpha=0.25)
    plt.tight_layout()
    out1 = IMAGES_DIR / "tsne_cat_vs_dog.png"
    plt.savefig(out1, dpi=180, bbox_inches="tight")
    plt.close()
    print(f"Plot 1 Saved {out1}")

    # Plot 2 – six focused breeds
    print("\nCreating Plot 2: focused 6-breed subset …")
    chosen = load_chosen_six()
    chosen_idx = {name: class_names.index(name) for name in chosen}

    # Colour map for the six breeds
    colours = ["#e41a1c", "#377eb8", "#4daf4a", "#984ea3", "#ff7f00", "#a65628"]
    fig, ax = plt.subplots(figsize=(9, 7))

    # First draw the non-selected points faintly for context
    selected_mask = np.isin(labels, list(chosen_idx.values()))
    ax.scatter(
        coords[~selected_mask, 0],
        coords[~selected_mask, 1],
        c="lightgrey",
        alpha=0.25,
        s=8,
        label="_nolegend_",
    )

    for (name, colour) in zip(chosen, colours):
        mask = labels == chosen_idx[name]
        ax.scatter(
            coords[mask, 0],
            coords[mask, 1],
            c=colour,
            label=name,
            alpha=0.8,
            s=28,
            edgecolors="k",
            linewidths=0.3,
        )

    ax.set_title("t-SNE of DINOv2-small embeddings on 6 selected breeds", fontsize=13)
    ax.set_xlabel("t-SNE dimension 1")
    ax.set_ylabel("t-SNE dimension 2")
    ax.legend(markerscale=1.3, frameon=True, loc="best")
    ax.grid(True, alpha=0.25)
    plt.tight_layout()
    out2 = IMAGES_DIR / "tsne_six_breeds.png"
    plt.savefig(out2, dpi=180, bbox_inches="tight")
    plt.close()
    print(f"Plot 2 Saved {out2}")

    print("\nBoth t-SNE plots added in the images/ folder")

if __name__ == "__main__":
    main()
