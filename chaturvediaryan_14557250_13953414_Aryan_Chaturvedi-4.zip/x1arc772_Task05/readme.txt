1. Olympus SIS ID
    x1arc772 
	Group ID: 14

2. Which external person (human resource) or TA I consulted:
    None

Environment
A requirements.txt file is included in code folder. Create a virtual environment and install:
  python -m venv .venv
  source .venv/bin/activate  # macOS / Linux
  pip install -r code/requirements.txt

Exact execution order for the code fragmented (and numbered in ordered sequence for ease) as mentioned on Piazza post by Lavanay
From the parent directory that contains the code/ folder:
  python3 code/01_download_dataset.py
  python3 code/02_dataset_analysis.py
  python3 code/03_extract_embeddings.py
  python3 code/04_tsne.py
  python3 code/05_classifier.py
Alternatively: cd into code/ and run the scripts directly

In a nutshell:
The first two scripts create the data/ and images/ directories and perform dataset download, report basic statistics and analyze.
The third script creates embeddings/.
The fourth script writes the two t-SNE PNG files into images/. Plots are reported and aid visualization. 
The fifth script prints the test accuracy and macro-averaged F1 score. Results noted in table.
Device Note: On Apple Silicon the scripts automatically prefer the MPS backend when available; otherwise they fall back to CPU. GPU is not required by the assignment. This note is also added in code. 

Note: data/ and embeddings/ and weights have been omitted for submission but can be recreated using the code or as required

Extra Reproducability Notes: 
- Dataset: Oxford-IIIT Pet
- DINOv2: facebook/dinov2-small
- Train split: trainval
- Test split: test offical
- target_types: category
- Embedding: final-layer CLS
- Embedding dimension: 384
- Logistic Regression: max_iter=2000 and random_state=42
- All random seeds are fixed to 42 (NumPy, PyTorch, scikit-learn).
- The image processor supplied with facebook/dinov2-small produces 224 × 224 inputs (sequence length 257 = 1 CLS + 256 patches). This is the official evaluation setting shipped with the checkpoint.
- Embeddings are standardised; the StandardScaler is fitted only on the trainval set and then applied to the test set.
- The linear probe never calls DINOv2; it operates solely on the saved .npy embedding files.

3. What non-human resources I used on the Internet:
    1. Oxford-IIIT Pet Dataset https://www.robots.ox.ac.uk/~vgg/data/pets/
    2. torchvision.datasets.OxfordIIITPet documentation https://pytorch.org/vision/main/generated/torchvision.datasets.OxfordIIITPet.html
    3. https://www.kaggle.com/datasets/tanlikesmath/the-oxfordiiit-pet-dataset
    4. Mirror copy used only for quick visual querying on web https://huggingface.co/datasets/visual-layer/oxford-iiit-pet-vl-enriched 
    5. facebook/dinov2-small model card (Hugging Face)https://huggingface.co/facebook/dinov2-small
    6. DINOv2 original paper https://arxiv.org/abs/2304.07193 
    7. Official DINOv2 repository (Meta AI / FAIR) https://github.com/facebookresearch/dinov2
    8. scikit-learn TSNE https://scikit-learn.org/stable/modules/generated/sklearn.manifold.TSNE.html
    9. scikit-learn LogisticRegression https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LogisticRegression.html
    10. Hugging Face Transformers – AutoModel / AutoImageProcessor https://huggingface.co/docs/transformers/main/en/model_doc/dinov2
    11. https://pytorch.org/vision/stable/datasets.html
    12. Meta AI blog post introducing DINOv2 https://ai.meta.com/blog/dino-v2-computer-vision-self-supervised-learning/
    13. Google AI Overview "“What is the difference between the [CLS] token and the patch tokens in DINOv2?”
    14. Google AI Overview "Is this statement correct on which cat breeds look very similar to each other? Siamese and Birman seem hard to tell apart and are visually similar" 
    15. Google AI Overview "What are the embedding dimensions for all the variants for Dinov2 model. Is 384 correct."
    16. Google AI Overview "Boilerplate for LogisticRegression max_iter=2000, random_state=42 with StandardScaler fit only on train
    17. Official Python documentation: https://docs.python.org/3/
    18 .OpenCV documentation: https://pypi.org/project/opencv-python/
    19. Python Venv tutorial: https://www.w3schools.com/python/python_virtualenv.asp
    20. Python venv documentation: https://docs.python.org/3/library/venv.html
    21. Simon Prince UDL Transformers Chapter
    22. MIT Foundations of Computer Vision transformers learning

4. I pledge on my honour that I have not given or received any unauthorized assistance on this assignment or any previous task.
    Signed by: Aryan Chaturvedi, x1arc772