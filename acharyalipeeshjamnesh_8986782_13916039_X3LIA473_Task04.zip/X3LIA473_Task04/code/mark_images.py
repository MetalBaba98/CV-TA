import cv2
import numpy as np
import os

PATTERN = (7, 7)

def mark_chessboard(input_path, output_path):
    img = cv2.imread(input_path)
    if img is None:
        raise FileNotFoundError(f"Image not found at {input_path}")
    
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    
    # Try finding corners on full resolution first
    found, corners = cv2.findChessboardCorners(
        gray, PATTERN,
        cv2.CALIB_CB_ADAPTIVE_THRESH + cv2.CALIB_CB_NORMALIZE_IMAGE
    )
    
    # If not found, try downscaling as in run_pnp.py
    if not found:
        small = cv2.resize(gray, None, fx=0.5, fy=0.5)
        found, corners = cv2.findChessboardCorners(
            small, PATTERN,
            cv2.CALIB_CB_ADAPTIVE_THRESH + cv2.CALIB_CB_NORMALIZE_IMAGE
        )
        if found:
            corners *= 2.0
            
    if not found:
        print(f"Warning: Chessboard corners not found in {input_path}")
        return False
        
    corners = cv2.cornerSubPix(
        gray, corners, (11, 11), (-1, -1),
        (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 100, 1e-5)
    )
    
    marked = img.copy()
    cv2.drawChessboardCorners(marked, PATTERN, corners, found)
    cv2.imwrite(output_path, marked)
    print(f"Saved marked chessboard image to {output_path}")
    return True

def mark_chair(input_path, output_path):
    img = cv2.imread(input_path)
    if img is None:
        raise FileNotFoundError(f"Image not found at {input_path}")
        
    landmarks = {
        'A': (557, 926),
        'O': (333, 950),
        'B': (409, 1061),
        'C': (685, 1017),
        'D': (305, 642),
        'E': (690, 654),
        'F': (298, 275),
        'G': (570, 301)
    }
    
    marked = img.copy()
    for label, (u, v) in landmarks.items():
        # Draw red circle
        cv2.circle(marked, (u, v), 8, (0, 0, 255), -1)
        # Draw centered white text label
        (w, h), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.7, 2)
        cv2.putText(marked, label, (u - w // 2, v + h // 2), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
        
    cv2.imwrite(output_path, marked)
    print(f"Saved marked chair image to {output_path}")
    return True

if __name__ == "__main__":
    os.makedirs("images", exist_ok=True)
    mark_chessboard("images/chess_images/d_19cm.jpeg", "images/chess_rep1_marked.jpg")
    mark_chessboard("images/chess_images/d_24cm.jpeg", "images/chess_rep2_marked.jpg")
    mark_chair("images/chair_1.jpeg", "images/chair1_marked.jpg")
