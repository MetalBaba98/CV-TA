import os
import random
import numpy as np
import torch
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, f1_score, classification_report


def set_seed(seed: int = 42):
    """
    Sets global seed across Python, NumPy, and PyTorch to ensure 100% reproducible execution.
    """
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def load_saved_embeddings(data_dir: str):
    """
    Loads extracted DINOv2 embeddings and labels for both trainval and test splits
    from the specified directory path.
    """
    trainval_path = os.path.join(data_dir, "dinov2_embeddings_trainval.pt")
    test_path = os.path.join(data_dir, "dinov2_embeddings_test.pt")

    if not os.path.exists(trainval_path):
        raise FileNotFoundError(f"Trainval embedding file not found at: '{trainval_path}'")
    if not os.path.exists(test_path):
        raise FileNotFoundError(f"Test embedding file not found at: '{test_path}'")

    print(f"Loading 'trainval' split embeddings from: {trainval_path}")
    trainval_payload = torch.load(trainval_path)
    X_trainval = trainval_payload["embeddings"].numpy()
    y_trainval = trainval_payload["labels"].numpy()

    print(f"Loading 'test' split embeddings from:     {test_path}")
    test_payload = torch.load(test_path)
    X_test = test_payload["embeddings"].numpy()
    y_test = test_payload["labels"].numpy()

    classes = trainval_payload.get("classes", [str(i) for i in range(37)])

    print(f"\nSuccessfully loaded dataset splits:")
    print(f"  • Trainval samples: {X_trainval.shape[0]} | Feature dimension: {X_trainval.shape[1]}")
    print(f"  • Test samples:     {X_test.shape[0]} | Feature dimension: {X_test.shape[1]}")
    print(f"  • Total classes:    {len(classes)}")

    return (X_trainval, y_trainval), (X_test, y_test), classes


def preprocess_features(X_trainval: np.ndarray, X_test: np.ndarray):
    """
    Applies StandardScaler (z-score normalization) to standardise features.
    CRITICAL METHODOLOGY REQUIREMENT:
    The scaler is fitted STRICTLY on X_trainval to prevent data leakage from the test split.
    The fitted scaler is then applied to transform both X_trainval and X_test.
    """
    print("\n--- FEATURE PREPROCESSING (STANDARDISATION) ---")
    print("Fitting StandardScaler on 'trainval' embeddings ONLY (preventing data leakage)...")
    scaler = StandardScaler()
    
    # Fit strictly on trainval
    scaler.fit(X_trainval)
    
    # Transform both trainval and test
    X_trainval_scaled = scaler.transform(X_trainval)
    X_test_scaled = scaler.transform(X_test)
    
    print("Standardisation complete: All 384 features scaled to zero mean and unit variance.")
    return X_trainval_scaled, X_test_scaled, scaler


def train_linear_probe(X_trainval: np.ndarray, y_trainval: np.ndarray, seed: int = 42):
    """
    Trains a LogisticRegression classifier with:
      - max_iter=2000
      - random_state=42
      - Default parameters (solver='lbfgs', C=1.0, multi_class='auto')
    """
    print("\n--- TRAINING LINEAR PROBE (LOGISTIC REGRESSION) ---")
    print("Hyperparameters: max_iter=2000, random_state=42, solver='lbfgs', C=1.0")
    
    clf = LogisticRegression(
        max_iter=2000,
        random_state=seed
    )
    
    clf.fit(X_trainval, y_trainval)
    print("Training successfully converged!")
    return clf


def evaluate_linear_probe(clf, X_test: np.ndarray, y_test: np.ndarray, classes: list):
    """
    Evaluates the linear probe once on the official test split and reports
    Test Accuracy and Macro-Averaged F1 Score formatted to 4 decimal places.
    """
    print("\n--- EVALUATING ON HELD-OUT TEST SPLIT ---")
    y_pred = clf.predict(X_test)

    # Compute metric values
    test_acc = accuracy_score(y_test, y_pred)
    macro_f1 = f1_score(y_test, y_pred, average="macro")

    # Format explicitly to 4 decimal places
    acc_formatted = f"{test_acc:.4f}"
    f1_formatted = f"{macro_f1:.4f}"
    acc_percentage = f"{test_acc * 100:.2f}%"
    f1_percentage = f"{macro_f1 * 100:.2f}%"

    print("\n[QUANTITATIVE RESULTS TABLE]")
    print("+" + "-" * 42 + "+" + "-" * 17 + "+" + "-" * 14 + "+")
    print(f"| {'Classifier':<40} | {'Test Accuracy':<15} | {'Macro F1':<12} |")
    print("+" + "-" * 42 + "+" + "-" * 17 + "+" + "-" * 14 + "+")
    print(f"| {'Logistic Regression (linear probe)':<40} | {acc_formatted:<15} | {f1_formatted:<12} |")
    print("+" + "-" * 42 + "+" + "-" * 17 + "+" + "-" * 14 + "+")

    print("\n[SUMMARY OF METRICS (TO 4 DECIMAL PLACES)]")
    print(f"• Test Accuracy:          {acc_formatted}  ({acc_percentage})")
    print(f"• Macro-Averaged F1:      {f1_formatted}  ({f1_percentage})")

    return test_acc, macro_f1


def main():
    SEED = 42
    set_seed(SEED)

    embeddings_dir = "./results/2_dinov2_embeddings_save/embeddings"

    # 1. Load saved trainval and test embeddings
    (X_trainval, y_trainval), (X_test, y_test), classes = load_saved_embeddings(embeddings_dir)

    # 2. Standardise features (fit on trainval ONLY)
    X_trainval_scaled, X_test_scaled, scaler = preprocess_features(X_trainval, X_test)

    # 3. Train Logistic Regression probe
    clf = train_linear_probe(X_trainval_scaled, y_trainval, seed=SEED)

    # 4. Evaluate once on official test split
    evaluate_linear_probe(clf, X_test_scaled, y_test, classes)


if __name__ == "__main__":
    main()
