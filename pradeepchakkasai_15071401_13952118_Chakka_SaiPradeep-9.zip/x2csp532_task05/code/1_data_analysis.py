import matplotlib.pyplot as plt
from torchvision.datasets import OxfordIIITPet

def load_and_inspect_dataset():
    # 1. Download and load trainval and test splits
    train_dataset = OxfordIIITPet(
        root="./data",
        split="trainval",
        target_types="category",
        download=True
    )

    test_dataset = OxfordIIITPet(
        root="./data",
        split="test",
        target_types="category",
        download=True
    )

    # Calculate statistics
    num_train = len(train_dataset)
    num_test = len(test_dataset)
    classes = train_dataset.classes
    num_classes = len(classes)

    print("=== Dataset Summary ===")
    print(f"Number of training images (trainval split): {num_train}")
    print(f"Number of test images (test split): {num_test}")
    print(f"Number of classes: {num_classes}")

    return train_dataset, test_dataset, classes


def find_samples_by_class(dataset):
    """Maps class indices to lists of image indices for easy sampling."""
    class_to_indices = {}
    for idx, (_, label) in enumerate(dataset):
        class_to_indices.setdefault(label, []).append(idx)
    return class_to_indices


def visualize_classification_challenges(dataset, classes):
    """
    Visualizes:
    1. Inter-class similarity: Two different breeds that look visually similar.
    2. Intra-class dissimilarity: Two images of the same breed with distinct visual variations.
    """
    class_to_indices = find_samples_by_class(dataset)
    # print(classes)
    # 1. Inter-class Similarity: Different breeds that look very similar
    # Example: 'american_pit_bull_terrier' vs 'staffordshire_bull_terrier'
    breed_a = "American Pit Bull Terrier"
    breed_b = "Staffordshire Bull Terrier"
    
    idx_a = classes.index(breed_a) if breed_a in classes else 0
    idx_b = classes.index(breed_b) if breed_b in classes else 1

    img_inter_1, _ = dataset[class_to_indices[idx_a][33]]
    img_inter_2, _ = dataset[class_to_indices[idx_b][1]]

    # 2. Intra-class Dissimilarity: Same breed with distinct appearances (e.g., color variation, pose, lighting)
    # Example: 'chihuahua' or 'pomeranian'
    target_breed = "Chihuahua"
    idx_target = classes.index(target_breed) if target_breed in classes else 2

    # Select two samples from the same breed with different visual traits
    img_intra_1, _ = dataset[class_to_indices[idx_target][14]]
    img_intra_2, _ = dataset[class_to_indices[idx_target][65]]

    # Plotting the visual factors
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))

    # Pair 1: Inter-class Similarity
    axes[0, 0].imshow(img_inter_1)
    axes[0, 0].set_title(f"Inter-Class Sim: {classes[idx_a]}")
    axes[0, 0].axis("off")

    axes[0, 1].imshow(img_inter_2)
    axes[0, 1].set_title(f"Inter-Class Sim: {classes[idx_b]}")
    axes[0, 1].axis("off")

    # Pair 2: Intra-class Dissimilarity
    axes[1, 0].imshow(img_intra_1)
    axes[1, 0].set_title(f"Intra-Class Dissim: {classes[idx_target]} ")
    axes[1, 0].axis("off")

    axes[1, 1].imshow(img_intra_2)
    axes[1, 1].set_title(f"Intra-Class Dissim: {classes[idx_target]} ")
    axes[1, 1].axis("off")

    plt.tight_layout()
    plt.savefig("./results/1_data_analysis/breed_classification_challenges.png")
    #plt.show()


if __name__ == "__main__":
    train_dataset, test_dataset, classes = load_and_inspect_dataset()
    visualize_classification_challenges(train_dataset, classes)
