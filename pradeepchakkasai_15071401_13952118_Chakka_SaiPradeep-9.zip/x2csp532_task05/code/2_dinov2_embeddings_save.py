import os
import random
import numpy as np
import torch
from torch.utils.data import DataLoader
from torchvision.datasets import OxfordIIITPet
from transformers import AutoImageProcessor, AutoModel
from tqdm import tqdm


def set_seed(seed: int = 42):
    """
    Sets the random seed across Python, NumPy, and PyTorch to ensure 100% reproducible results.
    """
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)  # Multi-GPU support
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def collate_fn(batch):
    """
    Custom collation function to separate PIL images and labels from dataset tuples.
    """
    images = [item[0] for item in batch]
    labels = torch.tensor([item[1] for item in batch], dtype=torch.long)
    return images, labels


def process_and_save_split(
    split_name: str,
    data_dir: str,
    output_dir: str,
    processor,
    model,
    device: torch.device,
    batch_size: int = 32,
):
    """
    Extracts DINOv2 embeddings for an entire dataset split and saves features,
    labels, and image filenames to a .pt file for downstream tasks.
    """
    print(f"\n--- Processing '{split_name}' split ---")

    # 1. Load Dataset Split
    try:
        dataset = OxfordIIITPet(
            root=data_dir,
            split=split_name,
            target_types="category",
            download=True,
        )
    except Exception as e:
        print(f"Error loading dataset split '{split_name}': {e}")
        return

    dataloader = DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=2,
        collate_fn=collate_fn,
    )

    all_embeddings = []
    all_labels = []
    image_paths = [str(p) for p in dataset._images]

    model.eval()
    with torch.no_grad():
        for batch_images, batch_labels in tqdm(
            dataloader, desc=f"Extracting [{split_name}]"
        ):
            # Preprocess image batch
            inputs = processor(images=batch_images, return_tensors="pt").to(
                device
            )

            # Forward pass through frozen backbone
            outputs = model(**inputs)

            # Extract [CLS] token embedding (shape: [B, Hidden_Dimension])
            cls_embeddings = outputs.last_hidden_state[:, 0, :].cpu()

            all_embeddings.append(cls_embeddings)
            all_labels.append(batch_labels)

    # Stack all batches into single contiguous tensors
    embeddings_tensor = torch.cat(all_embeddings, dim=0)
    labels_tensor = torch.cat(all_labels, dim=0)

    # Store payload dictionary containing features, targets, and metadata
    saved_payload = {
        "embeddings": embeddings_tensor,  # Tensor [N, Hidden_Dim]
        "labels": labels_tensor,  # Tensor [N]
        "image_paths": image_paths,  # List of str [N]
        "classes": dataset.classes,  # List of class names
        "model_name": model.config._name_or_path,
    }

    # Ensure output directory exists
    os.makedirs(output_dir, exist_ok=True)
    save_filepath = os.path.join(output_dir, f"dinov2_embeddings_{split_name}.pt")
    
    torch.save(saved_payload, save_filepath)

    # Reporting summary statistics
    print(f"Saved: {save_filepath}")
    print(f"  - Total samples:    {embeddings_tensor.shape[0]}")
    print(f"  - Embedding shape:  {embeddings_tensor.shape}")
    print(f"  - Labels shape:     {labels_tensor.shape}")


def main():
    SEED = 42
    set_seed(SEED)
    print(f"Global random seed set to: {SEED}")

    data_dir = "./data"
    output_dir = "./results/2_dinov2_embeddings_save/embeddings"
    model_name = "facebook/dinov2-small"
    batch_size = 32

    # Set compute device
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")

    # Load DINOv2 model and processor from Hugging Face
    print(f"Loading processor and model: {model_name}...")
    processor = AutoImageProcessor.from_pretrained(model_name)
    model = AutoModel.from_pretrained(model_name).to(device)

    # Freeze model parameters
    model.eval()
    for param in model.parameters():
        param.requires_grad = False

    # Process both dataset splits
    for split in ["trainval", "test"]:
        process_and_save_split(
            split_name=split,
            data_dir=data_dir,
            output_dir=output_dir,
            processor=processor,
            model=model,
            device=device,
            batch_size=batch_size,
        )

    print("\nExtraction complete! Saved files can now be loaded for downstream tasks.")


if __name__ == "__main__":
    main()
