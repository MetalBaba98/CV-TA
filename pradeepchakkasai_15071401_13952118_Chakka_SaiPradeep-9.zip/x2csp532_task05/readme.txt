1. Olympus SIS ID
X2CSP532
Group ID: 16
Learner ID: Y12

2. Which external person (human resource) or TA I consulted:
None. In order to have maximum learning experience we have done this particular task 100% solo each of us.

3. What non-human resources I used on the Internet:
a. LLM conversation links: 
	1. https://share.gemini.google/NEbBHlj3b1Eh
	2. https://share.gemini.google/8z4bIp7FqnYf

4. I pledge on my honour that I have not given or received any unauthorized
assistance on this assignment or any previous task.
Signed by: Chakka Sai Pradeep, X2CSP532

5. Python commands to reproduce the results:
a. Analyze dataset and visualize classes
> python 1_data_analysis.py > ./results/1_data_analysis/1_data_analysis_output_log.txt

b. Extract and save frozen DINOv2 [CLS] embeddings for trainval and test splits
> python 2_dinov2_embeddings_save.py > ./results/2_dinov2_embeddings_save/2_dinov2_embeddings_save_output_log.txt

c. Compute 2D t-SNE projections and generate diagnostic visualisations - takes the embeddings saved in step b as input.
> python 3_tsne_visualization.py > ./results/3_tsne_visualization/3_tsne_visualization_output_log.txt

d. Train and evaluate the Logistic Regression linear probe classifier - takes the embeddings saved in step b as input.
> python 4_linear_probe.py > ./results/4_linear_probe/4_linear_probe_output_log.txt

