README file for Task - 05

LLM Usage: Google Gemini
Prompt Used: Why is extracting train embeddings taking so much time?
Other external resources used: None

=============================================================================
CSO-610: Task 05 - Measure your transformation!
Execution Instructions
=============================================================================

This directory contains the code to download the Oxford-IIIT Pet dataset, 
extract DINOv2 embeddings, generate t-SNE visualisations, and train a 
linear probe classifier.

-----------------------------------------------------------------------------
1. ENVIRONMENT & DEPENDENCIES
-----------------------------------------------------------------------------
The code is optimized to run on a GPU (e.g., Google Colab T4 GPU or local 
NVIDIA GPU) but will automatically fall back to CPU if no GPU is detected. 

Ensure the following Python packages are installed (these can also be found 
in code/requirements.txt):
- torch >= 2.0.0
- torchvision >= 0.15.0
- transformers >= 4.30.0
- scikit-learn >= 1.2.0
- matplotlib >= 3.7.0
- numpy >= 1.24.0
- pillow >= 9.0.0

To install dependencies locally, run:
pip install -r code/requirements.txt

-----------------------------------------------------------------------------
2. HOW TO REPRODUCE RESULTS (GOOGLE COLAB / JUPYTER NOTEBOOK) (Done here)
-----------------------------------------------------------------------------
If you are reviewing this code via a Jupyter Notebook (.ipynb file) in Colab:
1. Upload the notebook to Google Colab.
2. Go to "Runtime" > "Change runtime type" > Select "T4 GPU" > Save.
3. Click "Runtime" > "Run all".
4. The notebook will sequentially:
   - Create the necessary 'images/' directory.
   - Download the Oxford-IIIT Pet dataset into a local './data' folder.
   - Extract the [CLS] embeddings using facebook/dinov2-small.
   - Print the exact tensor shapes for Task 3.1.
   - Generate and save 'cat_vs_dog_tsne.png' and '6_breed_subset_tsne.png' 
     to the 'images/' folder.
   - Print the final Test Accuracy and Macro F1 score to the console.

-----------------------------------------------------------------------------
3. HOW TO REPRODUCE RESULTS (COMMAND LINE / TERMINAL)
-----------------------------------------------------------------------------
If you are executing the consolidated Python script:
1. Open your terminal or command prompt.
2. Navigate to the root directory of this submission (25v009_Task05/).
3. Execute the script using the following command:
   
   python code/main.py 
   
   (Note: Replace 'main.py' with the exact name of the python file if 
   saved differently).

4. Check the console output for tensor shapes and classification metrics. 
   Check the 'images/' directory for the generated t-SNE plots.

-----------------------------------------------------------------------------
NOTES FOR REPRODUCIBILITY
-----------------------------------------------------------------------------
- All random seeds for t-SNE and Logistic Regression are explicitly set 
  to random_state=42.
- No pre-extracted embeddings, weights, or datasets are included in this 
  folder as per submission guidelines; the script will download and 
  process everything dynamically.

(Code name: model-actions.ipynb)

-----------------------------------------------------------------------------