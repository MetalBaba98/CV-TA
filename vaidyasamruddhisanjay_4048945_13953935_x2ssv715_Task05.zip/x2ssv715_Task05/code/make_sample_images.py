"""Step 3: build the Section 2 sample-image figures.

Two figures are produced, one per visual factor:

1. Inter-class similarity: the American Pit Bull Terrier / Staffordshire Bull
   Terrier pair whose *raw colour statistics* are closest to each other. Two
   images from two different breeds that a human can barely tell apart.
2. Intra-class dissimilarity: the two American Pit Bull Terrier images whose
   raw colour statistics are furthest apart. Two images from the *same* breed
   that look nothing alike.

The pair selection deliberately uses only 8x8x8 RGB colour histograms and a
chi-square distance, i.e. a cue that is completely independent of DINOv2, so
the figures are not cherry-picked using the representation we are evaluating.
A third figure shows one representative image for each of the 6 breeds used in
t-SNE Plot 2.
"""

from __future__ import annotations

from itertools import product

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image

import config
from download_data import load_split

MAX_PER_BREED = 60      # keep the pairwise search cheap
HIST_BINS = 8


def color_histogram(path) -> np.ndarray:
    img = Image.open(path).convert("RGB").resize((128, 128))
    arr = np.asarray(img).reshape(-1, 3)
    idx = (arr // (256 // HIST_BINS)).astype(np.int64)
    flat = idx[:, 0] * HIST_BINS ** 2 + idx[:, 1] * HIST_BINS + idx[:, 2]
    hist = np.bincount(flat, minlength=HIST_BINS ** 3).astype(np.float64)
    return hist / hist.sum()


def chi2(a: np.ndarray, b: np.ndarray) -> float:
    return float(0.5 * np.sum((a - b) ** 2 / (a + b + 1e-10)))


def breed_paths(dataset, breed: str):
    label = dataset.classes.index(breed)
    paths = [p for p, y in zip(dataset._images, dataset._labels) if y == label]
    return paths[:MAX_PER_BREED]


def show_pair(paths, titles, out_name, suptitle):
    fig, axes = plt.subplots(1, 2, figsize=(8, 4.2))
    for ax, p, t in zip(axes, paths, titles):
        ax.imshow(Image.open(p).convert("RGB"))
        ax.set_title(t, fontsize=11)
        ax.axis("off")
        ax.set_anchor("N")   # top-align both panels so the titles line up
    fig.suptitle(suptitle, fontsize=12)
    fig.tight_layout()
    out = config.IMAGES_DIR / out_name
    fig.savefig(out, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"wrote {out}")


def main() -> None:
    config.ensure_dirs()
    config.set_all_seeds()
    ds = load_split("trainval", download=False)

    breed_a, breed_b = config.SIMILAR_PAIR_DOGS
    paths_a, paths_b = breed_paths(ds, breed_a), breed_paths(ds, breed_b)
    hist_a = [color_histogram(p) for p in paths_a]
    hist_b = [color_histogram(p) for p in paths_b]

    # --- Factor 1: inter-class similarity (closest cross-breed pair) ---
    best = min(
        product(range(len(paths_a)), range(len(paths_b))),
        key=lambda ij: chi2(hist_a[ij[0]], hist_b[ij[1]]),
    )
    show_pair(
        [paths_a[best[0]], paths_b[best[1]]],
        [config.pretty(breed_a), config.pretty(breed_b)],
        "factor1_interclass_similarity.png",
        "Factor 1 - inter-class similarity: two different breeds, near-identical appearance",
    )

    # --- Factor 2: intra-class dissimilarity (furthest same-breed pair) ---
    paths_c = breed_paths(ds, config.INTRA_CLASS_BREED)
    hist_c = [color_histogram(p) for p in paths_c]
    worst = max(
        ((i, j) for i in range(len(paths_c)) for j in range(i + 1, len(paths_c))),
        key=lambda ij: chi2(hist_c[ij[0]], hist_c[ij[1]]),
    )
    label = config.pretty(config.INTRA_CLASS_BREED)
    show_pair(
        [paths_c[worst[0]], paths_c[worst[1]]],
        [f"{label} (a)", f"{label} (b)"],
        "factor2_intraclass_dissimilarity.png",
        "Factor 2 - intra-class dissimilarity: same breed, very different appearance",
    )

    # --- Context figure: the 6 breeds used in t-SNE Plot 2 ---
    fig, axes = plt.subplots(2, 3, figsize=(10.5, 7.2))
    for ax, breed in zip(axes.ravel(), config.SIX_BREEDS):
        ax.imshow(Image.open(breed_paths(ds, breed)[0]).convert("RGB"))
        kind = "cat" if config.is_cat(breed) else "dog"
        ax.set_title(f"{config.pretty(breed)} ({kind})", fontsize=10)
        ax.axis("off")
        ax.set_anchor("N")
    fig.suptitle("The 6 breeds selected for t-SNE Plot 2", fontsize=12)
    fig.tight_layout()
    out = config.IMAGES_DIR / "six_breeds_examples.png"
    fig.savefig(out, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"wrote {out}")


if __name__ == "__main__":
    main()
