"""Step 1: download the Oxford-IIIT Pet dataset and report basic statistics.

The images are hosted at https://www.robots.ox.ac.uk/~vgg/data/pets/ ; the
torchvision wrapper simply fetches images.tar.gz and annotations.tar.gz from
there. We only ever ask for target_types="category" (the 37-way breed label).
"""

from __future__ import annotations

from torchvision.datasets import OxfordIIITPet

import config


def load_split(split: str, download: bool = True) -> OxfordIIITPet:
    return OxfordIIITPet(
        root=str(config.DATA_ROOT),
        split=split,
        target_types="category",
        download=download,
    )


def main() -> None:
    config.ensure_dirs()
    trainval = load_split("trainval")
    test = load_split("test")

    lines = [
        "Oxford-IIIT Pet, target_types='category'",
        f"trainval images : {len(trainval)}",
        f"test images     : {len(test)}",
        f"num classes     : {len(trainval.classes)}",
        f"classes         : {trainval.classes}",
    ]
    report = "\n".join(lines)
    print(report)
    (config.ARTIFACT_DIR / "dataset_stats.txt").write_text(report + "\n")


if __name__ == "__main__":
    main()
