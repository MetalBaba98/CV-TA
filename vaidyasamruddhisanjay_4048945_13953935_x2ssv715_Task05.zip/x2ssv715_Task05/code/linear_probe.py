"""Step 5: linear probe on the frozen embeddings.

Multiclass logistic regression trained on the trainval [CLS] embeddings only and
evaluated exactly once on the official test split. DINOv2 is never called here:
the script reads the .npy files produced by extract_embeddings.py.

Features are standardised with a StandardScaler that is fitted on the trainval
embeddings only and then applied unchanged to the test embeddings (no test
statistics leak into the transform).
"""

from __future__ import annotations

import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, classification_report,
                             confusion_matrix, f1_score)
from sklearn.preprocessing import StandardScaler

import config


def main() -> None:
    config.ensure_dirs()
    config.set_all_seeds()

    X_tr = np.load(config.ARTIFACT_DIR / "X_trainval.npy")
    y_tr = np.load(config.ARTIFACT_DIR / "y_trainval.npy")
    X_te = np.load(config.ARTIFACT_DIR / "X_test.npy")
    y_te = np.load(config.ARTIFACT_DIR / "y_test.npy")
    classes = [str(c) for c in np.load(config.ARTIFACT_DIR / "classes.npy")]

    scaler = StandardScaler().fit(X_tr)          # fitted on trainval only
    X_tr_s = scaler.transform(X_tr)
    X_te_s = scaler.transform(X_te)

    clf = LogisticRegression(max_iter=config.LOGREG_MAX_ITER,
                             random_state=config.LOGREG_RANDOM_STATE)
    clf.fit(X_tr_s, y_tr)

    y_pred = clf.predict(X_te_s)
    acc = accuracy_score(y_te, y_pred)
    macro_f1 = f1_score(y_te, y_pred, average="macro")

    lines = [
        "Linear probe: LogisticRegression on frozen DINOv2-small [CLS] features",
        f"train (trainval) X : {X_tr.shape}",
        f"test X             : {X_te.shape}",
        f"classes            : {len(classes)}",
        f"preprocessing      : StandardScaler fitted on trainval only",
        f"solver / max_iter  : {clf.solver} / {config.LOGREG_MAX_ITER}",
        f"random_state       : {config.LOGREG_RANDOM_STATE}",
        f"iterations used    : {np.max(clf.n_iter_)}",
        f"train accuracy     : {accuracy_score(y_tr, clf.predict(X_tr_s)):.4f}",
        "",
        f"TEST ACCURACY      : {acc:.4f}",
        f"TEST MACRO F1      : {macro_f1:.4f}",
        "",
        classification_report(y_te, y_pred, target_names=classes, digits=4,
                              zero_division=0),
    ]

    # How often are the two look-alike breeds of Section 2 confused?
    cm = confusion_matrix(y_te, y_pred, labels=list(range(len(classes))))
    for a, b in (config.SIMILAR_PAIR_DOGS, config.SIMILAR_PAIR_CATS,
                 config.DISSIMILAR_PAIR_DOGS):
        ia, ib = classes.index(a), classes.index(b)
        lines.append(
            f"confusions  {config.pretty(a)} -> {config.pretty(b)} : {cm[ia, ib]} "
            f"of {cm[ia].sum()}   |   {config.pretty(b)} -> {config.pretty(a)} : "
            f"{cm[ib, ia]} of {cm[ib].sum()}"
        )

    report = "\n".join(lines)
    print(report)
    (config.ARTIFACT_DIR / "linear_probe_results.txt").write_text(report + "\n")


if __name__ == "__main__":
    main()
