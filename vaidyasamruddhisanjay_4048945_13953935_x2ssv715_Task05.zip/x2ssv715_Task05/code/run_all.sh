#!/usr/bin/env bash
# Reproduce every number and figure reported in answers.pdf, in order.
# Run from inside this code/ directory:  bash run_all.sh
set -euo pipefail

python download_data.py        # downloads Oxford-IIIT Pet, prints split sizes / #classes
python extract_embeddings.py   # frozen DINOv2-small [CLS] features, prints all tensor shapes
python make_sample_images.py   # Section 2 sample-image figures
python tsne_plots.py           # t-SNE (random_state=42): cat/dog plot + 6-breed plot
python linear_probe.py         # logistic-regression linear probe: accuracy + macro F1

echo
echo "Figures  -> ../images/"
echo "Numbers  -> ../convincingDirectory/{dataset_stats,shapes,tsne_info,linear_probe_results}.txt"
