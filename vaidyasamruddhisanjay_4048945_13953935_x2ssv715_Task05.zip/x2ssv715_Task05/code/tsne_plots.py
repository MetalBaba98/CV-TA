"""Step 4: t-SNE visualisation of the frozen DINOv2 embedding space (test split).

One single 2-D t-SNE projection of all test-split [CLS] embeddings is computed
with random_state=42 and then re-used for both plots, so the two figures are
literally the same map with different colouring:

  Plot 1  every test point coloured by its cat/dog super-category, which is
          derived from the breed name only (config.CAT_BREEDS), never from the
          dataset's binary label field;
  Plot 2  only the 6 selected breeds are drawn in colour, the remaining points
          stay light grey for context.

Embeddings are standardised (zero mean, unit variance per dimension) before
t-SNE; this is a purely unsupervised, per-feature linear rescaling of the test
embeddings and is stated explicitly in the report.
"""

from __future__ import annotations

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from sklearn.manifold import TSNE
from sklearn.preprocessing import StandardScaler

import config

MARKERS = ["o", "s", "^", "D", "v", "P"]


def main() -> None:
    config.ensure_dirs()
    config.set_all_seeds()

    X = np.load(config.ARTIFACT_DIR / "X_test.npy")
    y = np.load(config.ARTIFACT_DIR / "y_test.npy")
    classes = list(np.load(config.ARTIFACT_DIR / "classes.npy"))
    print(f"test embeddings: {X.shape}, labels: {y.shape}, classes: {len(classes)}")

    X_std = StandardScaler().fit_transform(X)
    tsne = TSNE(n_components=2, random_state=config.TSNE_RANDOM_STATE)
    Z = tsne.fit_transform(X_std)
    np.save(config.ARTIFACT_DIR / "tsne_test_2d.npy", Z)
    print(f"t-SNE done: {Z.shape}, KL divergence = {tsne.kl_divergence_:.4f}")

    # ---------------- Plot 1: cat vs dog ----------------
    is_cat_mask = np.array([config.is_cat(classes[i]) for i in y])
    fig, ax = plt.subplots(figsize=(8, 7))
    ax.scatter(Z[~is_cat_mask, 0], Z[~is_cat_mask, 1], s=7, alpha=0.6,
               c="#1f77b4", label=f"Dog ({(~is_cat_mask).sum()} images, 25 breeds)")
    ax.scatter(Z[is_cat_mask, 0], Z[is_cat_mask, 1], s=7, alpha=0.6,
               c="#d62728", label=f"Cat ({is_cat_mask.sum()} images, 12 breeds)")
    ax.set_title("t-SNE of frozen DINOv2-small [CLS] embeddings (test split)\n"
                 "coloured by cat vs. dog super-category", fontsize=12)
    ax.set_xlabel("t-SNE dimension 1")
    ax.set_ylabel("t-SNE dimension 2")
    ax.legend(loc="best", frameon=True, markerscale=2.5)
    fig.tight_layout()
    out1 = config.IMAGES_DIR / "tsne_cat_vs_dog.png"
    fig.savefig(out1, dpi=200)
    plt.close(fig)
    print(f"wrote {out1}")

    # ---------------- Plot 2: 6-breed subset ----------------
    six_ids = [classes.index(b) for b in config.SIX_BREEDS]
    subset_mask = np.isin(y, six_ids)

    fig, ax = plt.subplots(figsize=(8.5, 7))
    ax.scatter(Z[~subset_mask, 0], Z[~subset_mask, 1], s=5, c="#dcdcdc",
               alpha=0.7, label="other 31 breeds (context)")
    cmap = plt.get_cmap("tab10")
    for k, (breed, cid) in enumerate(zip(config.SIX_BREEDS, six_ids)):
        m = y == cid
        ax.scatter(Z[m, 0], Z[m, 1], s=32, marker=MARKERS[k], color=cmap(k),
                   edgecolors="black", linewidths=0.3, alpha=0.9,
                   label=f"{config.pretty(breed)} (n={m.sum()})")
    ax.set_title("t-SNE of frozen DINOv2-small [CLS] embeddings (test split)\n"
                 "same projection, restricted to 6 selected breeds", fontsize=12)
    ax.set_xlabel("t-SNE dimension 1")
    ax.set_ylabel("t-SNE dimension 2")
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.09), ncol=2,
              frameon=True, fontsize=9)
    fig.tight_layout()
    out2 = config.IMAGES_DIR / "tsne_six_breeds.png"
    fig.savefig(out2, dpi=200, bbox_inches="tight")
    plt.close(fig)
    print(f"wrote {out2}")

    (config.ARTIFACT_DIR / "tsne_info.txt").write_text(
        f"t-SNE on standardised test embeddings\n"
        f"input shape           : {X.shape}\n"
        f"random_state          : {config.TSNE_RANDOM_STATE}\n"
        f"perplexity            : {tsne.perplexity}\n"
        f"init / learning_rate  : {tsne.init} / {tsne.learning_rate}\n"
        f"n_iter run            : {tsne.n_iter_}\n"
        f"KL divergence         : {tsne.kl_divergence_:.6f}\n"
        f"cat images            : {int(is_cat_mask.sum())}\n"
        f"dog images            : {int((~is_cat_mask).sum())}\n"
        f"six-breed images      : {int(subset_mask.sum())}\n"
    )


if __name__ == "__main__":
    main()
