"""Step 2: extract frozen DINOv2-small [CLS] embeddings for both official splits.

The backbone is used strictly as a feature extractor:
  * weights are loaded from the pretrained checkpoint and never updated,
  * the module is put in eval() mode and every parameter has requires_grad=False,
  * all forward passes happen inside torch.no_grad().

For image i we keep only the final-layer global token
    z_i = last_hidden_state[i, 0, :]
and write the resulting (N, 384) matrices to disk so that no later step ever
has to call DINOv2 again.

Usage:
    python extract_embeddings.py [--device auto|cpu|mps|cuda] [--batch-size 32]
"""

from __future__ import annotations

import argparse
import time

import numpy as np
import torch
from transformers import AutoImageProcessor, AutoModel

import config
from download_data import load_split


def pick_device(requested: str) -> torch.device:
    if requested != "auto":
        return torch.device(requested)
    if torch.cuda.is_available():
        return torch.device("cuda")
    if torch.backends.mps.is_available():
        return torch.device("mps")
    return torch.device("cpu")


def pil_collate(batch):
    """Keep PIL images as a plain list; the HF image processor batches them."""
    images = [item[0].convert("RGB") for item in batch]
    labels = [item[1] for item in batch]
    return images, labels


@torch.no_grad()
def extract_split(split: str, processor, model, device, batch_size: int, shape_log: list):
    dataset = load_split(split, download=False)
    loader = torch.utils.data.DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=0,
        collate_fn=pil_collate,
    )

    all_embeddings, all_labels = [], []
    t0 = time.time()
    for batch_idx, (images, labels) in enumerate(loader):
        inputs = processor(images=images, return_tensors="pt")
        pixel_values = inputs["pixel_values"].to(device)
        outputs = model(pixel_values=pixel_values)
        hidden = outputs.last_hidden_state           # (B, 1 + num_patches, D)
        cls = hidden[:, 0, :]                        # (B, D)

        if batch_idx == 0:
            shape_log.append(
                f"[{split}] processed input tensor (pixel_values) : {tuple(pixel_values.shape)}\n"
                f"[{split}] final hidden state                    : {tuple(hidden.shape)}\n"
                f"[{split}] extracted [CLS] embeddings            : {tuple(cls.shape)}\n"
                f"[{split}] embedding dimensionality D            : {cls.shape[1]}\n"
                f"[{split}] embeddings per image                  : "
                f"{cls.shape[0] // len(images)} (batch has {len(images)} images, "
                f"{cls.shape[0]} rows)\n"
            )

        all_embeddings.append(cls.float().cpu().numpy())
        all_labels.extend(labels)

        if batch_idx % 20 == 0:
            done = batch_idx * batch_size
            print(f"  {split}: {done}/{len(dataset)} images ({time.time() - t0:.1f}s)", flush=True)

    embeddings = np.concatenate(all_embeddings, axis=0)
    labels = np.asarray(all_labels, dtype=np.int64)
    assert embeddings.shape[0] == len(dataset) == labels.shape[0], (
        "expected exactly one embedding per image"
    )
    print(f"  {split}: done, X={embeddings.shape}, y={labels.shape} "
          f"in {time.time() - t0:.1f}s", flush=True)
    return embeddings, labels, dataset.classes


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--device", default="auto")
    parser.add_argument("--batch-size", type=int, default=config.BATCH_SIZE)
    args = parser.parse_args()

    config.ensure_dirs()
    config.set_all_seeds()

    device = pick_device(args.device)
    print(f"device = {device}")

    # use_fast=False pins the original ("slow") PIL-based preprocessing that was
    # saved with the checkpoint, so results do not drift with transformers
    # versions that switch the default to the fast torchvision path.
    processor = AutoImageProcessor.from_pretrained(config.MODEL_NAME, use_fast=False)
    model = AutoModel.from_pretrained(config.MODEL_NAME)
    model.eval().to(device)
    for p in model.parameters():
        p.requires_grad_(False)

    n_params = sum(p.numel() for p in model.parameters())
    n_trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)

    shape_log = [
        f"model              : {config.MODEL_NAME}",
        f"hidden size (D)    : {model.config.hidden_size}",
        f"patch size         : {model.config.patch_size}",
        f"num hidden layers  : {model.config.num_hidden_layers}",
        f"total parameters   : {n_params:,}",
        f"trainable params   : {n_trainable:,}  (frozen backbone)",
        f"processor config   : {processor.size}, crop={getattr(processor, 'crop_size', None)}",
        f"device             : {device}",
        f"batch size         : {args.batch_size}",
        "",
    ]

    for split in ("trainval", "test"):
        X, y, classes = extract_split(split, processor, model, device,
                                      args.batch_size, shape_log)
        np.save(config.ARTIFACT_DIR / f"X_{split}.npy", X)
        np.save(config.ARTIFACT_DIR / f"y_{split}.npy", y)
        np.save(config.ARTIFACT_DIR / "classes.npy", np.asarray(classes))

    (config.ARTIFACT_DIR / "shapes.txt").write_text("\n".join(shape_log))
    print("\n".join(shape_log))


if __name__ == "__main__":
    main()
