"""Shared configuration for Task 05 (DINOv2 frozen features on Oxford-IIIT Pet).

Every script imports its paths, seeds and breed choices from here so that the
whole pipeline is driven by a single source of truth.
"""

from __future__ import annotations

import os
import random
from pathlib import Path

import numpy as np

SEED = 42
TSNE_RANDOM_STATE = 42
LOGREG_RANDOM_STATE = 42
LOGREG_MAX_ITER = 2000

MODEL_NAME = "facebook/dinov2-small"
BATCH_SIZE = 32

PROJECT_DIR = Path(__file__).resolve().parent.parent
DATA_ROOT = Path(os.environ.get("PET_DATA_ROOT", PROJECT_DIR / "data"))
ARTIFACT_DIR = Path(os.environ.get("PET_ARTIFACT_DIR", PROJECT_DIR / "convincingDirectory"))
IMAGES_DIR = PROJECT_DIR / "images"

# The 6 breeds used for t-SNE Plot 2. Names are spelled exactly as they appear
# in torchvision's OxfordIIITPet.classes. Two near-duplicate dog breeds, two
# near-duplicate spotted cat breeds, and two dog breeds that are extremely
# different in size and coat even though both are dogs.
SIMILAR_PAIR_DOGS = ("American Pit Bull Terrier", "Staffordshire Bull Terrier")
SIMILAR_PAIR_CATS = ("Bengal", "Egyptian Mau")
DISSIMILAR_PAIR_DOGS = ("Chihuahua", "Great Pyrenees")
SIX_BREEDS = SIMILAR_PAIR_DOGS + SIMILAR_PAIR_CATS + DISSIMILAR_PAIR_DOGS

# Breed used to illustrate intra-class dissimilarity (one breed, two very
# different-looking individuals).
INTRA_CLASS_BREED = "American Pit Bull Terrier"

# Cat vs dog super-category. In the raw Oxford-IIIT Pet annotation files the 12
# cat breeds are exactly the ones whose image-id starts with an upper-case
# letter (e.g. "Abyssinian_1.jpg") while the 25 dog breeds are lower-case
# (e.g. "american_pit_bull_terrier_1.jpg"), so the mapping is derivable from the
# breed name alone -- we never touch the dataset's binary label field. The
# explicit list below is used because torchvision title-cases `classes`, which
# destroys that casing cue; is_cat_from_image_id() recovers it from the raw file
# name and the two are cross-checked against each other in the code.
CAT_BREEDS = {
    "Abyssinian",
    "Bengal",
    "Birman",
    "Bombay",
    "British Shorthair",
    "Egyptian Mau",
    "Maine Coon",
    "Persian",
    "Ragdoll",
    "Russian Blue",
    "Siamese",
    "Sphynx",
}


def is_cat(breed_name: str) -> bool:
    """Cat vs dog super-category, derived from the breed name only."""
    return breed_name in CAT_BREEDS


def is_cat_from_image_id(image_id: str) -> bool:
    """Same mapping, recovered from the raw image-id casing (e.g. 'Bengal_12')."""
    return image_id[0].isupper()


def pretty(breed_name: str) -> str:
    """Display form of a breed name (torchvision names are already readable)."""
    return breed_name.replace("_", " ")


def set_all_seeds(seed: int = SEED) -> None:
    import torch

    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)


def ensure_dirs() -> None:
    for d in (DATA_ROOT, ARTIFACT_DIR, IMAGES_DIR):
        d.mkdir(parents=True, exist_ok=True)
