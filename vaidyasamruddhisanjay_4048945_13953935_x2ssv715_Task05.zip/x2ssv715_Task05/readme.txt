================================================================================
Task 05: Measure your transformation!   (CSO-610, Summer 2025-26)
DINOv2-small as a frozen feature extractor on the Oxford-IIIT Pet dataset
================================================================================

--------------------------------------------------------------------------------
HONOUR CODE AND DECLARATIONS
--------------------------------------------------------------------------------
1. Olympus SIS ID
    x2ssv715

2. Group ID
    11

3. Which external person (human resource) or TA I consulted:
    None

4. What non-human resources I used on the Internet:
   a. Official documentation only, for API details:
      - torchvision.datasets.OxfordIIITPet  (split, target_types, download)
        https://docs.pytorch.org/vision/stable/generated/torchvision.datasets.OxfordIIITPet.html
      - Hugging Face DINOv2 docs  (AutoImageProcessor, AutoModel, last_hidden_state)
        https://huggingface.co/docs/transformers/model_doc/dinov2
      - scikit-learn docs for TSNE, LogisticRegression, StandardScaler, metrics
      - Oxford-IIIT Pet dataset page, to see where the data is actually hosted
        https://www.robots.ox.ac.uk/~vgg/data/pets/
        (the files images.tar.gz and annotations.tar.gz are served from
        https://thor.robots.ox.ac.uk/~vgg/data/pets/, which is what torchvision
        fetches)

   b. LLM assistance: Cursor IDE agent (Anthropic Claude model)

5. I pledge on my honour that I have not given or received any unauthorized
   assistance on this assignment or any previous task.
    Signed by: <Samruddhi Vaidya, x2ssv715>


--------------------------------------------------------------------------------
ENVIRONMENT
--------------------------------------------------------------------------------
Python 3.9.6, macOS 15 (Darwin 25.5.0), Apple silicon (arm64).
No GPU required: the reported run used the CPU (extract_embeddings.py picks the
best available device automatically and printed "device = cpu"). Pass
--device mps or --device cuda to use an accelerator; results are identical up to
float round-off.

Package versions (also in code/requirements.txt):
    torch==2.8.0
    torchvision==0.23.0
    transformers==4.57.6
    scikit-learn==1.6.1
    numpy==2.0.2
    matplotlib==3.9.4
    Pillow==11.3.0

Install with:
    python -m venv .venv && source .venv/bin/activate
    pip install -r code/requirements.txt


--------------------------------------------------------------------------------
HOW TO REPRODUCE EVERY NUMBER AND FIGURE (exact execution order)
--------------------------------------------------------------------------------
All commands are run from inside the code/ directory:

    cd code
    python download_data.py        # step 1: download dataset, print split sizes and #classes
    python extract_embeddings.py   # step 2: frozen DINOv2-small [CLS] features + all tensor shapes
    python make_sample_images.py   # step 3: Section 2 sample-image figures
    python tsne_plots.py           # step 4: t-SNE (random_state=42), both plots
    python linear_probe.py         # step 5: logistic-regression linear probe, accuracy + macro F1

Or simply:

    cd code && bash run_all.sh

Runtime on the machine above: about 6.5 minutes for step 1 (a 792 MB download),
about 2.5 minutes for step 2, about 25 seconds for step 4, and a few seconds for
steps 3 and 5.

Optional flags for step 2:
    python extract_embeddings.py --device cpu --batch-size 16

Outputs
    ../images/factor1_interclass_similarity.png     Section 2, visual factor 1
    ../images/factor2_intraclass_dissimilarity.png  Section 2, visual factor 2
    ../images/six_breeds_examples.png               the 6 breeds of t-SNE Plot 2
    ../images/tsne_cat_vs_dog.png                   Section 4, Plot 1
    ../images/tsne_six_breeds.png                   Section 4, Plot 2
    ../convincingDirectory/dataset_stats.txt                  numbers quoted in Section 2
    ../convincingDirectory/shapes.txt                         tensor shapes quoted in Section 3
    ../convincingDirectory/tsne_info.txt                      t-SNE settings and KL divergence
    ../convincingDirectory/linear_probe_results.txt           accuracy, macro F1, per-class report

Reproducibility notes
    * All seeds are 42 (config.SEED); TSNE(random_state=42) and
      LogisticRegression(random_state=42, max_iter=2000).
    * The image processor is loaded with use_fast=False so that preprocessing
      matches the "slow" PIL pipeline saved with the checkpoint and does not
      drift with future transformers defaults.
    * Both splits are read with shuffle=False, so row i of X_<split>.npy always
      corresponds to image i of that split.

Not submitted (recreated by the code, per the task instructions)
    data/       the Oxford-IIIT Pet dataset (downloaded by download_data.py)
    convincingDirectory/  the extracted embeddings (.npy) -- the small .txt logs quoted in
                answers.pdf are kept because they are tiny
    Pretrained DINOv2 weights are cached by Hugging Face under
    ~/.cache/huggingface on first run.



