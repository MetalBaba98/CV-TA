import cv2
import numpy as np

# 1. Insert your computed K matrix values here
fx, fy = 944.09564486, 857.37796014  # Placeholder focal lengths
cx, cy = 347.16395025, 347.16395025  # Placeholder principal point
K = np.array([[fx, 0, cx], 
              [0, fy, cy], 
              [0, 0, 1]], dtype=np.float64)

# Assuming negligible lens distortion for this specific task
dist_coeffs = np.zeros((4,1)) 

# 2. Insert your physical 3D measurements (in cm)
object_points = np.array([
    [0.0, 0.0, 0.0],       # O: Origin
    [34.0, 0.0, 0.0],      # A: Front-left leg 
    [34.0, 34.0, 0.0],     # B: Front-right leg 
    [0.0, 0.0, 42.0],      # C: Top-left backrest 
    [34.0, 34.0, 34.0]     # D: Front-right seat edge 
], dtype=np.float64)

# 3. Insert your MS Paint 2D pixel coordinates
image_points = np.array([
    [344, 1008],          # O
    [480, 1070],          # A
    [300, 1156],          # B
    [348, 823],           # C
    [295, 1019]           # D
], dtype=np.float64)

# Run the EPnP algorithm
success, rvec, tvec = cv2.solvePnP(
    object_points, 
    image_points, 
    cameraMatrix=K, 
    distCoeffs=dist_coeffs, 
    flags=cv2.SOLVEPNP_EPNP
)

if success:
    # Calculate the Euclidean distance from the camera to the origin
    distance_cm = np.linalg.norm(tvec)
    print(f"Translation Vector (tvec):\n{tvec}")
    print(f"Estimated distance from camera to origin: {distance_cm:.2f} cm")
else:
    print("PnP estimation failed.")