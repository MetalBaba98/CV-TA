import cv2
import os

def annotate_chair_image():
    # Relative Windows paths pointing to the 'images' subdirectory
    image_path = r'..\images\chair_1st person.jpeg'
    output_path = r'..\images\chair_annotated.jpeg'
    
    # Load your specific image
    image = cv2.imread(image_path)
    
    if image is None:
        print(f"Error: Could not load {image_path}.")
        print("Please ensure you are running this script from the root of your assignment folder ")
        print("and that 'chair_1st person.jpeg' is inside the 'images' folder.")
        return

    # Define the re-approximated 2D pixel coordinates and their conceptual 3D labels
    # Origin (O) is now the back-right leg (estimated position as it is obscured)
    # Format: "Letter": ((u_pixel, v_pixel), "(X, Y, Z) string")
    landmarks = {
        "O": ((344, 1008), "(0, 0, 0)"),
        "A": ((480, 1070), "(34, 0, 0)"),
        "B": ((300, 1156), "(34, 34, 0)"),
        "C": ((348, 823), "(0, 0, 42)"),
        "D": ((295, 1019), "(34, 34, 34)")
    }

    # Loop through the landmarks and draw them on the image
    for label, (point, coord_text) in landmarks.items():
        # Draw a solid red circle at the exact pixel location
        cv2.circle(image, point, radius=12, color=(0, 0, 255), thickness=-1)
        
        # Create the text string (e.g., "O (0, 0, 0)")
        display_text = f"{label} {coord_text}"
        
        # Adjust text placement so right-side labels don't get cut off
        if label in ["O", "A"]:
            text_position = (point[0] - 220, point[1] - 15) # Shift text to the left
        else:
            text_position = (point[0] + 20, point[1] - 15)  # Default text to the right
            
        cv2.putText(
            image, 
            display_text, 
            text_position, 
            cv2.FONT_HERSHEY_SIMPLEX, 
            fontScale=1.2, 
            color=(0, 255, 0), # Green text
            thickness=3
        )

    # Save the new annotated image directly into the images/ directory
    cv2.imwrite(output_path, image)
    print(f"Success! Annotated image saved to '{output_path}'")

if __name__ == "__main__":
    annotate_chair_image()