import cv2
import numpy as np
import glob
import os

# --- Configuration ---
# Set the number of INTERNAL corners on the chessboard (width, height)
# Note: A 8x8 square board like the GeeksforGeeks one has 7x7 internal corners.
CHESSBOARD_SIZE = (7, 7) 

# The physical size of a single square (optional, but good for metric scale)
SQUARE_SIZE = 1.0 

# UPDATED: Relative Windows path using a raw string (r"...")
IMAGE_PATH_PATTERN = r"..\images\chessboard_*.jpeg" 
# ---------------------

def calibrate_camera():
    # 1. Prepare object points based on the known dimensions of the chessboard
    objp = np.zeros((CHESSBOARD_SIZE[0] * CHESSBOARD_SIZE[1], 3), np.float32)
    objp[:, :2] = np.mgrid[0:CHESSBOARD_SIZE[0], 0:CHESSBOARD_SIZE[1]].T.reshape(-1, 2)
    objp = objp * SQUARE_SIZE

    # Arrays to store object points and image points from all the images.
    objpoints = [] # 3d point in real world space
    imgpoints = [] # 2d points in image plane.

    # 2. Load the images using the Windows relative path
    images = glob.glob(IMAGE_PATH_PATTERN)
    
    if not images:
        print(f"No images found matching the pattern: {IMAGE_PATH_PATTERN}")
        print("Please check that the '..\images' folder exists and contains .jpeg files.")
        return

    print(f"Found {len(images)} images for calibration.")

    # Criteria for sub-pixel corner refinement
    criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 30, 0.001)

    # 3. Detect chessboard corners in each image
    gray_shape = None
    for fname in images:
        img = cv2.imread(fname)
        if img is None:
            print(f"Failed to load {fname}")
            continue
            
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        gray_shape = gray.shape[::-1]

        # Find the chess board corners
        ret, corners = cv2.findChessboardCorners(gray, CHESSBOARD_SIZE, None)

        # If found, add object points, image points (after refining them)
        if ret == True:
            objpoints.append(objp)

            # Refine corner locations to sub-pixel accuracy
            corners2 = cv2.cornerSubPix(gray, corners, (11, 11), (-1, -1), criteria)
            imgpoints.append(corners2)

            print(f"Successfully detected corners in {os.path.basename(fname)}")
        else:
            print(f"Could NOT detect corners in {os.path.basename(fname)}")

    if len(objpoints) == 0:
        print("Error: Could not find chessboard corners in any of the images.")
        return

    # 4. Perform the camera calibration
    print("\nCalculating camera matrix...")
    ret, camera_matrix, dist_coeffs, rvecs, tvecs = cv2.calibrateCamera(
        objpoints, imgpoints, gray_shape, None, None
    )

    if ret:
        print("\n--- Calibration Successful ---")
        print("\n1. Camera Matrix (K):")
        print(camera_matrix)
        
        print("\n2. Distortion Coefficients (dist_coeffs):")
        print(dist_coeffs)
        
        # Calculate Reprojection Error to measure accuracy
        mean_error = 0
        for i in range(len(objpoints)):
            imgpoints2, _ = cv2.projectPoints(objpoints[i], rvecs[i], tvecs[i], camera_matrix, dist_coeffs)
            error = cv2.norm(imgpoints[i], imgpoints2, cv2.NORM_L2) / len(imgpoints2)
            mean_error += error
            
        print(f"\nTotal Reprojection Error: {mean_error/len(objpoints):.4f} pixels (closer to 0 is better)")
    else:
        print("Camera calibration failed.")

if __name__ == "__main__":
    calibrate_camera()