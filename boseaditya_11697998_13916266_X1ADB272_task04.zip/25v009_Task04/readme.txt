. Olympus SIS ID: X1ADB272

2. Which external person (human resource) or TA I consulted:
   None

3. What non-human resources I used on the Internet:
   a. None

4. I pledge on my honour that I have not given or received any unauthorized
   assistance on this assignment or any previous task.

   Signed by: Aditya Bose, X1ADB272