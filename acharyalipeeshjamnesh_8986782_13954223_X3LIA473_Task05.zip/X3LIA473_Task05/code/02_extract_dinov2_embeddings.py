"""
Run:
    python 02_extract_dinov2_embeddings.py --data-root ./data --out-dir ./embeddings
"""

import argparse
import os

import numpy as np
import torch
from torch.utils.data import DataLoader
from torchvision.datasets import OxfordIIITPet
from transformers import AutoImageProcessor, AutoModel

SEED = 42
MODEL_NAME = "facebook/dinov2-small"


def set_seed(seed=SEED):
    torch.manual_seed(seed)
    np.random.seed(seed)


class Collator:
    """
    Turns a list of (PIL image, label) into a processed batch tensor + label tensor.

    This is a class (not a nested function/closure) specifically so it is
    picklable. On Windows, DataLoader workers (num_workers > 0) are started
    with 'spawn', which pickles the collate function to send to each worker
    process; a closure defined inside another function cannot be pickled and
    causes "Can't pickle local object ... .<locals>.collate". Using a class
    with __call__ avoids that.
    """
    def __init__(self, processor):
        self.processor = processor

    def __call__(self, batch):
        images, labels = zip(*batch)
        inputs = self.processor(images=list(images), return_tensors="pt")
        labels = torch.tensor(labels, dtype=torch.long)
        return inputs, labels


@torch.no_grad()
def extract_split(split_name, data_root, processor, model, device, batch_size=32,
                   report_shapes=False, num_workers=0):
    dataset = OxfordIIITPet(root=data_root, split=split_name, target_types="category", download=True)
    loader = DataLoader(
        dataset, batch_size=batch_size, shuffle=False,
        collate_fn=Collator(processor), num_workers=num_workers,
    )

    all_embeddings = []
    all_labels = []

    for batch_idx, (inputs, labels) in enumerate(loader):
        pixel_values = inputs["pixel_values"].to(device)

        if report_shapes and batch_idx == 0:
            print("=" * 60)
            print(f"Section 3.1(1) - tensor shapes for a batch from '{split_name}'")
            print("=" * 60)
            print(f"Processed input tensor shape : {tuple(pixel_values.shape)}")
            print("  -> (batch_size, channels=3 RGB, height, width) after resize/normalize")

        outputs = model(pixel_values=pixel_values)
        last_hidden_state = outputs.last_hidden_state  # (B, num_tokens, hidden_dim)

        if report_shapes and batch_idx == 0:
            print(f"Full final hidden-state shape : {tuple(last_hidden_state.shape)}")
            print("  -> (batch_size, num_tokens = 1 [CLS] + num_patch_tokens, hidden_dim)")

        cls_embedding = last_hidden_state[:, 0, :]  # z_i = last_hidden_state[i, 0, :]

        if report_shapes and batch_idx == 0:
            print(f"Extracted [CLS] embedding shape: {tuple(cls_embedding.shape)}")
            print("  -> (batch_size, hidden_dim) — exactly one embedding vector per image")
            print()

        all_embeddings.append(cls_embedding.cpu().numpy())
        all_labels.append(labels.numpy())

    embeddings = np.concatenate(all_embeddings, axis=0)
    labels = np.concatenate(all_labels, axis=0)
    return embeddings, labels, dataset.classes


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-root", type=str, default="./data")
    parser.add_argument("--out-dir", type=str, default="./embeddings")
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--num-workers", type=int, default=0,
                         help="DataLoader worker processes. Keep at 0 on Windows unless you "
                              "know what you're doing — >0 uses 'spawn' and is more fragile there.")
    args = parser.parse_args()

    set_seed()
    os.makedirs(args.out_dir, exist_ok=True)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}  (GPU is not required for dinov2-small)")

    # Load processor + frozen model
    processor = AutoImageProcessor.from_pretrained(MODEL_NAME)
    model = AutoModel.from_pretrained(MODEL_NAME)
    model.eval()          # inference mode
    model.to(device)
    for p in model.parameters():
        p.requires_grad = False   # explicitly freeze — no gradients will ever be computed

    print(f"\nExtracting embeddings for 'trainval' split...")
    trainval_emb, trainval_labels, classes = extract_split(
        "trainval", args.data_root, processor, model, device,
        batch_size=args.batch_size, report_shapes=True, num_workers=args.num_workers,
    )

    print(f"Extracting embeddings for 'test' split...")
    test_emb, test_labels, _ = extract_split(
        "test", args.data_root, processor, model, device,
        batch_size=args.batch_size, report_shapes=False, num_workers=args.num_workers,
    )

    print("=" * 60)
    print("Section 3.1(2) - embedding dimensionality check")
    print("=" * 60)
    print(f"trainval embeddings shape: {trainval_emb.shape}  (num_images, embedding_dim)")
    print(f"test embeddings shape    : {test_emb.shape}")
    print(f"Embedding dimensionality : {trainval_emb.shape[1]}")
    assert trainval_emb.shape[0] == len(trainval_labels)
    assert test_emb.shape[0] == len(test_labels)
    print("Confirmed: exactly one embedding vector per image in each split.")

    np.save(os.path.join(args.out_dir, "trainval_embeddings.npy"), trainval_emb)
    np.save(os.path.join(args.out_dir, "trainval_labels.npy"), trainval_labels)
    np.save(os.path.join(args.out_dir, "test_embeddings.npy"), test_emb)
    np.save(os.path.join(args.out_dir, "test_labels.npy"), test_labels)
    with open(os.path.join(args.out_dir, "classes.txt"), "w") as f:
        f.write("\n".join(classes))

    print(f"\nSaved embeddings + labels + class list to {args.out_dir}/")


if __name__ == "__main__":
    main()