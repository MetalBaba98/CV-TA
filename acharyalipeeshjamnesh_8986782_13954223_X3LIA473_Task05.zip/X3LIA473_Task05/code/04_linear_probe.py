"""
Run:
    python 04_linear_probe.py --embeddings-dir ./embeddings
"""

import argparse
import os

import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score
from sklearn.preprocessing import StandardScaler

RANDOM_STATE = 42


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--embeddings-dir", type=str, default="./embeddings")
    parser.add_argument("--standardise", action="store_true",
                         help="Fit a StandardScaler on trainval only, apply to both splits")
    args = parser.parse_args()

    X_train = np.load(os.path.join(args.embeddings_dir, "trainval_embeddings.npy"))
    y_train = np.load(os.path.join(args.embeddings_dir, "trainval_labels.npy"))
    X_test = np.load(os.path.join(args.embeddings_dir, "test_embeddings.npy"))
    y_test = np.load(os.path.join(args.embeddings_dir, "test_labels.npy"))

    print(f"trainval embeddings: {X_train.shape}, test embeddings: {X_test.shape}")

    if args.standardise:
        # Fit ONLY on trainval, then apply the same transform to test —
        # this avoids leaking test-set statistics into preprocessing.
        print("Standardising embeddings: scaler fit on trainval ONLY, then applied to test.")
        scaler = StandardScaler()
        X_train = scaler.fit_transform(X_train)
        X_test = scaler.transform(X_test)
    else:
        print("No standardisation applied — using raw [CLS] embeddings directly.")

    clf = LogisticRegression(max_iter=2000, random_state=RANDOM_STATE)
    clf.fit(X_train, y_train)

    y_pred = clf.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    macro_f1 = f1_score(y_test, y_pred, average="macro")

    print("=" * 60)
    print("Section 5.2 - Linear probe results (test split)")
    print("=" * 60)
    print(f"{'Classifier':<35}{'Test Accuracy':<16}{'Macro F1'}")
    print(f"{'Logistic Regression (linear probe)':<35}{acc:<16.4f}{macro_f1:.4f}")

    if clf.n_iter_[0] >= 2000:
        print("\nNOTE: solver used the full max_iter=2000 budget — check convergence "
              "warnings above; document any deviation from default params if needed.")


if __name__ == "__main__":
    main()
