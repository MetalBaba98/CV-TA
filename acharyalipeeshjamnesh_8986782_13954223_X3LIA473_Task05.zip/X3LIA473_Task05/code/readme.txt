Task 05 - DINOv2 frozen feature extractor on Oxford-IIIT Pet
==============================================================

ENVIRONMENT
-----------
Python 3.10+ recommended. Install dependencies with:
    pip install -r requirements.txt

All random seeds are fixed:
    - seed 42 for dataset loading, DINOv2 extraction, and the logistic
      regression classifier
    - random_state=422 specifically for t-SNE, per assignment spec

EXECUTION ORDER (run from the code/ directory)
-----------------------------------------------
1. python 01_load_and_explore_data.py --data-root ./data --save-samples
   - Downloads Oxford-IIIT Pet (trainval + test) via torchvision.
   - Prints image/class counts (Section 2.1.1).
   - Optionally dumps sample images per class to ./sample_images for you
     to manually pick visual-factor examples (Section 2.1.2).

2. python 02_extract_dinov2_embeddings.py --data-root ./data --out-dir ./embeddings
   - Loads facebook/dinov2-small via Hugging Face transformers (AutoModel).
   - Runs a frozen forward pass (torch.no_grad(), requires_grad=False) over
     both splits, extracts the [CLS] token from the final hidden state.
   - Prints tensor shapes for the first batch (Section 3.1.1) and confirms
     embedding dimensionality / one-embedding-per-image (Section 3.1.2).
   - Saves trainval/test embeddings + labels + class list as .npy/.txt
     under ./embeddings (NOT submitted, per assignment instructions).

3. python 03_tsne_visualization.py --embeddings-dir ./embeddings --out-dir ./images
   - Projects TEST split embeddings to 2D with sklearn TSNE(random_state=422).
   - Produces tsne_cat_vs_dog.png (Section 4.1) and tsne_breed_subset.png
     (Section 4.2). Edit BREED_SUBSET at the top of the script with your
     own 6 chosen breeds before running.
   - Pass --standardise if you choose to z-score embeddings before t-SNE
     (state this choice explicitly in your writeup either way).

4. python 04_linear_probe.py --embeddings-dir ./embeddings
   - Trains sklearn LogisticRegression(max_iter=2000, random_state=42) on
     trainval embeddings only, evaluates once on test embeddings.
   - Prints test accuracy and macro-F1 to 4 decimal places (Section 5.2).
   - Pass --standardise to fit a StandardScaler on trainval only and apply
     it to test (no leakage), matching Section 5.1's requirement.

NOT INCLUDED IN THIS SUBMISSION (per Section 6)
------------------------------------------------
- The Oxford-IIIT Pet dataset itself (./data/) — recreated by step 1.
- Pretrained DINOv2 weights (Hugging Face cache) — recreated by step 2.
- Extracted embedding files (./embeddings/*.npy) — recreated by step 2.

TODO FOR YOU (not filled in by this code)
------------------------------------------
- Section 2.1(2)/(3): pick your two example pairs illustrating inter-class
  similarity / intra-class dissimilarity, with sample images, and write the
  discussion.
- Section 3.1(3): write the explanation of the [CLS] token's purpose and
  why the backbone is "frozen" in your own words.
- Section 4.2/4.3: set BREED_SUBSET in 03_tsne_visualization.py to your
  chosen 6 breeds and write the interpretation of both plots.
- Honor code statement at the top of your submission.
