"""
Run:
    python 03_tsne_visualization.py --embeddings-dir ./embeddings --out-dir ./images
"""

import argparse
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from sklearn.manifold import TSNE
from sklearn.preprocessing import StandardScaler

RANDOM_STATE = 422  # fixed per assignment spec, note this is DIFFERENT from seed 42 elsewhere

# The 12 cat breeds in the Oxford-IIIT Pet dataset (everything else is a dog).
# Using an explicit list instead of guessing from name casing, since torchvision's
# class-name formatting (spacing/capitalization) can vary by version.
CAT_BREEDS = {
    "Abyssinian", "Bengal", "Birman", "Bombay", "British Shorthair",
    "Egyptian Mau", "Maine Coon", "Persian", "Ragdoll", "Russian Blue",
    "Siamese", "Sphynx",
}

# TODO: fill this in with your own 6 breed choices from Section 2's analysis.
# Use EXACT class name strings as they appear in classes.txt (check spacing/
# capitalization — it varies by torchvision version).
BREED_SUBSET = [
    "Bengal",
    "Egyptian Mau",
    "Chihuahua",
    "Great Pyrenees",
    "Siamese",
    "Pug",
]


def species_from_breed(breed_name: str) -> str:
    """Look up cat vs dog from the explicit CAT_BREEDS set (all non-cats are dogs)."""
    return "cat" if breed_name in CAT_BREEDS else "dog"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--embeddings-dir", type=str, default="./embeddings")
    parser.add_argument("--out-dir", type=str, default="./images")
    parser.add_argument("--standardise", action="store_true",
                         help="Apply StandardScaler to embeddings before t-SNE")
    args = parser.parse_args()

    os.makedirs(args.out_dir, exist_ok=True)

    test_emb = np.load(os.path.join(args.embeddings_dir, "test_embeddings.npy"))
    test_labels = np.load(os.path.join(args.embeddings_dir, "test_labels.npy"))
    with open(os.path.join(args.embeddings_dir, "classes.txt")) as f:
        classes = f.read().splitlines()

    print(f"Loaded test embeddings: {test_emb.shape}")

    X = test_emb
    if args.standardise:
        print("Standardising embeddings (zero mean, unit variance) before t-SNE.")
        X = StandardScaler().fit_transform(X)
    else:
        print("Running t-SNE directly on raw [CLS] embeddings (no standardisation).")

    print(f"Running t-SNE (random_state={RANDOM_STATE})... this can take a minute.")
    tsne = TSNE(n_components=2, random_state=RANDOM_STATE, init="pca")
    proj = tsne.fit_transform(X)  # (num_test_images, 2)

    breed_names = np.array([classes[i] for i in test_labels])

    # ---------------- Plot 1: cat vs dog ----------------
    species = np.array([species_from_breed(b) for b in breed_names])
    plt.figure(figsize=(8, 7))
    for sp, color in [("cat", "tab:orange"), ("dog", "tab:blue")]:
        mask = species == sp
        plt.scatter(proj[mask, 0], proj[mask, 1], s=8, alpha=0.6, label=sp, color=color)
    plt.legend(title="Species")
    plt.title("t-SNE of DINOv2-small [CLS] embeddings (test split) — Cat vs Dog")
    plt.xlabel("t-SNE dim 1")
    plt.ylabel("t-SNE dim 2")
    plt.tight_layout()
    plot1_path = os.path.join(args.out_dir, "tsne_cat_vs_dog.png")
    plt.savefig(plot1_path, dpi=200)
    plt.close()
    print(f"Saved Plot 1 to {plot1_path}")

    # ---------------- Plot 2: 6-breed subset ----------------
    missing = [b for b in BREED_SUBSET if b not in classes]
    if missing:
        raise ValueError(
            f"These breed names in BREED_SUBSET are not in classes.txt: {missing}. "
            f"Check spelling/casing against your dataset's class list.\n\n"
            f"Full list of valid class names (copy-paste exactly from here):\n"
            + "\n".join(f"  {c}" for c in classes)
        )

    plt.figure(figsize=(8, 7))
    cmap = plt.get_cmap("tab10")
    for i, breed in enumerate(BREED_SUBSET):
        mask = breed_names == breed
        plt.scatter(proj[mask, 0], proj[mask, 1], s=14, alpha=0.75,
                    label=breed, color=cmap(i))
    plt.legend(title="Breed", bbox_to_anchor=(1.02, 1), loc="upper left")
    plt.title("t-SNE of DINOv2-small [CLS] embeddings — 6-breed subset")
    plt.xlabel("t-SNE dim 1")
    plt.ylabel("t-SNE dim 2")
    plt.tight_layout()
    plot2_path = os.path.join(args.out_dir, "tsne_breed_subset.png")
    plt.savefig(plot2_path, dpi=200)
    plt.close()
    print(f"Saved Plot 2 to {plot2_path}")



if __name__ == "__main__":
    main()