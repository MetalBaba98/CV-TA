"""
Run:
    python 01_load_and_explore_data.py --data-root ./data
"""

import argparse
import os
import random

import numpy as np
import torch
from torchvision.datasets import OxfordIIITPet

SEED = 42


def set_seed(seed=SEED):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-root", type=str, default="./data",
                         help="Where torchvision should download/find the dataset")
    parser.add_argument("--save-samples", action="store_true",
                         help="Dump a handful of raw images per class to ./sample_images "
                              "so you can eyeball candidates for the visual-factor discussion")
    args = parser.parse_args()

    set_seed()
    os.makedirs(args.data_root, exist_ok=True)

    # --- Official trainval split: used to TRAIN downstream classifiers ---
    trainval_set = OxfordIIITPet(
        root=args.data_root,
        split="trainval",
        target_types="category",   # 37-way breed label, NOT the binary cat/dog label
        download=True,
    )

    # --- Official test split: used ONLY for final evaluation ---
    test_set = OxfordIIITPet(
        root=args.data_root,
        split="test",
        target_types="category",
        download=True,
    )

    classes = trainval_set.classes  # list of 37 breed name strings
    assert trainval_set.classes == test_set.classes, "class lists should match across splits"

    print("=" * 60)
    print("Section 2.1(1) - dataset counts")
    print("=" * 60)
    print(f"Number of training (trainval) images : {len(trainval_set)}")
    print(f"Number of test images                 : {len(test_set)}")
    print(f"Number of classes                     : {len(classes)}")
    print()
    print("Class list (index: breed name):")
    for i, c in enumerate(classes):
        print(f"  {i:2d}: {c}")

    # Quick sanity check on how species (cat/dog) can be derived from the
    # breed name. This dataset has 12 cat breeds and 25 dog breeds; the
    # simplest reliable way to map breed -> species is an explicit lookup
    # list, since torchvision's class-name formatting (spacing/capitalization)
    # varies by version and isn't a safe signal on its own.
    CAT_BREEDS = {
        "Abyssinian", "Bengal", "Birman", "Bombay", "British Shorthair",
        "Egyptian Mau", "Maine Coon", "Persian", "Ragdoll", "Russian Blue",
        "Siamese", "Sphynx",
    }
    print()
    print("Derived species mapping (explicit cat-breed lookup):")
    n_cats = sum(1 for c in classes if c in CAT_BREEDS)
    n_dogs = len(classes) - n_cats
    print(f"  cats: {n_cats}, dogs: {n_dogs}  (should be 12 cats / 25 dogs)")
    unmatched = [c for c in classes if c not in CAT_BREEDS and c.replace(" ", "_") not in
                 {b.replace(" ", "_") for b in CAT_BREEDS}]
    if n_cats != 12:
        print(f"  WARNING: expected 12 cats, got {n_cats}. Check exact class name formatting "
              f"(spaces vs underscores, capitalization) against your classes list above and "
              f"adjust the CAT_BREEDS set accordingly.")

    if args.save_samples:
        out_dir = "sample_images"
        os.makedirs(out_dir, exist_ok=True)
        # Save a couple of raw images per class so you can manually pick your
        # "visually similar" and "visually distinct" pairs for Section 2 and
        # your 6-breed subset for Section 4.2.
        seen = {}
        for img, label in trainval_set:
            cname = classes[label]
            seen.setdefault(cname, 0)
            if seen[cname] < 2:
                img.save(os.path.join(out_dir, f"{cname}_{seen[cname]}.png"))
                seen[cname] += 1
            if all(v >= 2 for v in seen.values()) and len(seen) == len(classes):
                break
        print(f"\nSaved sample images to ./{out_dir}/ for you to inspect.")


if __name__ == "__main__":
    main()