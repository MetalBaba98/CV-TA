"""
04_tsne_plots.py
================
Section 4: t-SNE visualisation of the DINOv2 embedding space.
Loads saved embeddings, runs t-SNE on test-split [CLS] vectors, and
produces two plots:
  1. Cat vs. Dog super-category colouring
  2. Focused 6-breed subset

Usage:
    python 04_tsne_plots.py       (run AFTER 03_extract_embeddings.py)
"""

import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE
from sklearn.preprocessing import StandardScaler

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_DIR = os.path.dirname(SCRIPT_DIR)
IMAGE_DIR = os.path.join(PROJECT_DIR, "images")
EMB_DIR = os.path.join(PROJECT_DIR, "embeddings")
RESULTS_DIR = os.path.join(PROJECT_DIR, "results")
os.makedirs(IMAGE_DIR, exist_ok=True)
os.makedirs(RESULTS_DIR, exist_ok=True)

SEED = 42

# ===========================================================================
# Load saved embeddings
# ===========================================================================
emb_path = os.path.join(EMB_DIR, "dinov2_small_embeddings.npz")
print(f"Loading embeddings from {emb_path} ...")
data = np.load(emb_path, allow_pickle=True)
test_embeddings = data["test_embeddings"]
test_labels = data["test_labels"]
class_names = list(data["class_names"])

print(f"Test embeddings shape: {test_embeddings.shape}")
print(f"Number of classes: {len(class_names)}")

# ---------------------------------------------------------------------------
# Cat / Dog mapping
# ---------------------------------------------------------------------------
CAT_BREEDS = {
    "Abyssinian", "Bengal", "Birman", "Bombay", "British Shorthair",
    "Egyptian Mau", "Maine Coon", "Persian", "Ragdoll", "Russian Blue",
    "Siamese", "Sphynx",
}

catdog_map = {}
for idx, name in enumerate(class_names):
    catdog_map[idx] = "Cat" if name in CAT_BREEDS else "Dog"

# ===========================================================================
# Standardise + run t-SNE
# ===========================================================================
print("=" * 70)
print("SECTION 4: t-SNE Visualization")
print("=" * 70)

print("\nStandardising test embeddings (StandardScaler) before t-SNE...")
scaler = StandardScaler()
test_std = scaler.fit_transform(test_embeddings)

print(f"Running TSNE(n_components=2, random_state={SEED}, perplexity=30, max_iter=1000) ...")
tsne = TSNE(n_components=2, random_state=SEED, perplexity=30, max_iter=1000)
test_2d = tsne.fit_transform(test_std)
print(f"t-SNE output shape: {test_2d.shape}")

# Save t-SNE coordinates as extra result
np.savez(os.path.join(RESULTS_DIR, "tsne_coordinates.npz"),
         tsne_2d=test_2d, labels=test_labels)
print(f"  t-SNE coordinates saved to ../results/tsne_coordinates.npz")

# ===========================================================================
# Plot 1: Cat vs. Dog
# ===========================================================================
print("\nGenerating Plot 1: Cat vs. Dog ...")
catdog_labels = np.array([catdog_map[l] for l in test_labels])

fig, ax = plt.subplots(1, 1, figsize=(10, 8))
colors_cd = {"Cat": "#FF6B6B", "Dog": "#4ECDC4"}
for species in ["Cat", "Dog"]:
    mask = catdog_labels == species
    ax.scatter(
        test_2d[mask, 0], test_2d[mask, 1],
        c=colors_cd[species], label=species, alpha=0.5, s=12, edgecolors="none"
    )
ax.set_title("t-SNE of DINOv2 [CLS] Embeddings -- Cat vs. Dog", fontsize=14)
ax.set_xlabel("t-SNE Dimension 1")
ax.set_ylabel("t-SNE Dimension 2")
ax.legend(fontsize=12, markerscale=3)
ax.set_aspect("equal", adjustable="datalim")
plt.tight_layout()
plt.savefig(os.path.join(IMAGE_DIR, "tsne_cat_vs_dog.png"), dpi=200)
plt.close()
print("  Saved: ../images/tsne_cat_vs_dog.png")

# ===========================================================================
# Plot 2: 6-Breed Subset
# ===========================================================================
SELECTED_BREEDS = [
    "Staffordshire Bull Terrier",   # inter-class similar (dog)
    "American Pit Bull Terrier",    # inter-class similar (dog)
    "Chihuahua",                    # visually distinct small dog
    "Great Pyrenees",               # visually distinct large dog
    "Persian",                      # cat -- fluffy
    "Siamese",                      # cat -- sleek
]

print(f"\nGenerating Plot 2: 6-Breed Subset ...")
print(f"  Selected breeds: {SELECTED_BREEDS}")

breed_to_idx = {name: i for i, name in enumerate(class_names)}
selected_indices = [breed_to_idx[b] for b in SELECTED_BREEDS]
print(f"  Class indices: {selected_indices}")

mask_6 = np.isin(test_labels, selected_indices)
tsne_6 = test_2d[mask_6]
labels_6 = test_labels[mask_6]

fig, ax = plt.subplots(1, 1, figsize=(10, 8))
colors_6 = ["#E63946", "#457B9D", "#2A9D8F", "#E9C46A", "#F4A261", "#264653"]
for i, (cls_idx, display_name) in enumerate(zip(selected_indices, SELECTED_BREEDS)):
    m = labels_6 == cls_idx
    ax.scatter(
        tsne_6[m, 0], tsne_6[m, 1],
        c=colors_6[i], label=display_name, alpha=0.7, s=25, edgecolors="none"
    )
ax.set_title("t-SNE of DINOv2 [CLS] Embeddings -- 6-Breed Subset", fontsize=14)
ax.set_xlabel("t-SNE Dimension 1")
ax.set_ylabel("t-SNE Dimension 2")
ax.legend(fontsize=10, markerscale=2, loc="best")
ax.set_aspect("equal", adjustable="datalim")
plt.tight_layout()
plt.savefig(os.path.join(IMAGE_DIR, "tsne_6breed_subset.png"), dpi=200)
plt.close()
print("  Saved: ../images/tsne_6breed_subset.png")

print("\n[DONE] Both t-SNE plots generated.")
