"""
05_linear_probe.py
==================
Section 5: Linear probe classification.
Loads saved DINOv2 embeddings, standardises them (scaler fit on trainval
only), trains a LogisticRegression(max_iter=2000, random_state=42), and
reports test accuracy and macro-F1 to 4 decimal places.

Usage:
    python 05_linear_probe.py     (run AFTER 03_extract_embeddings.py)
"""

import os
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score, classification_report

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_DIR = os.path.dirname(SCRIPT_DIR)
EMB_DIR = os.path.join(PROJECT_DIR, "embeddings")
RESULTS_DIR = os.path.join(PROJECT_DIR, "results")
os.makedirs(RESULTS_DIR, exist_ok=True)

SEED = 42

# ===========================================================================
# Load saved embeddings
# ===========================================================================
emb_path = os.path.join(EMB_DIR, "dinov2_small_embeddings.npz")
print(f"Loading embeddings from {emb_path} ...")
data = np.load(emb_path, allow_pickle=True)
train_embeddings = data["train_embeddings"]
train_labels = data["train_labels"]
test_embeddings = data["test_embeddings"]
test_labels = data["test_labels"]
class_names = list(data["class_names"])

print(f"Trainval: {train_embeddings.shape}, Test: {test_embeddings.shape}")

# ===========================================================================
# Standardise embeddings
# ===========================================================================
print("=" * 70)
print("SECTION 5: Linear Probe Classification")
print("=" * 70)

print("\nStandardising embeddings ...")
print("  -> StandardScaler fitted on trainval embeddings ONLY")
print("  -> Same transform applied to test embeddings (no data leakage)")
scaler = StandardScaler()
X_train = scaler.fit_transform(train_embeddings)
X_test = scaler.transform(test_embeddings)

# ===========================================================================
# Train logistic regression
# ===========================================================================
print(f"\nTraining LogisticRegression(max_iter=2000, random_state={SEED}) ...")
clf = LogisticRegression(max_iter=2000, random_state=SEED)
clf.fit(X_train, train_labels)
print("  Training complete.")

# ===========================================================================
# Evaluate on test split
# ===========================================================================
y_pred = clf.predict(X_test)

test_accuracy = accuracy_score(test_labels, y_pred)
test_f1 = f1_score(test_labels, y_pred, average="macro")

print(f"\n{'=' * 50}")
print(f"  Test Accuracy  : {test_accuracy:.4f}")
print(f"  Macro F1 Score : {test_f1:.4f}")
print(f"{'=' * 50}")

# Save detailed classification report to results/
report = classification_report(test_labels, y_pred, target_names=class_names)
report_path = os.path.join(RESULTS_DIR, "classification_report.txt")
with open(report_path, "w") as f:
    f.write("Linear Probe (Logistic Regression) -- Per-Class Report\n")
    f.write("=" * 60 + "\n\n")
    f.write(f"Test Accuracy:  {test_accuracy:.4f}\n")
    f.write(f"Macro F1 Score: {test_f1:.4f}\n\n")
    f.write(report)
print(f"\nDetailed per-class report saved to: {report_path}")

print("\n[DONE] Linear probe evaluation complete.")
