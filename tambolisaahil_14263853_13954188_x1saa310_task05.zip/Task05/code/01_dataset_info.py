"""
01_dataset_info.py
==================
Section 2: Dataset exploration.
Downloads the Oxford-IIIT Pet dataset and reports basic statistics.

Usage:
    python 01_dataset_info.py
"""

import os
import random
import numpy as np
import torch
from torchvision.datasets import OxfordIIITPet

# ---------------------------------------------------------------------------
# Reproducibility
# ---------------------------------------------------------------------------
SEED = 42
random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)

# Paths
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_DIR = os.path.dirname(SCRIPT_DIR)
DATA_DIR = os.path.join(SCRIPT_DIR, "data")
os.makedirs(DATA_DIR, exist_ok=True)

# ===========================================================================
# Load the dataset
# ===========================================================================
print("=" * 70)
print("SECTION 2: Dataset Information")
print("=" * 70)

trainval_dataset = OxfordIIITPet(
    root=DATA_DIR, split="trainval", target_types="category", download=True
)
test_dataset = OxfordIIITPet(
    root=DATA_DIR, split="test", target_types="category", download=True
)

class_names = trainval_dataset.classes
num_classes = len(class_names)

print(f"\nNumber of training (trainval) images : {len(trainval_dataset)}")
print(f"Number of test images                : {len(test_dataset)}")
print(f"Number of classes (breeds)           : {num_classes}")
print(f"\nClass names: {class_names}")

# ---------------------------------------------------------------------------
# Cat / Dog mapping (derived from breed names, not the binary label field)
# ---------------------------------------------------------------------------
CAT_BREEDS = {
    "Abyssinian", "Bengal", "Birman", "Bombay", "British Shorthair",
    "Egyptian Mau", "Maine Coon", "Persian", "Ragdoll", "Russian Blue",
    "Siamese", "Sphynx",
}

cat_list = sorted([n for n in class_names if n in CAT_BREEDS])
dog_list = sorted([n for n in class_names if n not in CAT_BREEDS])

print(f"\nCat breeds ({len(cat_list)}): {cat_list}")
print(f"Dog breeds ({len(dog_list)}): {dog_list}")

print("\n[DONE] Dataset loaded successfully.")
