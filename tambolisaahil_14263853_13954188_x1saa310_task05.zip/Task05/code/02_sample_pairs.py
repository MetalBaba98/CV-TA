"""
02_sample_pairs.py
==================
Section 2 (continued): Saves sample image pairs illustrating two visual
factors that make breed classification difficult.

Factor 1 -- Inter-class similarity:
    Two DIFFERENT breeds that look alike (Staffordshire Bull Terrier vs
    American Pit Bull Terrier).

Factor 2 -- Intra-class dissimilarity:
    Two images from the SAME breed (Beagle) that look very different due
    to pose, lighting, background, or age variation.

Usage:
    python 02_sample_pairs.py
"""

import os
import random
import numpy as np
import torch
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from torchvision.datasets import OxfordIIITPet

# ---------------------------------------------------------------------------
# Reproducibility
# ---------------------------------------------------------------------------
SEED = 42
random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)

# Paths
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_DIR = os.path.dirname(SCRIPT_DIR)
IMAGE_DIR = os.path.join(PROJECT_DIR, "images")
DATA_DIR = os.path.join(SCRIPT_DIR, "data")
os.makedirs(IMAGE_DIR, exist_ok=True)

# ===========================================================================
# Load dataset
# ===========================================================================
print("Loading trainval dataset...")
trainval_dataset = OxfordIIITPet(
    root=DATA_DIR, split="trainval", target_types="category", download=True
)

class_names = trainval_dataset.classes


def get_images_for_class(dataset, class_name, n=2):
    """Return the first n PIL images belonging to `class_name`."""
    target_idx = dataset.classes.index(class_name)
    images = []
    for i in range(len(dataset)):
        img, label = dataset[i]
        if label == target_idx:
            images.append(img)
            if len(images) >= n:
                break
    return images


# ===========================================================================
# Factor 1: Inter-class similarity
# ===========================================================================
print("\n--- Factor 1: Inter-class similarity ---")
breed_a = "Staffordshire Bull Terrier"
breed_b = "American Pit Bull Terrier"
print(f"  Breeds: {breed_a}  vs  {breed_b}")

imgs_a = get_images_for_class(trainval_dataset, breed_a, n=1)
imgs_b = get_images_for_class(trainval_dataset, breed_b, n=1)

fig, axes = plt.subplots(1, 2, figsize=(10, 5))
axes[0].imshow(imgs_a[0])
axes[0].set_title(breed_a, fontsize=12)
axes[0].axis("off")
axes[1].imshow(imgs_b[0])
axes[1].set_title(breed_b, fontsize=12)
axes[1].axis("off")
fig.suptitle("Factor 1: Inter-class Similarity\n(Different breeds that look alike)",
             fontsize=14, fontweight="bold")
plt.tight_layout()
plt.savefig(os.path.join(IMAGE_DIR, "factor1_interclass_similarity.png"), dpi=200)
plt.close()
print("  Saved: ../images/factor1_interclass_similarity.png")

# Also save individual images for LaTeX flexibility
imgs_a[0].save(os.path.join(IMAGE_DIR, "inter_class_similar_staffordshire.png"))
imgs_b[0].save(os.path.join(IMAGE_DIR, "inter_class_similar_pitbull.png"))

# ===========================================================================
# Factor 2: Intra-class dissimilarity
# ===========================================================================
print("\n--- Factor 2: Intra-class dissimilarity ---")
breed_c = "Beagle"
print(f"  Breed: {breed_c} (two visually different samples)")

imgs_c = get_images_for_class(trainval_dataset, breed_c, n=10)

fig, axes = plt.subplots(1, 2, figsize=(10, 5))
axes[0].imshow(imgs_c[0])
axes[0].set_title(f"{breed_c} -- sample 1", fontsize=12)
axes[0].axis("off")
axes[1].imshow(imgs_c[-1])
axes[1].set_title(f"{breed_c} -- sample 2", fontsize=12)
axes[1].axis("off")
fig.suptitle("Factor 2: Intra-class Dissimilarity\n(Same breed, different appearance)",
             fontsize=14, fontweight="bold")
plt.tight_layout()
plt.savefig(os.path.join(IMAGE_DIR, "factor2_intraclass_dissimilarity.png"), dpi=200)
plt.close()
print("  Saved: ../images/factor2_intraclass_dissimilarity.png")

# Also save individual images
imgs_c[0].save(os.path.join(IMAGE_DIR, "intra_class_dissimilar_beagle_1.png"))
imgs_c[-1].save(os.path.join(IMAGE_DIR, "intra_class_dissimilar_beagle_2.png"))

print("\n[DONE] Sample pairs saved.")
