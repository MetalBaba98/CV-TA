================================================================================
CSO-610 (Summer 2025-26) -- Task 05: Measure your transformation!
Submission Readme & Documentation
================================================================================

HONOR CODE
----------
Team: Saahil Tamboli and Narasinga Rao T.

We went through the entire project together and shared the dataset exploration,
DINOv2 feature extraction, t-SNE visualisation, and linear-probe classification
work between us.

For the LaTeX write-up, the Python implementation, and parts of the research/
understanding of DINOv2 and t-SNE, we used Claude Code (Anthropic) and Gemini
AI Assistant (Google DeepMind) to: scaffold and run the dataset/embedding
extraction/t-SNE/linear-probe scripts (code/01..05_*.py), resolve a corporate-
proxy SSL certificate issue when downloading the dataset and DINOv2 checkpoint,
explain concepts such as the [CLS] token and why the backbone is "frozen", and
draft the written explanations in task-body.tex. All breed-pair choices, plot
interpretations, and final numbers were reviewed and verified by us against
the actual generated plots/output before submission.

References:
- DINOv2 paper: Vision Transformers Need Registers (arXiv:2304.07193)
- Hugging Face DINOv2 documentation: https://huggingface.co/docs/transformers/model_doc/dinov2
- Oxford-IIIT Pet dataset page: https://www.robots.ox.ac.uk/~vgg/data/pets/
- torchvision OxfordIIITPet docs: https://pytorch.org/vision/stable/generated/torchvision.datasets.OxfordIIITPet.html


ENVIRONMENT & PACKAGE VERSIONS
-------------------------------
The code was executed and verified under Python 3.13 / Python 3.10 with the
following exact package versions:

  torch==2.12.0
  torchvision==0.27.0
  transformers==4.53.2
  scikit-learn==1.7.0
  matplotlib==3.11.0
  Pillow==11.3.0
  numpy==2.2.6

All dependencies are listed in code/requirements.txt.


REPRODUCTION INSTRUCTIONS
--------------------------
To reproduce all reported figures, tensor shapes, and classification metrics
from scratch:

1. Open terminal and navigate to the code/ directory:
       cd code/

2. Install dependencies:
       pip install -r requirements.txt

3. Run the modular Python scripts in sequential order:

   Step 1: Dataset statistics and information
       python 01_dataset_info.py
       -> Downloads Oxford-IIIT Pet dataset into code/data/
       -> Reports trainval count (3680), test count (3669), and class count (37).

   Step 2: Visual factors sample images
       python 02_sample_pairs.py
       -> Generates and saves sample images for Inter-class similarity
          (Staffordshire Bull Terrier vs American Pit Bull Terrier) and
          Intra-class dissimilarity (Beagle) to ../images/.

   Step 3: DINOv2 feature extraction
       python 03_extract_embeddings.py
       -> Loads facebook/dinov2-small (frozen backbone).
       -> Extracts [CLS] embedding tensor (last_hidden_state[:, 0, :]).
       -> Reports exact PyTorch tensor shapes for a batch of 64 images:
            Input pixel_values: torch.Size([64, 3, 224, 224])
            Last hidden state:  torch.Size([64, 257, 384])
            Extracted [CLS]:    torch.Size([64, 384])
       -> Saves feature embeddings to ../embeddings/dinov2_small_embeddings.npz.

   Step 4: t-SNE manifold projections
       python 04_tsne_plots.py
       -> Standardises test embeddings with StandardScaler.
       -> Runs TSNE(n_components=2, random_state=42, perplexity=30, max_iter=1000).
       -> Saves ../images/tsne_cat_vs_dog.png and ../images/tsne_6breed_subset.png.

   Step 5: Linear probe classification
       python 05_linear_probe.py
       -> Standardises embeddings (StandardScaler fitted strictly on trainval).
       -> Trains LogisticRegression(max_iter=2000, random_state=42) on trainval.
       -> Evaluates on test split and reports:
            Test Accuracy  : 0.9469
            Macro F1 Score : 0.9461
       -> Saves detailed per-class report to ../results/classification_report.txt.

   (Alternatively, running `python main.py` executes the entire pipeline end-to-end.)


RANDOM SEEDS & REPRODUCIBILITY
-------------------------------
All random seeds across PyTorch, NumPy, scikit-learn TSNE, and LogisticRegression
are explicitly fixed to 42.
================================================================================
