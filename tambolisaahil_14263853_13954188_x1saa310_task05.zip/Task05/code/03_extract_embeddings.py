"""
03_extract_embeddings.py
========================
Section 3: DINOv2 feature extraction.
Loads facebook/dinov2-small (frozen), extracts [CLS] embeddings for every
trainval and test image, reports tensor shapes, and saves embeddings to
../embeddings/dinov2_small_embeddings.npz.

Usage:
    python 03_extract_embeddings.py
"""

import os
import random
import numpy as np
import torch
from torchvision.datasets import OxfordIIITPet
from transformers import AutoImageProcessor, AutoModel

# ---------------------------------------------------------------------------
# Reproducibility
# ---------------------------------------------------------------------------
SEED = 42
random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)
if torch.cuda.is_available():
    torch.cuda.manual_seed_all(SEED)

# Paths
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_DIR = os.path.dirname(SCRIPT_DIR)
DATA_DIR = os.path.join(SCRIPT_DIR, "data")
EMB_DIR = os.path.join(PROJECT_DIR, "embeddings")
os.makedirs(EMB_DIR, exist_ok=True)

# ===========================================================================
# Load dataset
# ===========================================================================
print("Loading datasets...")
trainval_dataset = OxfordIIITPet(
    root=DATA_DIR, split="trainval", target_types="category", download=True
)
test_dataset = OxfordIIITPet(
    root=DATA_DIR, split="test", target_types="category", download=True
)

# ===========================================================================
# Load DINOv2-small (frozen)
# ===========================================================================
print("=" * 70)
print("SECTION 3: DINOv2 Feature Extraction")
print("=" * 70)

MODEL_NAME = "facebook/dinov2-small"
print(f"\nLoading model: {MODEL_NAME} ...")
processor = AutoImageProcessor.from_pretrained(MODEL_NAME)
model = AutoModel.from_pretrained(MODEL_NAME)
model.eval()  # frozen / inference mode -- no gradient updates

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = model.to(device)
print(f"Model loaded on device: {device}")


def extract_embeddings(dataset, batch_size=64):
    """
    Extract the final-layer [CLS] embedding from DINOv2 for every image.

    For each image the model returns:
        last_hidden_state : (batch, seq_len, hidden_dim)
    where seq_len = 1 [CLS] + num_patches (= 257 for 224x224 with 16x16 patches).

    We take position 0 along the sequence axis:
        cls_embedding = last_hidden_state[:, 0, :]   shape (batch, 384)

    Returns
    -------
    embeddings : np.ndarray, shape (N, 384)
    labels     : np.ndarray, shape (N,)
    """
    all_embeddings = []
    all_labels = []

    # Collect all PIL images and integer labels
    images, labels = [], []
    for i in range(len(dataset)):
        img, label = dataset[i]
        images.append(img)
        labels.append(label)

    num_images = len(images)
    reported_shapes = False

    for start in range(0, num_images, batch_size):
        end = min(start + batch_size, num_images)
        batch_imgs = images[start:end]

        # The Hugging Face image processor resizes, centre-crops, and
        # normalises each PIL image, then stacks them into a single tensor.
        inputs = processor(images=batch_imgs, return_tensors="pt")
        pixel_values = inputs["pixel_values"].to(device)

        with torch.no_grad():
            outputs = model(pixel_values)

        last_hidden = outputs.last_hidden_state   # (batch, 257, 384)
        cls_embeddings = last_hidden[:, 0, :]      # (batch, 384)

        # Print tensor shapes for the FIRST batch only
        if not reported_shapes:
            print(f"\n--- Tensor shapes (batch of {end - start} images) ---")
            print(f"  Processed input tensor (pixel_values) : {pixel_values.shape}")
            print(f"    -> (batch_size={pixel_values.shape[0]}, "
                  f"channels={pixel_values.shape[1]}, "
                  f"height={pixel_values.shape[2]}, "
                  f"width={pixel_values.shape[3]})")
            print(f"  Complete final hidden-state tensor     : {last_hidden.shape}")
            print(f"    -> (batch_size={last_hidden.shape[0]}, "
                  f"sequence_length={last_hidden.shape[1]}, "
                  f"hidden_dim={last_hidden.shape[2]})")
            print(f"       sequence_length = 1 [CLS] + {last_hidden.shape[1]-1} patches")
            print(f"  Extracted [CLS] embedding tensor       : {cls_embeddings.shape}")
            print(f"    -> (batch_size={cls_embeddings.shape[0]}, "
                  f"hidden_dim={cls_embeddings.shape[1]})")
            reported_shapes = True

        all_embeddings.append(cls_embeddings.cpu().numpy())
        all_labels.extend(labels[start:end])

        if (start // batch_size) % 10 == 0:
            print(f"  Processed {end}/{num_images} images...")

    embeddings = np.concatenate(all_embeddings, axis=0)
    labels_arr = np.array(all_labels)
    return embeddings, labels_arr


# ===========================================================================
# Extract embeddings
# ===========================================================================
print("\nExtracting trainval embeddings...")
train_embeddings, train_labels = extract_embeddings(trainval_dataset, batch_size=64)
print(f"Trainval embeddings shape: {train_embeddings.shape}")
print(f"Trainval labels shape:     {train_labels.shape}")

print("\nExtracting test embeddings...")
test_embeddings, test_labels = extract_embeddings(test_dataset, batch_size=64)
print(f"Test embeddings shape: {test_embeddings.shape}")
print(f"Test labels shape:     {test_labels.shape}")

# Report dimensionality
embedding_dim = train_embeddings.shape[1]
print(f"\nDimensionality of a single DINOv2-small embedding: {embedding_dim}")
print(f"Trainval: {train_embeddings.shape[0]} embeddings  (dataset has {len(trainval_dataset)} images)")
print(f"Test:     {test_embeddings.shape[0]} embeddings  (dataset has {len(test_dataset)} images)")
assert train_embeddings.shape[0] == len(trainval_dataset), "Mismatch!"
assert test_embeddings.shape[0] == len(test_dataset), "Mismatch!"
print("[OK] Verified: exactly one embedding per image.")

# ===========================================================================
# Save embeddings to disk (not submitted -- can be regenerated)
# ===========================================================================
save_path = os.path.join(EMB_DIR, "dinov2_small_embeddings.npz")
np.savez(
    save_path,
    train_embeddings=train_embeddings,
    train_labels=train_labels,
    test_embeddings=test_embeddings,
    test_labels=test_labels,
    class_names=np.array(trainval_dataset.classes),
)
print(f"\nEmbeddings saved to: {save_path}")
print("[DONE] Feature extraction complete.")
