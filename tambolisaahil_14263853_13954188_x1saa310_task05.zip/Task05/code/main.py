"""
Task 05: Measure Your Transformation!
======================================
DINOv2 (frozen) feature extraction on Oxford-IIIT Pet Dataset,
t-SNE visualization, and linear probe (logistic regression) evaluation.

Usage:
    python main.py

All output images are saved to ../images/
All metrics are printed to stdout.

Seeds: 42 everywhere (PyTorch, NumPy, sklearn, t-SNE).
"""

import os
import random
import numpy as np
import torch
import matplotlib
matplotlib.use("Agg")  # non-interactive backend
import matplotlib.pyplot as plt
from torch.utils.data import DataLoader
from torchvision.datasets import OxfordIIITPet
from torchvision import transforms
from transformers import AutoImageProcessor, AutoModel
from sklearn.manifold import TSNE
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score
from PIL import Image

# ---------------------------------------------------------------------------
# 0. Reproducibility — set all random seeds to 42
# ---------------------------------------------------------------------------
SEED = 42
random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)
if torch.cuda.is_available():
    torch.cuda.manual_seed_all(SEED)

# Paths
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_DIR = os.path.dirname(SCRIPT_DIR)           # Task05/
IMAGE_DIR = os.path.join(PROJECT_DIR, "images")
DATA_DIR = os.path.join(SCRIPT_DIR, "data")          # dataset downloaded here
os.makedirs(IMAGE_DIR, exist_ok=True)
os.makedirs(DATA_DIR, exist_ok=True)

# ===========================================================================
# SECTION 2 — Dataset
# ===========================================================================
print("=" * 70)
print("SECTION 2: Dataset")
print("=" * 70)

trainval_dataset = OxfordIIITPet(
    root=DATA_DIR, split="trainval", target_types="category", download=True
)
test_dataset = OxfordIIITPet(
    root=DATA_DIR, split="test", target_types="category", download=True
)

# Class names come from the dataset's internal list
class_names = trainval_dataset.classes  # list of 37 breed names
num_classes = len(class_names)

print(f"Number of training (trainval) images : {len(trainval_dataset)}")
print(f"Number of test images                : {len(test_dataset)}")
print(f"Number of classes (breeds)           : {num_classes}")
print(f"Class names: {class_names}")

# ---- Cat / Dog mapping ----
# The Oxford-IIIT Pet dataset convention: class names that start with an
# uppercase letter are cats; class names that start with a lowercase letter
# are dogs.  Alternatively, the first 12 alphabetically-sorted breeds are
# cats.  We derive it from the dataset's own _breed_annotations:
# Cat breeds (12): Abyssinian, Bengal, Birman, Bombay, British_Shorthair,
#   Egyptian_Mau, Maine_Coon, Persian, Ragdoll, Russian_Blue, Siamese, Sphynx
# All remaining 25 breeds are dogs.
CAT_BREEDS = {
    "Abyssinian", "Bengal", "Birman", "Bombay", "British Shorthair",
    "Egyptian Mau", "Maine Coon", "Persian", "Ragdoll", "Russian Blue",
    "Siamese", "Sphynx",
}

def is_cat(class_name):
    return class_name in CAT_BREEDS

# Build cat/dog label for every class index
catdog_map = {}  # class_idx -> 'Cat' or 'Dog'
for idx, name in enumerate(class_names):
    catdog_map[idx] = "Cat" if is_cat(name) else "Dog"

print("\nCat breeds:", sorted([n for n in class_names if is_cat(n)]))
print("Dog breeds:", sorted([n for n in class_names if not is_cat(n)]))

# ---- Save sample images for inter-class similarity & intra-class dissimilarity ----

def get_class_index(dataset, class_name):
    """Return the integer label for a given class name."""
    return dataset.classes.index(class_name)

def get_images_for_class(dataset, class_name, n=2):
    """Return the first n PIL images belonging to `class_name`."""
    target_idx = get_class_index(dataset, class_name)
    images = []
    for i in range(len(dataset)):
        img, label = dataset[i]
        if label == target_idx:
            images.append(img)
            if len(images) >= n:
                break
    return images

print("\nSaving sample images for visual factor discussion...")

# Factor 1: Inter-class similarity — two DIFFERENT breeds that look alike
# Staffordshire Bull Terrier vs. American Pit Bull Terrier
similar_breed_1 = "Staffordshire Bull Terrier"
similar_breed_2 = "American Pit Bull Terrier"

imgs_1 = get_images_for_class(trainval_dataset, similar_breed_1, n=1)
imgs_2 = get_images_for_class(trainval_dataset, similar_breed_2, n=1)

if imgs_1:
    imgs_1[0].save(os.path.join(IMAGE_DIR, "inter_class_similar_staffordshire.png"))
if imgs_2:
    imgs_2[0].save(os.path.join(IMAGE_DIR, "inter_class_similar_pitbull.png"))

print(f"  Inter-class similar pair: {similar_breed_1} vs {similar_breed_2}")

# Factor 2: Intra-class dissimilarity — SAME breed, very different-looking samples
# Pick a breed with high visual variation, e.g., 'beagle' (different poses/lighting)
dissimilar_breed = "Beagle"
imgs_d = get_images_for_class(trainval_dataset, dissimilar_breed, n=10)
# Pick the first and last to maximize visual difference
if len(imgs_d) >= 2:
    imgs_d[0].save(os.path.join(IMAGE_DIR, "intra_class_dissimilar_beagle_1.png"))
    imgs_d[-1].save(os.path.join(IMAGE_DIR, "intra_class_dissimilar_beagle_2.png"))

print(f"  Intra-class dissimilar pair: two samples of {dissimilar_breed}")
print("  Sample images saved to ../images/")


# ===========================================================================
# SECTION 3 — DINOv2 as a Feature Extractor
# ===========================================================================
print("\n" + "=" * 70)
print("SECTION 3: DINOv2 Feature Extraction")
print("=" * 70)

# Load the DINOv2-small model and processor from Hugging Face
MODEL_NAME = "facebook/dinov2-small"
print(f"Loading model: {MODEL_NAME} ...")
processor = AutoImageProcessor.from_pretrained(MODEL_NAME)
model = AutoModel.from_pretrained(MODEL_NAME)
model.eval()  # freeze / inference mode

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = model.to(device)
print(f"Model loaded on device: {device}")


def extract_embeddings(dataset, batch_size=64):
    """
    Extract [CLS] embeddings from DINOv2 for every image in `dataset`.
    Returns:
        embeddings: np.ndarray of shape (N, D)
        labels:     np.ndarray of shape (N,)
    """
    all_embeddings = []
    all_labels = []

    # Collect all images and labels first
    images = []
    labels = []
    for i in range(len(dataset)):
        img, label = dataset[i]
        images.append(img)
        labels.append(label)

    num_images = len(images)
    reported_shapes = False

    for start in range(0, num_images, batch_size):
        end = min(start + batch_size, num_images)
        batch_imgs = images[start:end]

        # Process images using the Hugging Face image processor
        inputs = processor(images=batch_imgs, return_tensors="pt")
        pixel_values = inputs["pixel_values"].to(device)

        with torch.no_grad():
            outputs = model(pixel_values)

        # outputs.last_hidden_state shape: (batch, seq_len, hidden_dim)
        # [CLS] token is at position 0
        last_hidden = outputs.last_hidden_state
        cls_embeddings = last_hidden[:, 0, :]  # (batch, hidden_dim)

        # Report shapes for the first batch only
        if not reported_shapes:
            print(f"\n--- Tensor shapes (first batch of {end - start} images) ---")
            print(f"  Processed input tensor (pixel_values) : {pixel_values.shape}")
            print(f"    -> (batch_size, channels, height, width)")
            print(f"  Complete final hidden-state tensor     : {last_hidden.shape}")
            print(f"    -> (batch_size, sequence_length, hidden_dim)")
            print(f"       sequence_length = 1 [CLS] + num_patches")
            print(f"  Extracted [CLS] embedding tensor       : {cls_embeddings.shape}")
            print(f"    -> (batch_size, hidden_dim)")
            reported_shapes = True

        all_embeddings.append(cls_embeddings.cpu().numpy())
        all_labels.extend(labels[start:end])

        if (start // batch_size) % 10 == 0:
            print(f"  Processed {end}/{num_images} images...")

    embeddings = np.concatenate(all_embeddings, axis=0)
    labels_arr = np.array(all_labels)
    return embeddings, labels_arr


print("\nExtracting trainval embeddings...")
train_embeddings, train_labels = extract_embeddings(trainval_dataset, batch_size=64)
print(f"Trainval embeddings shape: {train_embeddings.shape}")
print(f"Trainval labels shape:     {train_labels.shape}")

print("\nExtracting test embeddings...")
test_embeddings, test_labels = extract_embeddings(test_dataset, batch_size=64)
print(f"Test embeddings shape: {test_embeddings.shape}")
print(f"Test labels shape:     {test_labels.shape}")

# Report embedding dimensionality
embedding_dim = train_embeddings.shape[1]
print(f"\nDimensionality of a single DINOv2-small image embedding: {embedding_dim}")
print(f"Number of trainval embeddings: {train_embeddings.shape[0]}  (should equal {len(trainval_dataset)})")
print(f"Number of test embeddings:     {test_embeddings.shape[0]}  (should equal {len(test_dataset)})")
assert train_embeddings.shape[0] == len(trainval_dataset), "Mismatch in trainval count!"
assert test_embeddings.shape[0] == len(test_dataset), "Mismatch in test count!"
print("[OK] Verified: exactly one embedding per image.")


# ===========================================================================
# SECTION 4 — t-SNE Visualization
# ===========================================================================
print("\n" + "=" * 70)
print("SECTION 4: t-SNE Visualization")
print("=" * 70)

# Standardize test embeddings before t-SNE (zero mean, unit variance)
print("Standardizing test embeddings before t-SNE (StandardScaler)...")
scaler_tsne = StandardScaler()
test_embeddings_std = scaler_tsne.fit_transform(test_embeddings)

print(f"Running t-SNE (random_state={SEED}) on {test_embeddings_std.shape[0]} test embeddings...")
tsne = TSNE(n_components=2, random_state=SEED, perplexity=30, max_iter=1000)
test_tsne_2d = tsne.fit_transform(test_embeddings_std)
print(f"t-SNE output shape: {test_tsne_2d.shape}")

# ---- Plot 1: Cat vs. Dog ----
print("\nGenerating Plot 1: Cat vs. Dog t-SNE...")
catdog_labels = np.array([catdog_map[l] for l in test_labels])

fig, ax = plt.subplots(1, 1, figsize=(10, 8))
colors_cd = {"Cat": "#FF6B6B", "Dog": "#4ECDC4"}
for species in ["Cat", "Dog"]:
    mask = catdog_labels == species
    ax.scatter(
        test_tsne_2d[mask, 0], test_tsne_2d[mask, 1],
        c=colors_cd[species], label=species, alpha=0.5, s=12, edgecolors="none"
    )
ax.set_title("t-SNE of DINOv2 [CLS] Embeddings — Cat vs. Dog", fontsize=14)
ax.set_xlabel("t-SNE Dimension 1")
ax.set_ylabel("t-SNE Dimension 2")
ax.legend(fontsize=12, markerscale=3)
ax.set_aspect("equal", adjustable="datalim")
plt.tight_layout()
plt.savefig(os.path.join(IMAGE_DIR, "tsne_cat_dog.png"), dpi=200)
plt.close()
print("  Saved: ../images/tsne_cat_dog.png")

# ---- Plot 2: 6-Breed Subset ----
SELECTED_BREEDS = [
    "Staffordshire Bull Terrier",  # inter-class similar (dog)
    "American Pit Bull Terrier",   # inter-class similar (dog)
    "Chihuahua",                   # visually distinct dog
    "Great Pyrenees",              # visually distinct dog
    "Persian",                     # cat
    "Siamese",                     # cat
]

print(f"\nGenerating Plot 2: 6-Breed Subset t-SNE...")
print(f"  Selected breeds: {SELECTED_BREEDS}")

# Map breed names to class indices
breed_to_idx = {name: i for i, name in enumerate(class_names)}
selected_indices = []
for b in SELECTED_BREEDS:
    if b in breed_to_idx:
        selected_indices.append(breed_to_idx[b])
    else:
        raise ValueError(f"Breed '{b}' not found in class names: {class_names}")

print(f"  Class indices: {selected_indices}")

# Get display names (matching actual class_names)
selected_display = []
for idx in selected_indices:
    selected_display.append(class_names[idx])

# Filter test points belonging to these 6 breeds
mask_6 = np.isin(test_labels, selected_indices)
tsne_6 = test_tsne_2d[mask_6]
labels_6 = test_labels[mask_6]

fig, ax = plt.subplots(1, 1, figsize=(10, 8))
colors_6 = ["#E63946", "#457B9D", "#2A9D8F", "#E9C46A", "#F4A261", "#264653"]
for i, (cls_idx, display_name) in enumerate(zip(selected_indices, selected_display)):
    m = labels_6 == cls_idx
    ax.scatter(
        tsne_6[m, 0], tsne_6[m, 1],
        c=colors_6[i], label=display_name, alpha=0.7, s=25, edgecolors="none"
    )

ax.set_title("t-SNE of DINOv2 [CLS] Embeddings — 6-Breed Subset", fontsize=14)
ax.set_xlabel("t-SNE Dimension 1")
ax.set_ylabel("t-SNE Dimension 2")
ax.legend(fontsize=10, markerscale=2, loc="best")
ax.set_aspect("equal", adjustable="datalim")
plt.tight_layout()
plt.savefig(os.path.join(IMAGE_DIR, "tsne_6breeds.png"), dpi=200)
plt.close()
print("  Saved: ../images/tsne_6breeds.png")


# ===========================================================================
# SECTION 5 — Classification (Linear Probe)
# ===========================================================================
print("\n" + "=" * 70)
print("SECTION 5: Linear Probe Classification")
print("=" * 70)

# Standardize embeddings: fit on trainval, transform both
print("Standardizing embeddings (fit on trainval, apply to both)...")
scaler_clf = StandardScaler()
X_train = scaler_clf.fit_transform(train_embeddings)
X_test = scaler_clf.transform(test_embeddings)

print(f"Training Logistic Regression (max_iter=2000, random_state={SEED})...")
clf = LogisticRegression(max_iter=2000, random_state=SEED)
clf.fit(X_train, train_labels)

# Predict on test
y_pred = clf.predict(X_test)

# Metrics
test_accuracy = accuracy_score(test_labels, y_pred)
test_f1 = f1_score(test_labels, y_pred, average="macro")

print(f"\n{'='*50}")
print(f"  Test Accuracy  : {test_accuracy:.4f}")
print(f"  Macro F1 Score : {test_f1:.4f}")
print(f"{'='*50}")

print("\n" + "=" * 70)
print("ALL DONE. Images saved to ../images/")
print("=" * 70)
