1. Olympus SIS ID
x3san819
2. Which external person (human resource) or TA I consulted:
None
3. What non-human resources I used on the Internet:
a. https://www.abhik.ai/concepts/transformers/cls-token
b. https://www.abhik.ai/concepts/transformers/self-attention-vit
c. https://gemini.google.com/app/73f7e9b92bc9d121



GroupId: 22
Learner Id: Y23
Signed by: Satvik, x3san819