from torchvision.datasets import OxfordIIITPet
from pathlib import Path
import random
import torch
import numpy as np

ROOT = Path(__file__).resolve().parent.parent
DATA_ROOT = ROOT / "data"
IMAGES_DIR = ROOT / "images"
IMAGES_DIR.mkdir(exist_ok=True)
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
SEED = 42
random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)
if torch.cuda.is_available():
    torch.cuda.manual_seed_all(SEED)

# Dataset
train_dataset = OxfordIIITPet(
    root=str(DATA_ROOT),
    split="trainval",
    target_types="category",
    download=True,
)
test_dataset = OxfordIIITPet(
    root=str(DATA_ROOT),
    split="test",
    target_types="category",
    download=True,
)

print("Train size:", len(train_dataset))
print("Test size:", len(test_dataset))
print("Classes:", len(train_dataset.classes))

from transformers import AutoImageProcessor, AutoModelForImageClassification
import torch

processor = AutoImageProcessor.from_pretrained("facebook/dinov2-small")
dinov2 = AutoModelForImageClassification.from_pretrained("facebook/dinov2-small",attn_implementation="sdpa")

BATCH_SIZE = 32

def extract_from_dataset(dataset, batch_size=16):
    all_embeds = []
    all_labels = []
    with torch.no_grad():
        for start in range(0, len(dataset), batch_size):
            end = min(start + batch_size, len(dataset))
            batch = [dataset[idx] for idx in range(start, end)]
            images = [sample[0] for sample in batch]
            labels = np.array([sample[1] for sample in batch])
            processed = processor(images=images, return_tensors="pt")
            pixel_values = processed["pixel_values"].to(DEVICE)
            outputs = dinov2(**{"pixel_values": pixel_values}, output_hidden_states=True)
            cls_emb = outputs.hidden_states[-1][:, 0, :].cpu().numpy()
            all_embeds.append(cls_emb)
            all_labels.append(labels)
    embeddings = np.vstack(all_embeds)
    labels = np.concatenate(all_labels)
    return embeddings, labels
# Cat vs dog labels derived from breed names.
cat_breeds = {
    "abyssinian", "bengal", "birman", "bombay", "british shorthair", "egyptian mau",
    "maine coon", "persian", "ragdoll", "russian blue", "siamese", "sphynx"
}
dog_breeds = {
    "american bulldog", "american pit bull terrier", "basset hound", "beagle", "boxer", "chihuahua",
    "english cocker spaniel", "english setter", "german shorthaired", "great pyrenees",
    "havanese", "japanese chin", "keeshond", "leonberger", "miniature pinscher",
    "newfoundland", "pomeranian", "pug", "saint bernard", "samoyed", "scottish terrier",
    "shiba inu", "staffordshire bull terrier", "wheaten terrier", "yorkshire terrier"
}
breed_to_superlabel = {}
for breed in cat_breeds:
    normalized = breed.replace(" ", "_")
    breed_to_superlabel[normalized] = "cat"
    breed_to_superlabel[breed] = "cat"
for breed in dog_breeds:
    normalized = breed.replace(" ", "_")
    breed_to_superlabel[normalized] = "dog"
    breed_to_superlabel[breed] = "dog"


def normalize_breed_name(name: str) -> str:
    return name.lower().replace(" ", "_")

from sklearn.manifold import TSNE
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler

scaler = StandardScaler()
train_embeddings, train_labels = extract_from_dataset(train_dataset, batch_size=16)
test_embeddings, test_labels = extract_from_dataset(test_dataset, batch_size=16)
train_embeddings_scaled = scaler.fit_transform(train_embeddings)
test_embeddings_scaled = scaler.transform(test_embeddings)

def plot1n2():

    fig, ax = plt.subplots(figsize=(7, 5))
    # t-SNE for test split
    tsne = TSNE(n_components=2, random_state=422, init="pca", perplexity=30)
    tsne_coords = tsne.fit_transform(test_embeddings_scaled)
    class_names = np.array(test_dataset.classes)
    plot_labels = [normalize_breed_name(c) for c in class_names[test_labels]]
    # print(plot_labels, breeds6)
    plot_supercat = np.array([
        breed_to_superlabel.get(c, "unknown") for c in plot_labels
    ])

    fig, ax = plt.subplots(figsize=(7, 5))
    colors = {"cat": "blue", "dog": "red"}
    for label in ["cat", "dog"]:
        mask = plot_supercat == label
        ax.scatter(tsne_coords[mask, 0], tsne_coords[mask, 1], c=colors[label], label=label, alpha=0.75, s=28)
    ax.set_title("Cat vs Dog Structure")
    ax.legend(title="Super-category")
    fig.tight_layout()
    fig.savefig(IMAGES_DIR / "Cat_vs_Dog_Structure.png")

    breeds6 = ['abyssinian', 'siamese', 'birman', 'egyptian_mau', 'bengal', 'russian_blue']
    colors6 = ['red', 'blue', 'green', 'yellow', 'pink', 'cyan']
    fig, ax = plt.subplots(figsize=(7, 5))
    plot_labels_array = np.array(plot_labels)
    for i, breed in enumerate(breeds6):
        mask = plot_labels_array == breed
        ax.scatter(tsne_coords[mask, 0], tsne_coords[mask, 1], c=colors6[i], label=breed, alpha=0.75, s=28)
    ax.set_title('6 breed subset')
    ax.legend(title="6 breed subset")
    fig.tight_layout()
    fig.savefig(IMAGES_DIR / "Six_breed_subset.png")
plot1n2()

from sklearn.metrics import accuracy_score, f1_score
def train_predict():
    from sklearn.linear_model import LogisticRegression
    classifier = LogisticRegression(max_iter=2000, random_state=SEED)
    classifier.fit(train_embeddings_scaled, train_labels)
    pred = classifier.predict(test_embeddings_scaled)
    acc = accuracy_score(test_labels, pred)
    f1_macro = f1_score(test_labels, pred, average="macro")
    print("Test accuracy:", acc)
    print("Macro F1:", f1_macro)
train_predict()