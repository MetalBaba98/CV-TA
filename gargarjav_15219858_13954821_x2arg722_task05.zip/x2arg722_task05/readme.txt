1. Olympus SIS ID
    x2arg722
    Team members: Arjav Garg, Thakur Patel
    Contribution: 60%, 40%

2. Which external person (human resource) or TA I consulted:

3. What non-human resources I used on the Internet:
    https://docs.pytorch.org/vision/stable
	https://scikit-learn.org/stable/modules/generated/sklearn.manifold.TSNE.html 

4. I pledge on my honour that I have not given or received any unauthorized assistance on this assignment or any previous task.
    Signed by: <Arjav Garg, x2arg722>