import cv2
import numpy as np
import matplotlib.pyplot as plt

# -----------------------------
# 1. Read image
# -----------------------------
img = cv2.imread("../images/chair.png")   # change path if needed
if img is None:
    raise FileNotFoundError("Could not read chair.png")

print("Image shape:", img.shape)

# -----------------------------
# 2. Camera intrinsic matrix K
#    Replace with your final calibrated K if available
# -----------------------------
K = np.array([
    [25920, 0, 4056],
    [0, 25920, 3072],
    [0, 0, 1]
], dtype=np.float64)

# If you do not have distortion coefficients, use zeros
dist_coeffs = np.zeros((5, 1), dtype=np.float64)

# -----------------------------
# 3. Define 3D object points
#    Units here are in cm
#    Replace with your real measured points
# -----------------------------
obj_points = np.array([
    [0, 0, 0],
    [0, 0, 40],
    [35, 0, 0],
    [35, 35, 0],
    [0, 35, 40],
    [20, 15, 20]
], dtype=np.float64)



# -----------------------------
# 4. Define matching 2D image points
#    Replace these with manually marked pixel coordinates
# -----------------------------
img_points = np.array([
    [120, 260],
    [115, 160],
    [180, 255],
    [190, 210],
    [110, 130],
    [160, 190]
], dtype=np.float64)

# -----------------------------
# 5. Solve PnP
# -----------------------------
success, rvec, tvec = cv2.solvePnP(
    obj_points,
    img_points,
    K,
    dist_coeffs,
    flags=cv2.SOLVEPNP_ITERATIVE
)

if not success:
    raise RuntimeError("solvePnP failed")

# -----------------------------
# 6. Convert rotation vector to rotation matrix
# -----------------------------
R, _ = cv2.Rodrigues(rvec)

# Camera position in object/world coordinates
camera_position = -R.T @ tvec

# Distance from camera to origin
distance_cm = np.linalg.norm(camera_position)

# -----------------------------
# 7. Print results
# -----------------------------
print("\nRotation vector (rvec):\n", rvec)
print("\nTranslation vector (tvec):\n", tvec)
print("\nRotation matrix (R):\n", R)
print("\nCamera position in object coordinates:\n", camera_position)
print("\nEstimated distance from camera to object origin (cm):", float(distance_cm))

# -----------------------------
# 8. Draw the 2D points on image for checking
# -----------------------------
labels = ["O", "A", "B", "C", "D"]

for pt, label in zip(img_points, labels):
    x, y = int(pt[0]), int(pt[1])
    cv2.circle(img, (x, y), 5, (0, 0, 255), -1)
    cv2.putText(img, label, (x + 5, y - 5),
                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 0, 0), 1)
# -----------------------------
# 9. Save output image
# -----------------------------
output_path = "../images/chair_annotated.jpg"
saved = cv2.imwrite(output_path, img)

if saved:
    print(f"\nAnnotated image saved as: {output_path}")
else:
    print("\nFailed to save annotated image")

# -----------------------------
# 10. Show image
# -----------------------------


plt.figure(figsize=(8, 6))
plt.imshow(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
plt.axis("off")
plt.show()