-> Using 1 free latedaytask

-> Contents of Folder x2ans362_task04: 

  x2ans362_latedayTask04/
  │ 
  ├── code/
  │   │              
  │   ├── solve.py
  │   
  ├── images/
  │   │              
  │   ├── chair.png
  │   ├── chair_annotated.jpg
  │   ├── Image1.jpeg
  │   ├── Image2.jpeg
  │   
  ├── 04-task-header.inc  
  ├── answers.pdf
  ├── answers.tex
  ├── HW.sty
  ├── readme.tex
  ├── readme.txt
  ├── ReflectionEssay.pdf
  ├── task-body.tex


-> Honour Code

0. Student details
    learner id Y05
    
1. Olympus SIS ID
    id  X2ANS362

2. Which external person (human resource) or TA I consulted:
    1. None

3. What non-human resources I used on the Internet:
    a. https://docs.overleaf.com/troubleshooting-and-support/fixing-latex-errors
    b. https://docs.overleaf.com/
    c. geekForGeeks
    d. LLM- to convert output got from code into latex format
    
4. I pledge on my honour  that I have not given or received any unauthorized
   assistance on this assignment or any previous task.
    Signed by: Ankita Sahoo, X2ANS362

-> Using 1 free latedaytask
    