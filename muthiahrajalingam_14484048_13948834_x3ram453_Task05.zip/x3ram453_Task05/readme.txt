Task 05: Measure your transformation! -- README
==================================================

CONTENTS
--------
code/               - one script per report section (Sections 2-5)
images/             - breed sample figures (Section 2) and t-SNE plots (Section 4)
results/            - additional supporting details (shapes, metrics, confusion matrix)
answers.pdf / .tex  - written report
ReflectionEssay.pdf - reflection on the assignment

RUN ORDER
---------
All scripts were developed and run in Google Colab. To reproduce results from
scratch, run the following in order (each script is also runnable standalone,
but 04 and 05 depend on embeddings produced by 03):

1. python code/02_dataset_exploration.py
   - Downloads Oxford-IIIT Pet dataset via torchvision (~800MB, one-time).
   - Prints train/test/class counts.
   - Saves breed sample images to images/.

2. python code/03_dinov2_extraction.py
   - Loads facebook/dinov2-small via Hugging Face transformers (AutoImageProcessor,
     AutoModel).
   - Demonstrates tensor shapes on a small batch; writes results/task3_shapes.txt.
   - Extracts CLS embeddings for the full trainval (3680 images) and test
     (3669 images) splits.
   - Saves embeddings locally to code/embeddings/*.npy (NOT included in this
     submission -- regenerate by running this script).

3. python code/04_tsne_visualization.py
   - Loads saved test-split embeddings.
   - Computes a single t-SNE projection (random_state=422).
   - Saves images/tsne_cat_dog.png and images/tsne_6breeds.png.

4. python code/05_classification.py
   - Loads saved trainval/test embeddings.
   - Trains a logistic regression linear probe (max_iter=2000, random_state=42)
     on trainval; standardizes using a StandardScaler fit on trainval only.
   - Evaluates once on test; reports accuracy and macro F1.
   - Writes results/task5_metrics.txt and results/task5_confusion_matrix.png.

RANDOM SEEDS
------------
- Global seed (random, numpy, torch): 42, set at the top of every script.
- LogisticRegression: random_state=42 (as specified in the task sheet).
- TSNE: random_state=422 (as specified in the task sheet -- note this is
  intentionally different from the global seed).


NOT INCLUDED IN THIS SUBMISSION
--------------------------------
Per the task sheet, the following are excluded (all regenerable via the code above):
- The Oxford-IIIT Pet dataset itself (downloaded to ./data/ by code/02).
- Pretrained DINOv2 weights (downloaded/cached by Hugging Face transformers
  when code/03 is run).
- Extracted embedding .npy files (saved locally to code/embeddings/ when
  code/03 is run; regenerate by re-running that script).

RESULTS SUMMARY
----------------
Dataset: 3680 trainval images, 3669 test images, 37 classes.
DINOv2-small CLS embedding dimensionality: 384.
Linear probe (Logistic Regression) test accuracy: 0.9469
Linear probe (Logistic Regression) macro F1: 0.9461
(Full details and figures in answers.pdf; additional diagnostic detail such as
the confusion matrix is in results/.)

HONOR CODE / LLM DISCLOSURE
-----------------------------
We used an LLM (Claude) to help draft boilerplate code structure (dataset
loading, batched embedding extraction loop, t-SNE/matplotlib plotting
scaffolding, and sklearn classifier setup) and to review/tighten the wording
of our written analysis in answers.tex. All breed selections, visual-factor
reasoning, image inspection, and interpretation of results are our own.

TEAM / AUTHORS
----------------
1. Olympus SIS ID
    x3ram453
    
2. I pledge on my honour that I have not given or received any unauthorized assistance on this assignment or any previous task.
    Signed by: Rajalingam Muthiah, x3ram453