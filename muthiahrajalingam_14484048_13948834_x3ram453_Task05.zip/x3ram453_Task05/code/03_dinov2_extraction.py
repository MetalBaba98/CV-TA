import os
import random
import numpy as np
import torch
from tqdm.auto import tqdm
from transformers import AutoImageProcessor, AutoModel
from torchvision.datasets import OxfordIIITPet

# ---- Reproducibility ----
SEED = 42
random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)

# ---- Paths ----
RESULTS_DIR = os.path.join("..", "results")
EMBED_DIR = "embeddings"  # local only, not submitted
os.makedirs(RESULTS_DIR, exist_ok=True)
os.makedirs(EMBED_DIR, exist_ok=True)

device = "cuda" if torch.cuda.is_available() else "cpu"
print("Using device:", device)

# ---- Load dataset (needed here since this script is standalone) ----
trainval = OxfordIIITPet(root="./data", split="trainval",
                          target_types="category", download=True)
test = OxfordIIITPet(root="./data", split="test",
                      target_types="category", download=True)

# ---- Load frozen DINOv2-small ----
processor = AutoImageProcessor.from_pretrained("facebook/dinov2-small")
model = AutoModel.from_pretrained("facebook/dinov2-small").to(device)
model.eval()  # frozen: no training, no gradient updates to this model


def demo_batch_shapes(dataset, n=8):
    """Task 3.1.1 / 3.1.2: report shapes on a small demo batch."""
    batch_imgs = [dataset[i][0] for i in range(n)]
    inputs = processor(images=batch_imgs, return_tensors="pt").to(device)

    with torch.no_grad():
        outputs = model(**inputs)

    cls_embeddings = outputs.last_hidden_state[:, 0, :]

    lines = [
        f"Processed input shape: {tuple(inputs['pixel_values'].shape)}",
        f"Full hidden-state shape: {tuple(outputs.last_hidden_state.shape)}",
        f"CLS embedding shape: {tuple(cls_embeddings.shape)}",
        f"Embedding dimensionality: {cls_embeddings.shape[1]}",
        f"Images in batch: {len(batch_imgs)}",
        f"Embeddings extracted: {cls_embeddings.shape[0]}",
    ]
    for line in lines:
        print(line)

    assert cls_embeddings.shape[0] == len(batch_imgs), "Mismatch: not one embedding per image!"
    print("Confirmed: one embedding per image (demo batch).")

    with open(os.path.join(RESULTS_DIR, "task3_shapes.txt"), "w") as f:
        f.write("\n".join(lines) + "\n")
        f.write("Verified: one embedding per image (demo batch).\n")


@torch.no_grad()
def extract_cls_embeddings(dataset, batch_size=32):
    """Full-dataset batched CLS embedding extraction."""
    embeddings, labels = [], []
    n = len(dataset)
    for start in tqdm(range(0, n, batch_size), desc="Extracting embeddings"):
        end = min(start + batch_size, n)
        batch = [dataset[i] for i in range(start, end)]
        imgs = [img for img, _ in batch]
        lbls = [lbl for _, lbl in batch]

        inputs = processor(images=imgs, return_tensors="pt").to(device)
        outputs = model(**inputs)
        cls_embeds = outputs.last_hidden_state[:, 0, :]

        embeddings.append(cls_embeds.cpu().numpy())
        labels.extend(lbls)

    return np.concatenate(embeddings, axis=0), np.array(labels)


if __name__ == "__main__":
    # Task 3.1.1 and 3.1.2: shape demonstration on a small batch
    demo_batch_shapes(trainval, n=8)

    # Full extraction for downstream Sections 4 and 5
    train_embeds, train_labels = extract_cls_embeddings(trainval, batch_size=32)
    print("Train embeddings shape:", train_embeds.shape)

    test_embeds, test_labels = extract_cls_embeddings(test, batch_size=32)
    print("Test embeddings shape:", test_embeds.shape)

    assert train_embeds.shape[0] == len(trainval)
    assert test_embeds.shape[0] == len(test)
    assert train_embeds.shape[1] == 384
    print("All checks passed: one 384-dim embedding per image, for both splits.")

    np.save(os.path.join(EMBED_DIR, "train_embeds.npy"), train_embeds)
    np.save(os.path.join(EMBED_DIR, "train_labels.npy"), train_labels)
    np.save(os.path.join(EMBED_DIR, "test_embeds.npy"), test_embeds)
    np.save(os.path.join(EMBED_DIR, "test_labels.npy"), test_labels)
    print(f"Saved embeddings and labels to ./{EMBED_DIR}/ (not part of submission).")
