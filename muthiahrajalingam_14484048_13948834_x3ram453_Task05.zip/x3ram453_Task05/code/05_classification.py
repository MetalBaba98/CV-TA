"""
Task 05 - Section 5: Classification (Linear Probe)
Trains a multiclass logistic regression on frozen DINOv2-small CLS embeddings
(trainval split), evaluates once on the test split, and reports accuracy and
macro-F1 to four decimal places.

Run standalone: python 05_classification.py
Requires: embeddings/{train,test}_embeds.npy and embeddings/{train,test}_labels.npy
          (produced by 03_dinov2_extraction.py)
Outputs:
  - prints accuracy/F1 to console
  - writes results/task5_metrics.txt (required numbers, for the report table)
  - writes results/task5_confusion_matrix.png (extra detail beyond what's asked,
    per additional instructions: goes in results/)
"""

import os
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, f1_score, confusion_matrix
import matplotlib.pyplot as plt

EMBED_DIR = "embeddings"
RESULTS_DIR = os.path.join("..", "results")
os.makedirs(RESULTS_DIR, exist_ok=True)

SEED = 42

# ---- Load saved embeddings (from Section 3) ----
train_embeds = np.load(os.path.join(EMBED_DIR, "train_embeds.npy"))
train_labels = np.load(os.path.join(EMBED_DIR, "train_labels.npy"))
test_embeds = np.load(os.path.join(EMBED_DIR, "test_embeds.npy"))
test_labels = np.load(os.path.join(EMBED_DIR, "test_labels.npy"))

# ---- Standardize: fit on train ONLY, apply to test ----
scaler = StandardScaler()
X_train = scaler.fit_transform(train_embeds)
X_test = scaler.transform(test_embeds)

# ---- Train linear probe ----
clf = LogisticRegression(max_iter=2000, random_state=SEED)
clf.fit(X_train, train_labels)

# ---- Evaluate once on test ----
preds = clf.predict(X_test)
acc = accuracy_score(test_labels, preds)
f1 = f1_score(test_labels, preds, average="macro")

print(f"Test Accuracy: {acc:.4f}")
print(f"Macro F1:      {f1:.4f}")

with open(os.path.join(RESULTS_DIR, "task5_metrics.txt"), "w") as f:
    f.write("Logistic Regression (linear probe)\n")
    f.write(f"Test Accuracy: {acc:.4f}\n")
    f.write(f"Macro F1:      {f1:.4f}\n")
    f.write("StandardScaler fitted on trainval only, applied to test.\n")
    f.write("LogisticRegression(max_iter=2000, random_state=42), other params default.\n")

# ---- Extra detail (not required, goes in results/ per additional instructions) ----
cm = confusion_matrix(test_labels, preds)
plt.figure(figsize=(10, 9))
plt.imshow(cm, cmap="viridis")
plt.title("Confusion Matrix - Linear Probe on DINOv2-small CLS Embeddings")
plt.xlabel("Predicted label")
plt.ylabel("True label")
plt.colorbar()
plt.tight_layout()
plt.savefig(os.path.join(RESULTS_DIR, "task5_confusion_matrix.png"), dpi=150, bbox_inches="tight")
plt.close()
print("Saved extra detail: results/task5_confusion_matrix.png")

print("Section 5 classification complete.")
