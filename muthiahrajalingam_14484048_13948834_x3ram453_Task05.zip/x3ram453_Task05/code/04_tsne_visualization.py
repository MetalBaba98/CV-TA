"""
Task 05 - Section 4: Visualising the Embedding Space with t-SNE
Loads saved test-split embeddings, computes a single 2D t-SNE projection
(random_state=422), and produces two plots:
  1. Cat vs Dog super-category
  2. A focused 6-breed subset

Run standalone: python 04_tsne_visualization.py
Requires: embeddings/test_embeds.npy and embeddings/test_labels.npy
          (produced by 03_dinov2_extraction.py)
Outputs: saves both PNGs to ../images/
"""

import os
import numpy as np
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE
from sklearn.preprocessing import StandardScaler
from torchvision.datasets import OxfordIIITPet

IMAGES_DIR = os.path.join("..", "images")
EMBED_DIR = "embeddings"
os.makedirs(IMAGES_DIR, exist_ok=True)

# ---- Load saved embeddings (from Section 3) ----
test_embeds = np.load(os.path.join(EMBED_DIR, "test_embeds.npy"))
test_labels = np.load(os.path.join(EMBED_DIR, "test_labels.npy"))

# Need class name list; loading dataset metadata only (already cached on disk)
trainval = OxfordIIITPet(root="./data", split="trainval",
                          target_types="category", download=True)
classes = trainval.classes

# ---- t-SNE projection (computed once, reused for both plots) ----
scaler = StandardScaler()
test_embeds_scaled = scaler.fit_transform(test_embeds)

tsne = TSNE(n_components=2, random_state=422)
proj = tsne.fit_transform(test_embeds_scaled)
print("Projection shape:", proj.shape)

# ---- Plot 1: Cat vs Dog (Section 4.1) ----
CAT_BREEDS = {"Abyssinian", "Bengal", "Birman", "Bombay", "British Shorthair",
              "Egyptian Mau", "Maine Coon", "Persian", "Ragdoll",
              "Russian Blue", "Siamese", "Sphynx"}

is_cat = np.array([classes[l] in CAT_BREEDS for l in test_labels])

plt.figure(figsize=(8, 6))
plt.scatter(proj[is_cat, 0], proj[is_cat, 1], s=8, label="Cat", alpha=0.6)
plt.scatter(proj[~is_cat, 0], proj[~is_cat, 1], s=8, label="Dog", alpha=0.6)
plt.legend()
plt.title("t-SNE of DINOv2 CLS Embeddings: Cat vs Dog")
plt.savefig(os.path.join(IMAGES_DIR, "tsne_cat_dog.png"), dpi=150, bbox_inches="tight")
plt.close()
print("Saved: tsne_cat_dog.png")

# ---- Plot 2: 6-breed focused subset (Section 4.2) ----
CHOSEN_BREEDS = ["British Shorthair", "Russian Blue", "Persian",
                  "Chihuahua", "Great Pyrenees", "Maine Coon"]

plt.figure(figsize=(8, 6))
for breed in CHOSEN_BREEDS:
    breed_idx = classes.index(breed)
    m = test_labels == breed_idx
    plt.scatter(proj[m, 0], proj[m, 1], s=12, label=breed, alpha=0.7)
plt.legend()
plt.title("t-SNE of DINOv2 CLS Embeddings: 6-Breed Subset")
plt.savefig(os.path.join(IMAGES_DIR, "tsne_6breeds.png"), dpi=150, bbox_inches="tight")
plt.close()
print("Saved: tsne_6breeds.png")

print("Section 4 visualization complete.")
