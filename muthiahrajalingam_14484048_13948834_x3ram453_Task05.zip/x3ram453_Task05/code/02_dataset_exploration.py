import os
import random
import numpy as np
import torch
import matplotlib.pyplot as plt
from torchvision.datasets import OxfordIIITPet

# ---- Reproducibility ----
SEED = 42
random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)

# ---- Paths ----
IMAGES_DIR = os.path.join("..", "images")
os.makedirs(IMAGES_DIR, exist_ok=True)

# ---- Load dataset (Section 2 task) ----
trainval = OxfordIIITPet(root="./data", split="trainval",
                          target_types="category", download=True)
test = OxfordIIITPet(root="./data", split="test",
                      target_types="category", download=True)

print("Train images:", len(trainval))
print("Test images:", len(test))
print("Num classes:", len(trainval.classes))
print(trainval.classes)


def show_and_save_breed_samples(dataset, breed_name, n=4, save_name=None):
    """Saves a grid of n sample images for a given breed to IMAGES_DIR."""
    classes = dataset.classes
    breed_idx = classes.index(breed_name)
    imgs = [img for img, lbl in dataset if lbl == breed_idx][:n]
    fig, axes = plt.subplots(1, n, figsize=(4 * n, 4))
    for ax, img in zip(axes, imgs):
        ax.imshow(img)
        ax.set_title(breed_name)
        ax.axis("off")
    plt.tight_layout()
    if save_name is None:
        save_name = breed_name.replace(" ", "_") + "_samples.png"
    fig.savefig(os.path.join(IMAGES_DIR, save_name), dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"Saved: {save_name}")


if __name__ == "__main__":
    # Inter-class similarity pair (Section 2.1.2, Factor 1)
    show_and_save_breed_samples(trainval, "British Shorthair", n=4,
                                 save_name="factor1_British_Shorthair.png")
    show_and_save_breed_samples(trainval, "Russian Blue", n=4,
                                 save_name="factor1_Russian_Blue.png")

    # Intra-class dissimilarity example (Section 2.1.2, Factor 2)
    show_and_save_breed_samples(trainval, "Persian", n=4,
                                 save_name="candidate_Persian.png")

    # Extra breeds reserved for the Section 4.2 six-breed t-SNE subset
    show_and_save_breed_samples(trainval, "Chihuahua", n=4,
                                 save_name="factor2_Chihuahua.png")
    show_and_save_breed_samples(trainval, "Great Pyrenees", n=4,
                                 save_name="factor2_Great_Pyrenees.png")
    show_and_save_breed_samples(trainval, "Maine Coon", n=4,
                                 save_name="breed6_Maine_Coon.png")

    print("Section 2 exploration complete.")
