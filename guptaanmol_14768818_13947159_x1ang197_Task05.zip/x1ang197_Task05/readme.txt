TASK 05 — REPRODUCTION INSTRUCTIONS
===================================

This submission uses facebook/dinov2-small as a frozen feature extractor for
the Oxford-IIIT Pet dataset. The program downloads or reuses the official
trainval and test splits, extracts one final-layer [CLS] embedding per image,
creates the required diagnostic figures, fits one multiclass logistic-
regression linear probe, and writes the measured results to images/metrics.json.


QUICK START: TESTED coolalgo ENVIRONMENT
----------------------------------------

Run from the submission root (the directory containing this readme.txt).
Python 3.11.15, all pinned imports, the command-line interface, and the complete
measured experiment were checked in the existing coolalgo environment. The
portable reproduction command with the same measured settings is:

    conda run -n coolalgo python code/run_experiment.py --output-dir images --batch-size 32 --device cpu

On its first run it
requires an internet connection so torchvision can obtain Oxford-IIIT Pet and
Hugging Face can obtain the pinned DINOv2-small revision. Downloads and derived
embeddings go to external user caches by default, not into this submission:

    ~/.cache/task05_dinov2/data
    ~/.cache/task05_dinov2/embeddings
    the Hugging Face user cache (normally ~/.cache/huggingface)

The measured run invoked the coolalgo environment's Python interpreter directly
because this machine's Conda front end emitted an unrelated plug-in architecture
warning. This did not affect Python, the installed packages, or the experiment.
If a similar front-end warning occurs, activate coolalgo by the installation's
normal method and run the same command beginning with `python`.

The coolalgo environment already contained the required pinned packages when
this submission was prepared. If that named environment is missing a package,
install the submitted version manifest into it once, then repeat the run:

    conda run -n coolalgo python -m pip install -r code/requirements.txt


GENERIC pip FALLBACK
--------------------

Python 3.11 is recommended. The following creates an isolated environment,
installs the exact submitted versions, and runs the same experiment:

    python3.11 -m venv .venv
    source .venv/bin/activate
    python -m pip install --upgrade pip
    python -m pip install -r code/requirements.txt
    python code/run_experiment.py --output-dir images --batch-size 32 --device cpu

Do not add .venv to a submission archive. On Windows, activate with
`.venv\Scripts\activate` instead of the `source` command.


EXPECTED RUNTIME AND OUTPUTS
----------------------------

The first run is the slow run: it downloads the data and model and processes
7,349 images through DINOv2 (3,680 trainval and 3,669 test images) in batches.
Feature extraction took roughly ten minutes on the tested M1 CPU after the
inputs were available; download time depends on the network. The fixed
--device cpu option matches the submitted metrics exactly. Later runs with compatible external embedding caches skip
feature extraction and are much shorter, although t-SNE and classifier fitting
still take time.

The complete run creates or replaces these small reproducible artifacts:

    images/metrics.json
        Dataset counts, tensor shapes, cache/extraction provenance, selected
        examples, t-SNE settings, package versions, accuracy, and macro F1.

    images/tsne_cat_vs_dog.png
        Test-set t-SNE coloured by the breed-derived cat/dog super-category.

    images/tsne_six_breeds.png
        The same test projection restricted to the six selected breeds.

    images/sample_inter_class_similarity.png
        Deterministically selected similar-looking Bengal/Egyptian Mau pair
        from trainval.

    images/sample_intra_class_variation.png
        Deterministically selected visually varied Chihuahua pair from
        trainval.

The console also prints the data counts, device, representative tensor shapes,
cache status, final test accuracy, and macro-averaged F1. The authoritative
machine-readable values are in images/metrics.json; the report rounds both
classification metrics to four decimal places.


REPRODUCIBILITY DETAILS
-----------------------

* The global seed is 42 for Python, NumPy, PyTorch, DataLoader workers, t-SNE,
  and LogisticRegression. Deterministic PyTorch algorithms are requested with
  warnings rather than silent fallback.
* The checkpoint is facebook/dinov2-small at revision
  ed25f3a31f01632728cabb09d1542f84ab7b0056.
* The backbone is put in evaluation mode, has gradients disabled, and is used
  only to extract last_hidden_state[:, 0, :] (384 values per image).
* The official trainval split alone fits StandardScaler and LogisticRegression.
  The official test split is used for the required t-SNE views and one final
  quantitative evaluation.
* t-SNE uses unstandardized test embeddings, random_state=42, init="pca",
  learning_rate="auto", perplexity=30, and 1,000 iterations.
* LogisticRegression uses max_iter=2000 and random_state=42; all other
  classifier parameters retain scikit-learn defaults. StandardScaler is fitted
  on trainval only and then applied to test.
* The focused breeds are Bengal, Egyptian Mau, Sphynx, Chihuahua, Pomeranian,
  and Saint Bernard. Cat/dog labels are derived from breed names; the dataset's
  binary target is not requested or used.
* Embedding-cache compatibility checks cover the split, expected image count,
  batch size, seed, model ID, pinned revision, shape, values, and label range.
  Use --force-extract if a clean re-extraction is required.

For an offline verification after the first successful run, point to populated
external caches and add --no-download --local-files-only. Those flags are for
verification only; they are deliberately absent from the primary reproduction
command because a new evaluator must be allowed to download the inputs.

Useful diagnostics:

    conda run -n coolalgo python code/run_experiment.py --help
    conda run -n coolalgo python code/run_experiment.py --output-dir images --batch-size 32 --device cpu --force-extract


SUBMISSION CONTENTS
-------------------

The final archive is organized as follows (answers.* are the written report):

    x1ang197_Task05/
    |-- answers.pdf
    |-- answers.tex
    |-- ReflectionEssay.pdf
    |-- ReflectionEssay.tex
    |-- readme.txt
    |-- HW.sty
    |-- 05-task-header.inc
    |-- task-body.tex
    |-- images/
    |   |-- metrics.json
    |   |-- tsne_cat_vs_dog.png
    |   |-- tsne_six_breeds.png
    |   |-- sample_inter_class_similarity.png
    |   `-- sample_intra_class_variation.png
    `-- code/
        |-- run_experiment.py
        `-- requirements.txt

EXCLUDED LARGE OR RE-CREATABLE FILES
------------------------------------

The submission intentionally contains none of the following:

* Oxford-IIIT Pet images, annotations, archives, or dataset directories;
* pretrained DINOv2 model/configuration/processor files or Hugging Face caches;
* extracted embedding arrays, .npz caches, checkpoints, or learned model files;
* virtual environments, Python bytecode, package caches, or temporary files.

These exclusions are required by the assignment and do not prevent
reproduction: the script downloads the public inputs and rebuilds embeddings.
Only the compact figures and metrics.json are included.
