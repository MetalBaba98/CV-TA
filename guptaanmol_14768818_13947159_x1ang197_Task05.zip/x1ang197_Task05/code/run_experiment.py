#!/usr/bin/env python3
"""Reproduce the Task 05 Oxford-IIIT Pet / frozen DINOv2 experiment.

The script intentionally keeps the dataset, Hugging Face model files, and
derived embeddings out of the submission directory by default.  Only figures
and a compact JSON results file are written to ``--output-dir``.
"""

from __future__ import annotations

import argparse
import json
import os
import random
import sys
import tempfile
import warnings
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Sequence


SEED = 42
MODEL_ID = "facebook/dinov2-small"
MODEL_REVISION = "ed25f3a31f01632728cabb09d1542f84ab7b0056"

# Oxford-IIIT Pet category IDs are one-indexed in the original annotations and
# torchvision converts them to zero-indexed IDs in this exact order.
BREED_NAMES: tuple[str, ...] = (
    "Abyssinian",
    "american_bulldog",
    "american_pit_bull_terrier",
    "basset_hound",
    "beagle",
    "Bengal",
    "Birman",
    "Bombay",
    "boxer",
    "British_Shorthair",
    "chihuahua",
    "Egyptian_Mau",
    "english_cocker_spaniel",
    "english_setter",
    "german_shorthaired",
    "great_pyrenees",
    "havanese",
    "japanese_chin",
    "keeshond",
    "leonberger",
    "Maine_Coon",
    "miniature_pinscher",
    "newfoundland",
    "Persian",
    "pomeranian",
    "pug",
    "Ragdoll",
    "Russian_Blue",
    "saint_bernard",
    "samoyed",
    "scottish_terrier",
    "shiba_inu",
    "Siamese",
    "Sphynx",
    "staffordshire_bull_terrier",
    "wheaten_terrier",
    "yorkshire_terrier",
)

# This set is defined from the official breed names, not from the dataset's
# binary species target.  Every remaining breed in BREED_NAMES is a dog.
CAT_BREEDS = frozenset(
    {
        "Abyssinian",
        "Bengal",
        "Birman",
        "Bombay",
        "British_Shorthair",
        "Egyptian_Mau",
        "Maine_Coon",
        "Persian",
        "Ragdoll",
        "Russian_Blue",
        "Siamese",
        "Sphynx",
    }
)

DEFAULT_SIX_BREEDS = (
    "Bengal",
    "Egyptian_Mau",
    "Sphynx",
    "chihuahua",
    "pomeranian",
    "saint_bernard",
)


@dataclass(frozen=True)
class SplitFeatures:
    embeddings: Any
    labels: Any
    input_shape: tuple[int, ...]
    hidden_shape: tuple[int, ...]
    cls_shape: tuple[int, ...]
    source: str


def default_cache_root() -> Path:
    """Return a user cache location, deliberately outside the submission."""
    configured = os.environ.get("TASK05_CACHE_DIR")
    if configured:
        return Path(configured).expanduser()
    xdg_cache = os.environ.get("XDG_CACHE_HOME")
    base = Path(xdg_cache).expanduser() if xdg_cache else Path.home() / ".cache"
    return base / "task05_dinov2"


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Extract frozen facebook/dinov2-small CLS embeddings for the "
            "Oxford-IIIT Pet trainval/test splits, make diagnostic figures, "
            "and evaluate one logistic-regression linear probe."
        ),
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("outputs"),
        help="Directory for figures and metrics.json (no raw embeddings).",
    )
    parser.add_argument(
        "--data-dir",
        type=Path,
        default=default_cache_root() / "data",
        help="Oxford-IIIT Pet download/cache directory.",
    )
    parser.add_argument(
        "--embedding-cache-dir",
        type=Path,
        default=default_cache_root() / "embeddings",
        help="Re-creatable embedding cache; keep this out of the submission.",
    )
    parser.add_argument(
        "--hf-cache-dir",
        type=Path,
        default=None,
        help="Optional Hugging Face model cache (the HF default is used if omitted).",
    )
    parser.add_argument(
        "--batch-size", type=int, default=16, help="Feature-extraction batch size."
    )
    parser.add_argument(
        "--num-workers", type=int, default=0, help="DataLoader worker processes."
    )
    parser.add_argument(
        "--device",
        choices=("auto", "cpu", "cuda", "mps"),
        default="auto",
        help="Inference device; auto prefers CUDA, then Apple MPS, then CPU.",
    )
    parser.add_argument(
        "--six-breeds",
        nargs=6,
        metavar=("B1", "B2", "B3", "B4", "B5", "B6"),
        default=list(DEFAULT_SIX_BREEDS),
        help="Exactly six breed names for the focused t-SNE plot.",
    )
    parser.add_argument(
        "--inter-class-breeds",
        nargs=2,
        metavar=("BREED_A", "BREED_B"),
        default=["Bengal", "Egyptian_Mau"],
        help="Two visually similar breeds used for the cross-breed sample pair.",
    )
    parser.add_argument(
        "--intra-class-breed",
        default="chihuahua",
        help="Breed used for the visually varied within-breed sample pair.",
    )
    parser.add_argument(
        "--tsne-perplexity", type=float, default=30.0, help="t-SNE perplexity."
    )
    parser.add_argument(
        "--force-extract",
        action="store_true",
        help="Ignore compatible embedding caches and extract both splits again.",
    )
    parser.add_argument(
        "--local-files-only",
        action="store_true",
        help="Do not download Hugging Face files; require a populated local cache.",
    )
    parser.add_argument(
        "--download",
        action=argparse.BooleanOptionalAction,
        default=True,
        help=(
            "Allow torchvision to download Oxford-IIIT Pet if absent; use "
            "--no-download to require an existing local copy."
        ),
    )
    return parser


def normalise_breed_key(name: str) -> str:
    return "_".join(name.strip().replace("-", " ").replace("_", " ").lower().split())


def resolve_breed_name(name: str) -> str:
    lookup = {normalise_breed_key(breed): breed for breed in BREED_NAMES}
    key = normalise_breed_key(name)
    if key not in lookup:
        choices = ", ".join(BREED_NAMES)
        raise ValueError(f"Unknown breed {name!r}. Valid breed names are: {choices}")
    return lookup[key]


def validate_args(args: argparse.Namespace) -> None:
    if args.batch_size < 1:
        raise ValueError("--batch-size must be at least 1")
    if args.num_workers < 0:
        raise ValueError("--num-workers cannot be negative")
    if args.tsne_perplexity <= 0:
        raise ValueError("--tsne-perplexity must be positive")

    args.six_breeds = [resolve_breed_name(name) for name in args.six_breeds]
    if len(set(args.six_breeds)) != 6:
        raise ValueError("--six-breeds must contain six distinct breeds")
    args.inter_class_breeds = [
        resolve_breed_name(name) for name in args.inter_class_breeds
    ]
    if args.inter_class_breeds[0] == args.inter_class_breeds[1]:
        raise ValueError("--inter-class-breeds must name two different breeds")
    args.intra_class_breed = resolve_breed_name(args.intra_class_breed)

    required = set(args.inter_class_breeds) | {args.intra_class_breed}
    missing = sorted(required.difference(args.six_breeds))
    if missing:
        raise ValueError(
            "The breeds used for the sample pairs must also occur in --six-breeds. "
            f"Missing: {', '.join(missing)}"
        )


def seed_everything(torch: Any, np: Any) -> None:
    os.environ["PYTHONHASHSEED"] = str(SEED)
    random.seed(SEED)
    np.random.seed(SEED)
    torch.manual_seed(SEED)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(SEED)
    if hasattr(torch, "use_deterministic_algorithms"):
        torch.use_deterministic_algorithms(True, warn_only=True)
    if hasattr(torch.backends, "cudnn"):
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False


def seed_worker(worker_id: int) -> None:
    # torch.initial_seed is deterministically derived from the DataLoader generator.
    import numpy as np
    import torch

    worker_seed = torch.initial_seed() % (2**32)
    np.random.seed(worker_seed)
    random.seed(worker_seed)


def collate_pil_batch(batch: Sequence[tuple[Any, Any]]) -> tuple[list[Any], list[int]]:
    images: list[Any] = []
    labels: list[int] = []
    for image, target in batch:
        if isinstance(target, (tuple, list)):
            target = target[0]
        images.append(image.convert("RGB"))
        labels.append(int(target))
    return images, labels


def choose_device(requested: str, torch: Any) -> Any:
    if requested == "auto":
        if torch.cuda.is_available():
            return torch.device("cuda")
        mps = getattr(torch.backends, "mps", None)
        if mps is not None and mps.is_available():
            return torch.device("mps")
        return torch.device("cpu")
    if requested == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested, but torch.cuda.is_available() is false")
    if requested == "mps":
        mps = getattr(torch.backends, "mps", None)
        if mps is None or not mps.is_available():
            raise RuntimeError("MPS was requested, but this PyTorch build/device lacks MPS")
    return torch.device(requested)


def cache_path(cache_dir: Path, split: str, batch_size: int) -> Path:
    model_key = MODEL_ID.replace("/", "--")
    return cache_dir / (
        f"oxfordiiitpet_{split}_{model_key}_rev{MODEL_REVISION[:8]}_"
        f"cls_bs{batch_size}_seed{SEED}.npz"
    )


def save_feature_cache(
    path: Path, features: SplitFeatures, batch_size: int, np: Any
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    handle = tempfile.NamedTemporaryFile(
        mode="wb", prefix=f".{path.stem}.", suffix=".npz", dir=path.parent, delete=False
    )
    temporary_path = Path(handle.name)
    try:
        with handle:
            np.savez_compressed(
                handle,
                embeddings=features.embeddings,
                labels=features.labels,
                input_shape=np.asarray(features.input_shape, dtype=np.int64),
                hidden_shape=np.asarray(features.hidden_shape, dtype=np.int64),
                cls_shape=np.asarray(features.cls_shape, dtype=np.int64),
                model_id=np.asarray(MODEL_ID),
                model_revision=np.asarray(MODEL_REVISION),
                batch_size=np.asarray(batch_size, dtype=np.int64),
                seed=np.asarray(SEED, dtype=np.int64),
            )
        temporary_path.replace(path)
    finally:
        if temporary_path.exists():
            temporary_path.unlink()


def load_feature_cache(
    path: Path, expected_count: int, expected_batch_size: int, np: Any
) -> SplitFeatures | None:
    if not path.is_file():
        return None
    try:
        with np.load(path, allow_pickle=False) as cached:
            if str(cached["model_id"].item()) != MODEL_ID:
                return None
            if str(cached["model_revision"].item()) != MODEL_REVISION:
                return None
            if int(cached["batch_size"].item()) != expected_batch_size:
                return None
            if int(cached["seed"].item()) != SEED:
                return None
            embeddings = cached["embeddings"].astype(np.float32, copy=False)
            labels = cached["labels"].astype(np.int64, copy=False)
            if embeddings.ndim != 2 or embeddings.shape[0] != expected_count:
                return None
            if labels.shape != (expected_count,):
                return None
            if embeddings.shape[1] != 384:
                return None
            if not np.isfinite(embeddings).all():
                return None
            if labels.min() < 0 or labels.max() >= len(BREED_NAMES):
                return None
            return SplitFeatures(
                embeddings=embeddings,
                labels=labels,
                input_shape=tuple(int(v) for v in cached["input_shape"]),
                hidden_shape=tuple(int(v) for v in cached["hidden_shape"]),
                cls_shape=tuple(int(v) for v in cached["cls_shape"]),
                source="cache",
            )
    except (KeyError, OSError, ValueError, EOFError) as exc:
        print(f"Ignoring unreadable/incompatible cache {path}: {exc}", file=sys.stderr)
        return None


def extract_features(
    *,
    dataset: Any,
    split: str,
    processor: Any,
    model: Any,
    device: Any,
    batch_size: int,
    num_workers: int,
    torch: Any,
    np: Any,
) -> SplitFeatures:
    generator = torch.Generator()
    generator.manual_seed(SEED)
    loader = torch.utils.data.DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        collate_fn=collate_pil_batch,
        worker_init_fn=seed_worker if num_workers else None,
        generator=generator,
        pin_memory=device.type == "cuda",
        persistent_workers=num_workers > 0,
    )

    all_embeddings: list[Any] = []
    all_labels: list[Any] = []
    input_shape: tuple[int, ...] | None = None
    hidden_shape: tuple[int, ...] | None = None
    cls_shape: tuple[int, ...] | None = None

    total_batches = len(loader)
    print(f"Extracting {split}: {len(dataset)} images in {total_batches} batches on {device}")
    model.eval()
    with torch.inference_mode():
        for batch_number, (images, labels) in enumerate(loader, start=1):
            processed = processor(images=images, return_tensors="pt")
            if "pixel_values" not in processed:
                raise RuntimeError("AutoImageProcessor did not return pixel_values")
            processed = {
                key: value.to(device, non_blocking=device.type == "cuda")
                for key, value in processed.items()
            }
            output = model(**processed)
            hidden = output.last_hidden_state
            cls_embeddings = hidden[:, 0, :]

            if input_shape is None:
                input_shape = tuple(int(v) for v in processed["pixel_values"].shape)
                hidden_shape = tuple(int(v) for v in hidden.shape)
                cls_shape = tuple(int(v) for v in cls_embeddings.shape)
                print(
                    f"{split} example shapes: input={input_shape}, "
                    f"hidden={hidden_shape}, CLS={cls_shape}"
                )

            all_embeddings.append(cls_embeddings.float().cpu().numpy())
            all_labels.append(np.asarray(labels, dtype=np.int64))
            if batch_number == total_batches or batch_number % 10 == 0:
                print(f"  {split}: batch {batch_number}/{total_batches}")

    if input_shape is None or hidden_shape is None or cls_shape is None:
        raise RuntimeError(f"No batches were produced for the {split} split")
    embeddings = np.concatenate(all_embeddings, axis=0).astype(np.float32, copy=False)
    labels = np.concatenate(all_labels, axis=0).astype(np.int64, copy=False)
    if embeddings.shape[0] != len(dataset) or labels.shape[0] != len(dataset):
        raise RuntimeError(
            f"{split}: expected one embedding per image ({len(dataset)}), got "
            f"{embeddings.shape[0]} embeddings and {labels.shape[0]} labels"
        )
    if embeddings.ndim != 2 or embeddings.shape[1] != 384:
        raise RuntimeError(
            f"Expected DINOv2-small CLS embeddings with shape (N, 384), got {embeddings.shape}"
        )
    return SplitFeatures(
        embeddings=embeddings,
        labels=labels,
        input_shape=input_shape,
        hidden_shape=hidden_shape,
        cls_shape=cls_shape,
        source="extracted",
    )


def get_or_extract_split(
    *,
    dataset: Any,
    split: str,
    cache_dir: Path,
    force_extract: bool,
    processor: Any,
    model: Any,
    device: Any,
    batch_size: int,
    num_workers: int,
    torch: Any,
    np: Any,
) -> SplitFeatures:
    path = cache_path(cache_dir, split, batch_size)
    if not force_extract:
        cached = load_feature_cache(path, len(dataset), batch_size, np)
        if cached is not None:
            print(f"Loaded {split} embeddings from external cache: {path}")
            return cached
    if processor is None or model is None:
        raise RuntimeError(f"{split} embeddings need extraction, but the model is not loaded")
    features = extract_features(
        dataset=dataset,
        split=split,
        processor=processor,
        model=model,
        device=device,
        batch_size=batch_size,
        num_workers=num_workers,
        torch=torch,
        np=np,
    )
    save_feature_cache(path, features, batch_size, np)
    print(f"Saved re-creatable {split} embeddings outside submission: {path}")
    return features


def label_to_breed(label: int) -> str:
    return BREED_NAMES[int(label)]


def species_for_breed(breed: str) -> str:
    return "cat" if breed in CAT_BREEDS else "dog"


def validate_dataset_class_order(dataset: Any, split: str) -> None:
    """Guard the documented category-ID mapping against library/data changes."""
    classes = getattr(dataset, "classes", None)
    if classes is None:
        return
    observed = [normalise_breed_key(str(name)) for name in classes]
    expected = [normalise_breed_key(name) for name in BREED_NAMES]
    if observed != expected:
        raise RuntimeError(
            f"{split}: torchvision category order differs from the expected "
            "Oxford-IIIT Pet annotation order; refusing to attach wrong breed names"
        )


def dataset_image_filename(dataset: Any, index: int) -> str:
    """Return the source filename when exposed by torchvision."""
    images = getattr(dataset, "_images", None)
    if images is None:
        return f"dataset_index_{index}"
    return Path(images[index]).name


def find_most_similar_cross_breed_pair(
    embeddings: Any,
    labels: Any,
    breed_a: str,
    breed_b: str,
    np: Any,
) -> tuple[int, int, float]:
    label_a = BREED_NAMES.index(breed_a)
    label_b = BREED_NAMES.index(breed_b)
    idx_a = np.flatnonzero(labels == label_a)
    idx_b = np.flatnonzero(labels == label_b)
    if not len(idx_a) or not len(idx_b):
        raise RuntimeError(f"No test images found for {breed_a} and/or {breed_b}")
    emb_a = embeddings[idx_a]
    emb_b = embeddings[idx_b]
    emb_a = emb_a / np.maximum(np.linalg.norm(emb_a, axis=1, keepdims=True), 1e-12)
    emb_b = emb_b / np.maximum(np.linalg.norm(emb_b, axis=1, keepdims=True), 1e-12)
    similarities = emb_a @ emb_b.T
    row, column = np.unravel_index(int(np.argmax(similarities)), similarities.shape)
    return int(idx_a[row]), int(idx_b[column]), float(similarities[row, column])


def find_most_varied_within_breed_pair(
    embeddings: Any, labels: Any, breed: str, np: Any
) -> tuple[int, int, float]:
    label = BREED_NAMES.index(breed)
    indices = np.flatnonzero(labels == label)
    if len(indices) < 2:
        raise RuntimeError(f"Need at least two test images for intra-class breed {breed}")
    selected = embeddings[indices]
    selected = selected / np.maximum(
        np.linalg.norm(selected, axis=1, keepdims=True), 1e-12
    )
    similarities = selected @ selected.T
    similarities[np.tril_indices_from(similarities)] = np.inf
    row, column = np.unravel_index(int(np.argmin(similarities)), similarities.shape)
    return int(indices[row]), int(indices[column]), float(similarities[row, column])


def save_pair_figure(
    *,
    dataset: Any,
    indices: tuple[int, int],
    titles: tuple[str, str],
    heading: str,
    note: str,
    output_path: Path,
    plt: Any,
) -> None:
    figure, axes = plt.subplots(1, 2, figsize=(9, 4.8))
    for axis, index, title in zip(axes, indices, titles):
        image, _ = dataset[index]
        axis.imshow(image.convert("RGB"))
        axis.set_title(title.replace("_", " "))
        axis.axis("off")
    figure.suptitle(heading, fontsize=13)
    figure.text(0.5, 0.015, note, ha="center", fontsize=9)
    figure.tight_layout(rect=(0, 0.04, 1, 0.93))
    figure.savefig(output_path, dpi=180, bbox_inches="tight")
    plt.close(figure)


def save_tsne_figures(
    *,
    coordinates: Any,
    labels: Any,
    six_breeds: Sequence[str],
    output_dir: Path,
    np: Any,
    plt: Any,
) -> dict[str, str]:
    species = np.asarray(
        [species_for_breed(label_to_breed(label)) for label in labels], dtype=str
    )
    figure, axis = plt.subplots(figsize=(8.5, 7))
    for name, colour in (("cat", "#d95f02"), ("dog", "#1b9e77")):
        mask = species == name
        axis.scatter(
            coordinates[mask, 0],
            coordinates[mask, 1],
            s=10,
            alpha=0.65,
            c=colour,
            label=f"{name.title()} (n={int(mask.sum())})",
            linewidths=0,
        )
    axis.set_title("DINOv2-small test embeddings: cat vs. dog")
    axis.set_xlabel("t-SNE dimension 1")
    axis.set_ylabel("t-SNE dimension 2")
    axis.legend(frameon=True)
    axis.grid(alpha=0.15)
    figure.tight_layout()
    cat_dog_path = output_dir / "tsne_cat_vs_dog.png"
    figure.savefig(cat_dog_path, dpi=200, bbox_inches="tight")
    plt.close(figure)

    figure, axis = plt.subplots(figsize=(9.5, 7.5))
    colours = plt.get_cmap("tab10")
    for colour_index, breed in enumerate(six_breeds):
        label = BREED_NAMES.index(breed)
        mask = labels == label
        if not np.any(mask):
            raise RuntimeError(f"No test points found for focused breed {breed}")
        axis.scatter(
            coordinates[mask, 0],
            coordinates[mask, 1],
            s=18,
            alpha=0.72,
            color=colours(colour_index),
            label=f"{breed.replace('_', ' ')} (n={int(mask.sum())})",
            linewidths=0,
        )
    axis.set_title("DINOv2-small test embeddings: focused six-breed subset")
    axis.set_xlabel("t-SNE dimension 1")
    axis.set_ylabel("t-SNE dimension 2")
    axis.legend(loc="best", frameon=True, fontsize=9)
    axis.grid(alpha=0.15)
    figure.tight_layout()
    six_path = output_dir / "tsne_six_breeds.png"
    figure.savefig(six_path, dpi=200, bbox_inches="tight")
    plt.close(figure)
    return {"cat_dog": cat_dog_path.name, "six_breeds": six_path.name}


def package_versions(packages: Sequence[str]) -> dict[str, str]:
    from importlib.metadata import PackageNotFoundError, version

    versions: dict[str, str] = {}
    for package in packages:
        try:
            versions[package] = version(package)
        except PackageNotFoundError:
            versions[package] = "unknown"
    return versions


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        validate_args(args)
    except ValueError as exc:
        parser.error(str(exc))

    # Heavy imports happen after parsing so ``--help`` works before dependencies
    # are installed and does not initialize CUDA/MPS.
    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        import numpy as np
        import torch
        from sklearn.linear_model import LogisticRegression
        from sklearn.manifold import TSNE
        from sklearn.metrics import accuracy_score, f1_score
        from sklearn.preprocessing import StandardScaler
        from torchvision.datasets import OxfordIIITPet
        from transformers import AutoImageProcessor, AutoModel
    except ImportError as exc:
        parser.error(
            f"Missing dependency ({exc}). Install code/requirements.txt before running."
        )

    seed_everything(torch, np)
    device = choose_device(args.device, torch)
    output_dir = args.output_dir.expanduser().resolve()
    data_dir = args.data_dir.expanduser().resolve()
    cache_dir = args.embedding_cache_dir.expanduser().resolve()
    hf_cache_dir = (
        args.hf_cache_dir.expanduser().resolve() if args.hf_cache_dir is not None else None
    )
    output_dir.mkdir(parents=True, exist_ok=True)
    cache_dir.mkdir(parents=True, exist_ok=True)

    print(f"Seed: {SEED}")
    print(f"Device: {device}")
    print(f"Output directory: {output_dir}")
    print(f"Dataset directory: {data_dir}")
    print(f"External embedding cache: {cache_dir}")

    train_dataset = OxfordIIITPet(
        root=data_dir, split="trainval", target_types="category", download=args.download
    )
    test_dataset = OxfordIIITPet(
        root=data_dir, split="test", target_types="category", download=args.download
    )
    if len(BREED_NAMES) != 37:
        raise RuntimeError("Internal Oxford-IIIT Pet breed-name mapping is not length 37")
    validate_dataset_class_order(train_dataset, "trainval")
    validate_dataset_class_order(test_dataset, "test")
    print(
        f"Dataset: trainval={len(train_dataset)}, test={len(test_dataset)}, "
        f"classes={len(BREED_NAMES)}"
    )

    paths = {
        split: cache_path(cache_dir, split, args.batch_size)
        for split in ("trainval", "test")
    }
    cached_train = (
        None
        if args.force_extract
        else load_feature_cache(
            paths["trainval"], len(train_dataset), args.batch_size, np
        )
    )
    cached_test = (
        None
        if args.force_extract
        else load_feature_cache(paths["test"], len(test_dataset), args.batch_size, np)
    )
    processor = None
    model = None
    if cached_train is None or cached_test is None:
        print(f"Loading frozen feature extractor: {MODEL_ID}")
        processor_kwargs: dict[str, Any] = {
            "cache_dir": str(hf_cache_dir) if hf_cache_dir is not None else None,
            "local_files_only": args.local_files_only,
            "revision": MODEL_REVISION,
            "use_fast": False,
        }
        model_kwargs: dict[str, Any] = {
            "cache_dir": str(hf_cache_dir) if hf_cache_dir is not None else None,
            "local_files_only": args.local_files_only,
            "revision": MODEL_REVISION,
        }
        # Omitting rather than passing cache_dir=None avoids version-specific warnings.
        processor_kwargs = {k: v for k, v in processor_kwargs.items() if v is not None}
        model_kwargs = {k: v for k, v in model_kwargs.items() if v is not None}
        processor = AutoImageProcessor.from_pretrained(MODEL_ID, **processor_kwargs)
        model = AutoModel.from_pretrained(MODEL_ID, **model_kwargs)
        model.requires_grad_(False)
        model.eval()
        model.to(device)

    if cached_train is None:
        train_features = get_or_extract_split(
            dataset=train_dataset,
            split="trainval",
            cache_dir=cache_dir,
            force_extract=True,
            processor=processor,
            model=model,
            device=device,
            batch_size=args.batch_size,
            num_workers=args.num_workers,
            torch=torch,
            np=np,
        )
    else:
        print(f"Loaded trainval embeddings from external cache: {paths['trainval']}")
        train_features = cached_train
    if cached_test is None:
        test_features = get_or_extract_split(
            dataset=test_dataset,
            split="test",
            cache_dir=cache_dir,
            force_extract=True,
            processor=processor,
            model=model,
            device=device,
            batch_size=args.batch_size,
            num_workers=args.num_workers,
            torch=torch,
            np=np,
        )
    else:
        print(f"Loaded test embeddings from external cache: {paths['test']}")
        test_features = cached_test

    # Release accelerator memory before the CPU-only analysis and classifier fit.
    if model is not None:
        model.to("cpu")
        del model
        if device.type == "cuda":
            torch.cuda.empty_cache()
        elif device.type == "mps" and hasattr(torch.mps, "empty_cache"):
            torch.mps.empty_cache()

    for split, features, expected in (
        ("trainval", train_features, len(train_dataset)),
        ("test", test_features, len(test_dataset)),
    ):
        if features.embeddings.shape[0] != expected:
            raise RuntimeError(f"{split}: one-embedding-per-image verification failed")
        if set(np.unique(features.labels).tolist()) != set(range(len(BREED_NAMES))):
            raise RuntimeError(f"{split}: expected all 37 category labels")

    if args.tsne_perplexity >= len(test_dataset):
        raise ValueError("--tsne-perplexity must be smaller than the test-set size")
    print("Running t-SNE on unstandardized test CLS embeddings (random_state=42)")
    tsne = TSNE(
        n_components=2,
        perplexity=args.tsne_perplexity,
        random_state=SEED,
        init="pca",
        learning_rate="auto",
        max_iter=1000,
    )
    coordinates = tsne.fit_transform(test_features.embeddings)
    figure_files = save_tsne_figures(
        coordinates=coordinates,
        labels=test_features.labels,
        six_breeds=args.six_breeds,
        output_dir=output_dir,
        np=np,
        plt=plt,
    )

    # The qualitative choices are made on trainval so that test is reserved for
    # the required visualization and one final quantitative evaluation.
    inter_a, inter_b, inter_similarity = find_most_similar_cross_breed_pair(
        train_features.embeddings,
        train_features.labels,
        args.inter_class_breeds[0],
        args.inter_class_breeds[1],
        np,
    )
    inter_files = (
        dataset_image_filename(train_dataset, inter_a),
        dataset_image_filename(train_dataset, inter_b),
    )
    inter_path = output_dir / "sample_inter_class_similarity.png"
    save_pair_figure(
        dataset=train_dataset,
        indices=(inter_a, inter_b),
        titles=(
            f"{args.inter_class_breeds[0]}\n{inter_files[0]}",
            f"{args.inter_class_breeds[1]}\n{inter_files[1]}",
        ),
        heading="Inter-class similarity: two different breeds can look alike",
        note=f"Deterministic most-similar cross-breed trainval pair; cosine similarity={inter_similarity:.3f}",
        output_path=inter_path,
        plt=plt,
    )
    intra_a, intra_b, intra_similarity = find_most_varied_within_breed_pair(
        train_features.embeddings,
        train_features.labels,
        args.intra_class_breed,
        np,
    )
    intra_files = (
        dataset_image_filename(train_dataset, intra_a),
        dataset_image_filename(train_dataset, intra_b),
    )
    intra_path = output_dir / "sample_intra_class_variation.png"
    save_pair_figure(
        dataset=train_dataset,
        indices=(intra_a, intra_b),
        titles=(
            f"{args.intra_class_breed}\n{intra_files[0]}",
            f"{args.intra_class_breed}\n{intra_files[1]}",
        ),
        heading="Intra-class variation: one breed can vary in appearance",
        note=f"Deterministic least-similar within-breed trainval pair; cosine similarity={intra_similarity:.3f}",
        output_path=intra_path,
        plt=plt,
    )
    figure_files.update(
        {
            "inter_class_similarity": inter_path.name,
            "intra_class_variation": intra_path.name,
        }
    )

    print("Fitting StandardScaler on trainval embeddings only")
    scaler = StandardScaler()
    x_train = scaler.fit_transform(train_features.embeddings)
    x_test = scaler.transform(test_features.embeddings)
    print("Training LogisticRegression(max_iter=2000, random_state=42)")
    classifier = LogisticRegression(max_iter=2000, random_state=SEED)
    from sklearn.exceptions import ConvergenceWarning

    with warnings.catch_warnings(record=True) as caught_warnings:
        warnings.simplefilter("always", ConvergenceWarning)
        classifier.fit(x_train, train_features.labels)
    convergence_warnings = [
        str(item.message)
        for item in caught_warnings
        if issubclass(item.category, ConvergenceWarning)
    ]
    if convergence_warnings:
        print(
            "WARNING: LogisticRegression emitted a convergence warning; see metrics.json",
            file=sys.stderr,
        )
    predictions = classifier.predict(x_test)
    accuracy = float(accuracy_score(test_features.labels, predictions))
    macro_f1 = float(
        f1_score(test_features.labels, predictions, average="macro", zero_division=0)
    )

    metrics = {
        "seed": SEED,
        "model_id": MODEL_ID,
        "model_revision": MODEL_REVISION,
        "device": str(device),
        "dataset": {
            "name": "OxfordIIITPet",
            "target_types": "category",
            "train_split": "trainval",
            "test_split": "test",
            "train_images": len(train_dataset),
            "test_images": len(test_dataset),
            "classes": len(BREED_NAMES),
            "breed_names": list(BREED_NAMES),
        },
        "feature_extraction": {
            "backbone_frozen": True,
            "representation": "last_hidden_state[:, 0, :]",
            "embedding_dimension": int(train_features.embeddings.shape[1]),
            "train_embeddings": int(train_features.embeddings.shape[0]),
            "test_embeddings": int(test_features.embeddings.shape[0]),
            "one_embedding_per_image_verified": True,
            "batch_size": args.batch_size,
            "trainval_example_shapes": {
                "processed_input": list(train_features.input_shape),
                "last_hidden_state": list(train_features.hidden_shape),
                "cls_embedding": list(train_features.cls_shape),
            },
            "test_example_shapes": {
                "processed_input": list(test_features.input_shape),
                "last_hidden_state": list(test_features.hidden_shape),
                "cls_embedding": list(test_features.cls_shape),
            },
            "train_source": train_features.source,
            "test_source": test_features.source,
        },
        "visualization": {
            "split": "test",
            "method": "TSNE",
            "random_state": SEED,
            "standardized_before_tsne": False,
            "perplexity": args.tsne_perplexity,
            "max_iter": 1000,
            "six_breeds": list(args.six_breeds),
            "six_breed_rationale": (
                "Bengal and Egyptian Mau are a deliberately similar-looking cat "
                "pair; Chihuahua supplies the within-breed variation pair; Sphynx, "
                "Pomeranian, and Saint Bernard add visually contrasting anchors "
                "while keeping the subset balanced at three cats and three dogs."
                if tuple(args.six_breeds) == DEFAULT_SIX_BREEDS
                else "User-configured focused subset; explain the selection in the report."
            ),
            "cat_dog_mapping": (
                "derived from breed-name membership; binary target not requested or used"
            ),
            "inter_class_pair": {
                "split": "trainval",
                "breeds": list(args.inter_class_breeds),
                "dataset_indices": [inter_a, inter_b],
                "image_files": list(inter_files),
                "cosine_similarity": inter_similarity,
                "selection": "maximum cosine similarity across the two breed categories",
            },
            "intra_class_pair": {
                "split": "trainval",
                "breed": args.intra_class_breed,
                "dataset_indices": [intra_a, intra_b],
                "image_files": list(intra_files),
                "cosine_similarity": intra_similarity,
                "selection": "minimum cosine similarity among images of this breed",
            },
        },
        "linear_probe": {
            "classifier": "LogisticRegression",
            "max_iter": 2000,
            "random_state": SEED,
            "all_other_classifier_parameters": "scikit-learn defaults",
            "scaling": "StandardScaler fitted on trainval only, then applied to test",
            "iterations_by_class_or_binary_problem": [
                int(value) for value in classifier.n_iter_
            ],
            "converged_without_warning": not convergence_warnings,
            "convergence_warnings": convergence_warnings,
            "test_accuracy": round(accuracy, 4),
            "test_accuracy_4dp": f"{accuracy:.4f}",
            "macro_f1": round(macro_f1, 4),
            "macro_f1_4dp": f"{macro_f1:.4f}",
        },
        "figures": figure_files,
        "software_versions": {
            "python": sys.version.split()[0],
            **package_versions(
                (
                    "torch",
                    "torchvision",
                    "transformers",
                    "numpy",
                    "scikit-learn",
                    "matplotlib",
                    "Pillow",
                )
            ),
        },
    }
    metrics_path = output_dir / "metrics.json"
    temporary_metrics = output_dir / ".metrics.json.tmp"
    with temporary_metrics.open("w", encoding="utf-8") as handle:
        json.dump(metrics, handle, indent=2, sort_keys=True)
        handle.write("\n")
    temporary_metrics.replace(metrics_path)

    print(f"Test accuracy: {accuracy:.4f}")
    print(f"Macro F1:     {macro_f1:.4f}")
    print(f"Wrote metrics: {metrics_path}")
    for description, filename in figure_files.items():
        print(f"Wrote {description}: {output_dir / filename}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
