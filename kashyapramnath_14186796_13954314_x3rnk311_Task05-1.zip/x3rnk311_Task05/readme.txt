README.txt

============================================================
OXFORD-IIIT PET BREED CLASSIFICATION USING DINOv2
=================================================

1. PROJECT OVERVIEW

---

This project performs fine-grained pet breed classification using the
Oxford-IIIT Pet Dataset.

A pretrained DINOv2-small model is used as a frozen feature extractor.
For each image, the final-layer [CLS] representation is extracted as a
384-dimensional embedding.

The extracted embeddings are used for:

```
• t-SNE visualization
• Inter-class similarity analysis
• Intra-class dissimilarity analysis
• Breed classification using Logistic Regression
```

The DINOv2 backbone is kept frozen throughout the experiment and is not
fine-tuned.

2. DATASET

---

Dataset:
Oxford-IIIT Pet Dataset

Number of classes:
37

Trainval images:
3680

Official test images:
3669

Dataset usage:

```
Trainval split
    Used only for training the Logistic Regression linear probe.

Official test split
    Used only once for final evaluation.
```

## 3. SOFTWARE REQUIREMENTS

The implementation uses Python with the following packages:

```
PyTorch
    Used for tensor operations, DINOv2 inference, and saving/loading
    embeddings.

Torchvision
    Used to load the Oxford-IIIT Pet Dataset.

Transformers
    Used to load the pretrained DINOv2-small model and image processor.

NumPy
    Used for numerical operations and label processing.

Scikit-learn
    Used for:
        • Logistic Regression
        • Cosine similarity
        • t-SNE
        • Accuracy
        • Macro-averaged F1 score

Matplotlib
    Used to generate and save visualizations.
```

## 4. IMPLEMENTATION GUIDELINES

STEP 1 — DATASET PREPARATION

```
• Load the Oxford-IIIT Pet Dataset.
• Use the trainval split for training.
• Use the official test split only for final evaluation.
• Verify that the dataset contains 37 classes.
• Verify the expected number of images:
      Trainval = 3680
      Test     = 3669
```

STEP 2 — DINOv2 FEATURE EXTRACTION

```
• Use the pretrained DINOv2-small model:
      facebook/dinov2-small

• Set the model to evaluation mode.
• Freeze all DINOv2 parameters.
• Do not fine-tune the backbone.
• Process images using the DINOv2 image processor.
• Extract only the final-layer [CLS] representation.

DINOv2-small representation:

      Image size       = 224 × 224
      Input channels   = 3
      [CLS] dimension  = 384

Therefore, every image must produce exactly one
384-dimensional embedding.
```

STEP 3 — EMBEDDING VERIFICATION

```
Verify the extracted embedding shapes:

      Train embeddings = 3680 × 384
      Test embeddings  = 3669 × 384

The number of embeddings must exactly match the number of images.

This confirms that:

      One image → One 384-dimensional embedding
```

STEP 4 — SAVE EMBEDDINGS : Can be reproduced by code
```
Save the extracted embeddings and labels as:

      train_embeddings.pt
      test_embeddings.pt

These saved embeddings are used for all subsequent analysis.
DINOv2 should not be called again during classifier training.
```

STEP 5 — t-SNE VISUALIZATION

```
Generate two t-SNE visualizations using the saved test embeddings ( Can be reproduced by code )
PLOT 1 — CAT VS. DOG

    • Group the 37 breed labels into Cat and Dog.
    • Use these labels only for visualization.
    • Do not use them for DINOv2 feature extraction.

    Output:
        dino_v2_tsne_cat_vs_dog.png


PLOT 2 — SIX-BREED SUBSET

    The following breeds are selected:

        1. Siamese
        2. Birman
        3. Persian
        4. Sphynx
        5. German Shepherd
        6. Pug

    Siamese and Birman are included to examine
    inter-class similarity.

    Output:
        tsne_sex_breeds.png
```

STEP 6 — INTER-CLASS SIMILARITY

```
• Compare Siamese and Birman embeddings using cosine similarity.
• Identify highly similar image pairs.
• Visually inspect the selected pairs.
• Use these examples to demonstrate inter-class similarity.

Selected images are stored in:

      selected_pairs/interclass_similarity/
```

STEP 7 — INTRA-CLASS DISSIMILARITY

```
• Compare embeddings within the Siamese class.
• Ignore self-comparisons.
• Identify pairs with the lowest cosine similarity.
• Visually inspect the selected pairs.
• Use these examples to demonstrate intra-class dissimilarity.

Selected images are stored in:

      selected_pairs/intraclass_dissimilarity/
```

STEP 8 — TRAIN THE LINEAR PROBE

```
Use Logistic Regression as the linear probe.

Training guidelines:

    • Use only the trainval embeddings.( Embeddings u can find at data Folder )
    • Use all 3680 trainval images for training.
    • Do not use test embeddings during training.
    • Use the saved DINOv2 embeddings directly.
    • Apply no additional embedding transformation.
    • Keep the DINOv2 backbone frozen.

Classifier settings:

    Classifier       = Logistic Regression
    Maximum iterations = 2000
    Random state       = 42
```

STEP 9 — FINAL EVALUATION

```
• Evaluate the trained classifier once on the official test split.
• Use all 3669 test images for evaluation.
• Generate predictions for the test images.
• Calculate:
      - Test Accuracy
      - Macro-averaged F1 score

The test set must not be used for training or parameter selection.
```

## 5. REPRODUCTION / EXECUTION ORDER

Execute the experiment in the following order:

```
01. Load and verify the Oxford-IIIT Pet Dataset.
02. Load the pretrained DINOv2-small model.
03. Freeze the DINOv2 backbone.
04. Extract trainval [CLS] embeddings.
05. Extract test [CLS] embeddings.
06. Verify embedding dimensions and counts.
07. Save train and test embeddings.
08. Generate the Cat-vs-Dog t-SNE plot.
09. Generate the six-breed t-SNE plot.
10. Perform inter-class similarity analysis.
11. Perform intra-class dissimilarity analysis.
12. Load the saved train embeddings.
13. Train the Logistic Regression linear probe.
14. Load the saved test embeddings.
15. Evaluate on the official test split.
16. Calculate accuracy and macro F1.
17. Report the final results.
```

## 6. IMPORTANT GUIDELINES / CHECKS

Before submission, verify the following:

```
✓ 37 breed classes are used.

✓ 3680 trainval images are used for classifier training.

✓ 3669 official test images are reserved for final evaluation.

✓ Exactly one embedding is extracted per image.

✓ Each DINOv2-small embedding has 384 dimensions.

✓ The DINOv2 backbone remains frozen.

✓ No test data is used during classifier training.

✓ No additional transformation is applied to the embeddings.

✓ Logistic Regression uses:
      max_iter = 2000
      random_state = 42

✓ The official test set is evaluated only once.

✓ Accuracy and Macro F1 are reported to four decimal places.

✓ All required output files and folders are present.
```

## 7. OUTPUT FILES

Expected output files:

```
train_embeddings.pt
test_embeddings.pt

dino_v2_tsne_cat_vs_dog.png
tsne_sex_breeds.png
```

Expected output directories:

```
selected pairs/
    ├── interclass similarity/
    └── intraclass_dissimilarity/
```

## 8. FINAL CLASSIFICATION RESULT

+----------------------------------+----------------+----------+
| Classifier                       | Test Accuracy  | Macro F1 |
+----------------------------------+----------------+----------+
| Logistic Regression (Linear      |    0.9463      |  0.9455  |
| Probe)                           |                |          |
+----------------------------------+----------------+----------+

9. SUMMARY

---

The complete pipeline is:

```
Oxford-IIIT Pet Dataset
          ↓
   Frozen DINOv2-small
          ↓
   384-D [CLS] Embeddings
          ↓
   ┌───────────────┐
   │               │
   ↓               ↓
  t-SNE       Similarity Analysis
   │               │
   ↓               ↓
```

Visualization    Selected Pairs
↓
Logistic Regression
Linear Probe
↓
Official Test Split
↓
Accuracy / Macro F1

Final reported results:

```
Test Accuracy = 0.9463
Macro F1      = 0.9455
```

============================================================
END OF README
=============

