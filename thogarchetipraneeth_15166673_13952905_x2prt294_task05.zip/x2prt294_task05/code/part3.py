# part3.py
import torch
from transformers import AutoImageProcessor, AutoModel
from PIL import Image

# 1. Load frozen DINOv2-small
proc  = AutoImageProcessor.from_pretrained("facebook/dinov2-small")
model = AutoModel.from_pretrained("facebook/dinov2-small")
model.eval()                                  # frozen: no dropout / no BN updates

# 2. Build a small batch (swap in filenames that exist in your folder)
BASE  = "data/oxford-iiit-pet/images/"
paths = [
    BASE + "Russian_Blue_1.jpg",
    BASE + "Abyssinian_1.jpg",
    BASE + "american_pit_bull_terrier_1.jpg",
    BASE + "staffordshire_bull_terrier_1.jpg",
]
imgs = [Image.open(p).convert("RGB") for p in paths]

# 3. Preprocess -> tensor
inputs = proc(images=imgs, return_tensors="pt")
print("Processed input (pixel_values):", tuple(inputs["pixel_values"].shape))

# 4. Forward pass, no gradients (frozen)
with torch.no_grad():
    out = model(**inputs)

# 5. Report shapes
print("Final hidden state:", tuple(out.last_hidden_state.shape))

cls = out.last_hidden_state[:, 0, :]          # [CLS] token = index 0
print("CLS embedding:", tuple(cls.shape))

# 6. Dimensionality + one-embedding-per-image check
print("Embedding dimensionality:", cls.shape[1])
assert cls.shape[0] == len(paths), "expected one embedding per image"
print(f"Verified: {cls.shape[0]} embeddings for {len(paths)} images")