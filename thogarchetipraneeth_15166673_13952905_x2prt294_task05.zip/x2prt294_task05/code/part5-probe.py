# part5_probe.py
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score

Xtr = np.load("trainval_embeddings.npy"); Ytr = np.load("trainval_labels.npy")
Xte = np.load("test_embeddings.npy");     Yte = np.load("test_labels.npy")

# STANDARDISATION: fit on TRAIN only, then apply to test (state this in report)
scaler = StandardScaler().fit(Xtr)
Xtr_s  = scaler.transform(Xtr)
Xte_s  = scaler.transform(Xte)

clf = LogisticRegression(max_iter=2000, random_state=42).fit(Xtr_s, Ytr)

pred = clf.predict(Xte_s)
acc  = accuracy_score(Yte, pred)
f1   = f1_score(Yte, pred, average="macro")
print(f"Test Accuracy: {acc:.4f}")
print(f"Macro F1:      {f1:.4f}")