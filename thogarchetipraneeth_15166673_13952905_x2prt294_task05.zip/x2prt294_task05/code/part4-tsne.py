# part4_tsne.py
import os
import numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.manifold import TSNE

# ---- load cached embeddings ----
X       = np.load("test_embeddings.npy")
Y       = np.load("test_labels.npy")
classes = list(np.load("classes.npy", allow_pickle=True))

# ---- compute t-SNE ONCE and cache it, so points never shift on re-runs ----
if os.path.exists("tsne_coords.npy"):
    emb = np.load("tsne_coords.npy")
else:
    Xs  = StandardScaler().fit_transform(X)          # STANDARDISATION applied (state in report)
    emb = TSNE(n_components=2, random_state=42, init="pca",
               perplexity=30).fit_transform(Xs)
    np.save("tsne_coords.npy", emb)

# ---- Plot 1: Cat vs Dog ----
cat_breeds = {"Abyssinian","Bengal","Birman","Bombay","British Shorthair",
              "Egyptian Mau","Maine Coon","Persian","Ragdoll","Russian Blue",
              "Siamese","Sphynx"}
is_cat = np.array([classes[y] in cat_breeds for y in Y])

plt.figure(figsize=(10,7))
plt.scatter(emb[is_cat,0],  emb[is_cat,1],  s=8, c="tab:orange", label="Cat", alpha=.6)
plt.scatter(emb[~is_cat,0], emb[~is_cat,1], s=8, c="tab:blue",   label="Dog", alpha=.6)
plt.legend(title="Super-category", markerscale=2)
plt.title("Plot 1: DINOv2 Embedding Space - Cat vs Dog Structure")
plt.xlabel("t-SNE Dimension 1"); plt.ylabel("t-SNE Dimension 2")
plt.grid(True, linestyle="-", alpha=0.3)
plt.savefig("tsne_cat_dog.png", dpi=150, bbox_inches="tight")

# ---- Plot 2: 6 breeds (original selection) ----
six = ["American Pit Bull Terrier","Staffordshire Bull Terrier",
       "Persian","Samoyed","Sphynx","Bengal"]
plt.figure(figsize=(10,7))
for name in six:
    m = Y == classes.index(name)
    plt.scatter(emb[m,0], emb[m,1], s=18, label=name, alpha=.75)
plt.legend(title="Selected Breeds", markerscale=1.5, fontsize=9)
plt.title("Plot 2: DINOv2 Embedding Space - Focused 6-Breed Subset Visualisation")
plt.xlabel("t-SNE Dimension 1"); plt.ylabel("t-SNE Dimension 2")
plt.grid(True, linestyle="-", alpha=0.3)
plt.savefig("tsne_6breeds.png", dpi=150, bbox_inches="tight")

print("saved tsne_cat_dog.png and tsne_6breeds.png")