# part2_figure.py
import matplotlib
matplotlib.use("Agg")            # save to file, no GUI needed on WSL
import matplotlib.pyplot as plt
from PIL import Image

BASE = "data/oxford-iiit-pet/images/"

# TODO: put YOUR four exact filenames here
inter = ["american_pit_bull_terrier_130.jpg", "staffordshire_bull_terrier_101.jpg"]
intra = ["Russian_Blue_1.jpg",              "Russian_Blue_101.jpg"]

fig, ax = plt.subplots(2, 2, figsize=(9, 9))
titles = ["Inter-class similarity\nAmerican Pit Bull Terrier",
          "Inter-class similarity\nStaffordshire Bull Terrier",
          "Intra-class dissimilarity\nRussian Blue (a)",
          "Intra-class dissimilarity\nRussian Blue (b)"]
for a, fn, t in zip(ax.ravel(), inter + intra, titles):
    a.imshow(Image.open(BASE + fn)); a.axis("off"); a.set_title(t, fontsize=10)
plt.tight_layout()
plt.savefig("task1_pairs.png", dpi=150)
print("saved task1_pairs.png")