# part1.py
from torchvision.datasets import OxfordIIITPet

# Official splits, category (breed) labels, auto-download
trainval = OxfordIIITPet(root="data", split="trainval", target_types="category", download=True)
test     = OxfordIIITPet(root="data", split="test",     target_types="category", download=True)

# 1. counts
print("Trainval images:", len(trainval))
print("Test images:    ", len(test))

# 2. number of classes — read it from the dataset, not hardcoded
print("Number of classes:", len(trainval.classes))

# 3. inspect one sample so you know the data types for later
img, label = trainval[0]
print("Image type:", type(img))          # PIL.Image.Image
print("Image size:", img.size)           # (width, height) — varies per image
print("Label:", label, "->", trainval.classes[label])  # int index + breed name
