# part4_extract.py
import torch, numpy as np
from transformers import AutoImageProcessor, AutoModel
from torchvision.datasets import OxfordIIITPet
from torch.utils.data import DataLoader

proc  = AutoImageProcessor.from_pretrained("facebook/dinov2-small")
model = AutoModel.from_pretrained("facebook/dinov2-small").eval()

test = OxfordIIITPet(root="data", split="test", target_types="category", download=False)
print("classes:", test.classes)          # note the exact string format

def collate(batch):
    imgs   = [im.convert("RGB") for im, _ in batch]
    labels = [l for _, l in batch]
    px = proc(images=imgs, return_tensors="pt")["pixel_values"]
    return px, torch.tensor(labels)

loader = DataLoader(test, batch_size=32, collate_fn=collate, num_workers=0)

feats, labs = [], []
with torch.no_grad():
    for i, (px, y) in enumerate(loader):
        cls = model(pixel_values=px).last_hidden_state[:, 0, :]   # [B,384]
        feats.append(cls.numpy()); labs.append(y.numpy())
        print(f"batch {i+1}/{len(loader)}", end="\r")

X = np.concatenate(feats); Y = np.concatenate(labs)
np.save("test_embeddings.npy", X)
np.save("test_labels.npy", Y)
np.save("classes.npy", np.array(test.classes, dtype=object))
print("\nsaved", X.shape, Y.shape)