Task 05 -- Measure your transformation!
CSO-610 Summer 2025-26
=========================================================

HONOR CODE
----------
Team: Narasinga Rao T. and Saahil Tamboli. We went through the entire
project together and shared the dataset exploration, DINOv2 feature
extraction, t-SNE visualisation, and linear-probe classification work
equally between us.

For the LaTeX write-up, the Python implementation, and parts of the
research/understanding of DINOv2 and t-SNE, we used Claude Code
(Anthropic), an LLM assistant, to: scaffold and run the dataset/embedding
extraction/t-SNE/linear-probe scripts (code/01..05_*.py), resolve a
corporate-proxy SSL certificate issue when downloading the dataset and
the DINOv2 checkpoint, explain concepts such as the [CLS] token and why
the backbone is "frozen", and draft the written explanations in
task-body.tex. All breed-pair choices, plot interpretation, and final
numbers were reviewed and verified by us against the actual generated
plots/output before submission.

Reference: DINOv2 paper (arXiv:2304.07193), Hugging Face DINOv2 docs,
Oxford-IIIT Pet dataset page, torchvision OxfordIIITPet docs -- all
linked in Task05.pdf.

SUBMISSION NOTES
-----------------
Late days used: 0

=========================================================

REPRODUCTION INSTRUCTIONS
--------------------------
Install dependencies:
    pip install -r code/requirements.txt

Exact versions used for the reported numbers/plots (see code/requirements.txt):
torch==2.13.0, torchvision==0.28.0, transformers==5.14.1,
scikit-learn==1.9.0, matplotlib==3.11.1, Pillow==12.3.0

All random seeds (torch, TSNE, LogisticRegression) are fixed to 42.

Note: on networks behind a corporate TLS-intercepting proxy, `pip install
truststore` plus the `truststore.inject_into_ssl()` call at the top of the
dataset/model scripts routes HTTPS verification through the OS trust store
instead of Python's bundled CA list. Remove that import if not needed on
your network.

Run from inside the code/ directory, in this order:

1. python3 01_dataset_info.py
   Downloads Oxford-IIIT Pet into ../data (created automatically, not
   submitted) and prints the number of trainval images, test images, and
   classes.

2. python3 02_sample_pairs.py
   Saves the two sample-image pairs used to discuss the "hard to
   classify" visual factors (Section 1) to ../images/:
     - factor1_interclass_similarity.png
     - factor2_intraclass_dissimilarity.png

3. python3 03_extract_embeddings.py
   Loads facebook/dinov2-small (frozen, no gradient updates) via
   transformers.AutoModel, extracts the last-layer [CLS] embedding for
   every trainval/test image, prints the required tensor shapes for one
   batch, and saves embeddings to ../embeddings/dinov2_small_embeddings.npz
   (not submitted -- regenerate via this script). Runs on CPU; takes a
   few minutes for ~7350 images.

4. python3 04_tsne_plots.py
   Loads the saved embeddings, standardises the TEST split embeddings
   (StandardScaler fit on the test split itself), runs
   sklearn.manifold.TSNE(random_state=42), and saves:
     - ../images/tsne_cat_vs_dog.png
     - ../images/tsne_6breed_subset.png

5. python3 05_linear_probe.py
   Loads the saved embeddings, standardises with a StandardScaler fit on
   trainval only (applied unchanged to test), trains
   sklearn.linear_model.LogisticRegression(max_iter=2000, random_state=42)
   on trainval, evaluates once on test, and prints test accuracy and
   macro-F1 to 4 decimal places.

Reported results (facebook/dinov2-small, [CLS] embedding, dim=384)
------------------------------------------------------------------
Trainval images: 3680 | Test images: 3669 | Classes: 37

Linear probe (Logistic Regression):
  Test accuracy: 0.9469
  Macro F1:      0.9461

Not submitted (regenerate via the scripts above): ../data/ (Oxford-IIIT
Pet raw files), the downloaded DINOv2 checkpoint (cached by
huggingface_hub, not stored in this repo), and
../embeddings/dinov2_small_embeddings.npz.

=========================================================

DISCREPANCY NOTES
------------------
None observed -- LogisticRegression converged within max_iter=2000 without
needing a documented parameter change.
