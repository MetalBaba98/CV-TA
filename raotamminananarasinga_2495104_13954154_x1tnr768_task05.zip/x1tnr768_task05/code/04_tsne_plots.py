"""
Task05 - Section 4: t-SNE visualisation of the DINOv2 [CLS] embeddings
for the TEST split.

Plot 1: coloured by cat-vs-dog super-category.
Plot 2: 6 chosen breeds only, coloured by breed, with legend.

Breed choice (see Section 2 discussion):
  - American Pit Bull Terrier / Staffordshire Bull Terrier
      -> the inter-class-similarity pair (two breeds that look alike).
  - Chihuahua / Great Pyrenees
      -> two dog breeds that are visually very distinct from each other
         despite both being dogs (tiny vs. giant).
  - Siamese / Persian
      -> two cat breeds that are visually very distinct from each other
         (short-haired pointed coat vs. long-haired fluffy coat).
"""
import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE
from sklearn.preprocessing import StandardScaler

SEED = 42
EMB_DIR = os.environ.get("PET_EMB_DIR", "../embeddings")
OUT_DIR = os.environ.get("PET_IMAGES_DIR", "../images")

# Oxford-IIIT Pet: cat breeds are exactly these 12; everything else is a dog.
CAT_BREEDS = {
    "Abyssinian", "Bengal", "Birman", "Bombay", "British Shorthair",
    "Egyptian Mau", "Maine Coon", "Persian", "Ragdoll", "Russian Blue",
    "Siamese", "Sphynx",
}

CHOSEN_BREEDS = [
    "American Pit Bull Terrier",
    "Staffordshire Bull Terrier",
    "Chihuahua",
    "Great Pyrenees",
    "Siamese",
    "Persian",
]


def main():
    data = np.load(os.path.join(EMB_DIR, "dinov2_small_embeddings.npz"), allow_pickle=True)
    test_emb = data["test_emb"]
    test_labels = data["test_labels"]
    classes = list(data["classes"])

    # Standardise (fit on test embeddings only, since t-SNE here is applied
    # to the test split alone -- stated explicitly per assignment instructions).
    scaler = StandardScaler()
    test_emb_std = scaler.fit_transform(test_emb)

    tsne = TSNE(n_components=2, random_state=SEED, init="pca", learning_rate="auto")
    proj = tsne.fit_transform(test_emb_std)  # (N, 2)

    is_cat = np.array([classes[l] in CAT_BREEDS for l in test_labels])

    # ---- Plot 1: cat vs dog ----
    fig, ax = plt.subplots(figsize=(7, 6))
    ax.scatter(proj[~is_cat, 0], proj[~is_cat, 1], s=8, alpha=0.6, label="Dog", c="tab:blue")
    ax.scatter(proj[is_cat, 0], proj[is_cat, 1], s=8, alpha=0.6, label="Cat", c="tab:orange")
    ax.set_title("t-SNE of DINOv2-small [CLS] embeddings (test split)\ncoloured by cat vs. dog")
    ax.set_xlabel("t-SNE dim 1"); ax.set_ylabel("t-SNE dim 2")
    ax.legend()
    fig.tight_layout()
    fig.savefig(os.path.join(OUT_DIR, "tsne_cat_vs_dog.png"), dpi=150)
    plt.close(fig)

    # ---- Plot 2: 6-breed subset ----
    fig, ax = plt.subplots(figsize=(8, 6))
    cmap = plt.get_cmap("tab10")
    for i, breed in enumerate(CHOSEN_BREEDS):
        breed_idx = classes.index(breed)
        mask = test_labels == breed_idx
        ax.scatter(proj[mask, 0], proj[mask, 1], s=14, alpha=0.8, label=breed, color=cmap(i))
    ax.set_title("t-SNE of DINOv2-small [CLS] embeddings (test split)\n6 chosen breeds")
    ax.set_xlabel("t-SNE dim 1"); ax.set_ylabel("t-SNE dim 2")
    ax.legend(loc="best", fontsize=8)
    fig.tight_layout()
    fig.savefig(os.path.join(OUT_DIR, "tsne_6breed_subset.png"), dpi=150)
    plt.close(fig)

    print("Saved tsne_cat_vs_dog.png and tsne_6breed_subset.png to", OUT_DIR)


if __name__ == "__main__":
    main()
