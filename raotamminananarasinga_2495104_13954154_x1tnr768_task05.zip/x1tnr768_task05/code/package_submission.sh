#!/bin/bash
# Builds x1tnr768_task05.zip containing exactly the files/folders listed in
# 05-task-header.inc (the submission structure from Task05.pdf), no more,
# no less. Run this from the Task05/ directory after answers.pdf and
# ReflectionEssay.pdf are (re)compiled with your real content.
set -euo pipefail
cd "$(dirname "$0")/.."

NAME=x1tnr768_task05
STAGE="/tmp/${NAME}_stage"
rm -rf "$STAGE"
mkdir -p "$STAGE/$NAME"

for f in answers.pdf answers.tex HW.sty 05-task-header.inc task-body.tex readme.txt ReflectionEssay.pdf; do
  cp "$f" "$STAGE/$NAME/$f"
done

mkdir -p "$STAGE/$NAME/images" "$STAGE/$NAME/code"
# images/: only real content
rsync -a --exclude 'PLACE_*' images/ "$STAGE/$NAME/images/"
# code/: drop bytecode caches, downloaded data/embeddings (regenerable, not submitted)
rsync -a --exclude '__pycache__' code/ "$STAGE/$NAME/code/"

rm -f "${NAME}.zip"
(cd "$STAGE" && zip -rq -X "$OLDPWD/${NAME}.zip" "$NAME")

echo "Built ${NAME}.zip. Contents:"
unzip -l "${NAME}.zip"
