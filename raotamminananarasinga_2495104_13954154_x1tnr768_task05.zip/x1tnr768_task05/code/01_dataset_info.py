"""
Task05 - Section 2: download Oxford-IIIT Pet and report basic dataset stats.
Run: python3 01_dataset_info.py
"""
import os
import truststore
truststore.inject_into_ssl()
from torchvision.datasets import OxfordIIITPet

DATA_ROOT = os.environ.get("PET_DATA_ROOT", "../data")


def main():
    trainval = OxfordIIITPet(
        root=DATA_ROOT, split="trainval", target_types="category", download=True
    )
    test = OxfordIIITPet(
        root=DATA_ROOT, split="test", target_types="category", download=True
    )

    classes = trainval.classes
    print(f"Number of trainval (training) images: {len(trainval)}")
    print(f"Number of test images: {len(test)}")
    print(f"Number of classes: {len(classes)}")
    print("Classes:")
    for i, c in enumerate(classes):
        print(f"  {i:2d}: {c}")


if __name__ == "__main__":
    main()
