"""
Task05 - Section 2.1, item 2/3: two visual factors that make breed
classification hard, each illustrated with a sample image pair.

Factor 1 (inter-class similarity): American Pit Bull Terrier vs
Staffordshire Bull Terrier -- two different breeds that look almost
identical (same short coat, same muscular build, overlapping colour
patterns).

Factor 2 (intra-class dissimilarity): two Chihuahuas that look very
different from each other (coat length/colour/pose varies a lot within
the same breed label).
"""
import os
import truststore
truststore.inject_into_ssl()
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from torchvision.datasets import OxfordIIITPet

DATA_ROOT = os.environ.get("PET_DATA_ROOT", "../data")
OUT_DIR = os.environ.get("PET_IMAGES_DIR", "../images")


def first_n_images(ds, class_name, n):
    idx = ds.classes.index(class_name)
    imgs = []
    for i in range(len(ds)):
        if ds._labels[i] == idx:
            imgs.append(ds[i][0])
            if len(imgs) == n:
                break
    return imgs


def main():
    os.makedirs(OUT_DIR, exist_ok=True)
    ds = OxfordIIITPet(root=DATA_ROOT, split="trainval", target_types="category", download=True)

    # Factor 1: inter-class similarity
    pitbull = first_n_images(ds, "American Pit Bull Terrier", 1)[0]
    staffie = first_n_images(ds, "Staffordshire Bull Terrier", 1)[0]

    fig, axes = plt.subplots(1, 2, figsize=(8, 4))
    axes[0].imshow(pitbull); axes[0].set_title("American Pit Bull Terrier"); axes[0].axis("off")
    axes[1].imshow(staffie); axes[1].set_title("Staffordshire Bull Terrier"); axes[1].axis("off")
    fig.suptitle("Factor 1: Inter-class similarity (different breeds, similar look)")
    fig.tight_layout()
    fig.savefig(os.path.join(OUT_DIR, "factor1_interclass_similarity.png"), dpi=150)
    plt.close(fig)

    # Factor 2: intra-class dissimilarity
    chihuahuas = first_n_images(ds, "Chihuahua", 6)
    idx_pair = (0, 5) if len(chihuahuas) > 5 else (0, len(chihuahuas) - 1)
    c1, c2 = chihuahuas[idx_pair[0]], chihuahuas[idx_pair[1]]

    fig, axes = plt.subplots(1, 2, figsize=(8, 4))
    axes[0].imshow(c1); axes[0].set_title("Chihuahua (sample A)"); axes[0].axis("off")
    axes[1].imshow(c2); axes[1].set_title("Chihuahua (sample B)"); axes[1].axis("off")
    fig.suptitle("Factor 2: Intra-class dissimilarity (same breed, very different look)")
    fig.tight_layout()
    fig.savefig(os.path.join(OUT_DIR, "factor2_intraclass_dissimilarity.png"), dpi=150)
    plt.close(fig)

    print("Saved factor1_interclass_similarity.png and factor2_intraclass_dissimilarity.png to", OUT_DIR)


if __name__ == "__main__":
    main()
