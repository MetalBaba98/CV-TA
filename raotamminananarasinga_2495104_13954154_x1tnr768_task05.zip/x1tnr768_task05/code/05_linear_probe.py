"""
Task05 - Section 5: linear probe (multiclass logistic regression) trained
on frozen DINOv2-small [CLS] embeddings.

Standardisation is fit on trainval embeddings only and applied unchanged
to the test embeddings.
"""
import os
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score
from sklearn.preprocessing import StandardScaler

SEED = 42
EMB_DIR = os.environ.get("PET_EMB_DIR", "../embeddings")


def main():
    data = np.load(os.path.join(EMB_DIR, "dinov2_small_embeddings.npz"), allow_pickle=True)
    X_train, y_train = data["trainval_emb"], data["trainval_labels"]
    X_test, y_test = data["test_emb"], data["test_labels"]

    scaler = StandardScaler()
    X_train_std = scaler.fit_transform(X_train)
    X_test_std = scaler.transform(X_test)

    clf = LogisticRegression(max_iter=2000, random_state=SEED)
    clf.fit(X_train_std, y_train)

    y_pred = clf.predict(X_test_std)
    acc = accuracy_score(y_test, y_pred)
    macro_f1 = f1_score(y_test, y_pred, average="macro")

    print(f"Test accuracy: {acc:.4f}")
    print(f"Macro-averaged F1: {macro_f1:.4f}")


if __name__ == "__main__":
    main()
